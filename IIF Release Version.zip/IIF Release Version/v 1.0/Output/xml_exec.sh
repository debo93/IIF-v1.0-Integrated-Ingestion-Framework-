xml_path=/home/lmaddineni/Output_IIF/STREAMS_XMLs
count_path=/home/lmaddineni/Output_IIF/UT_Check
env_path=/home/lmaddineni/Output_IIF/STREAMS_XMLs/env_setting.properties
FILE_PATH=/home/lmaddineni/Output_IIF/STREAMS_XMLs/stream.list
FILE_PATH_COUNT_SRC=/home/lmaddineni/Output_IIF/UT_Check/src_stream_count.list
FILE_PATH_COUNT_TGT=/home/lmaddineni/Output_IIF/UT_Check/tgt_stream_count.list
####################################################################################################
#SOURCING ENVIRONMENTAL PROPERTIES
####################################################################################################
#cd $xml_path 
#chmod 777 *
source $env_path
#######################################################################################
#COUNT STREAM EXECUTE
#######################################################################################
#cd $count_path
Groups=`cat ${FILE_PATH_COUNT_SRC}|cut -d '|' -f 2|uniq`
#echo $Groups
for Group in $Groups
do
Streams=`cat ${FILE_PATH_COUNT_SRC}|grep -w "\|$Group"|cut -d '|' -f 1`
#echo $Streams
for Stream_name_COUNT in $Streams
do
dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name_COUNT
echo $Stream_name_COUNT
done
done
#######################################################################################
#INGESTION STREAM EXECUTE
#######################################################################################
Groups=`cat ${FILE_PATH}|cut -d '|' -f 2|uniq`
#echo $Groups_1
for Group in $Groups
do
Streams_1=`cat ${FILE_PATH}|grep -w "\|$Group"|cut -d '|' -f 1`
#echo $Streams_1
for Stream_name in $Streams_1
do
dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name
echo $Stream_name
done
done
#######################################################################################
#COUNT STREAM EXECUTE
#######################################################################################
#cd $count_path
Groups=`cat ${FILE_PATH_COUNT_TGT}|cut -d '|' -f 2|uniq`
#echo $Groups
for Group in $Groups
do
Streams=`cat ${FILE_PATH_COUNT_TGT}|grep -w "\|$Group"|cut -d '|' -f 1`
#echo $Streams
for Stream_name_COUNT in $Streams
do
dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name_COUNT
echo $Stream_name_COUNT
done
done
