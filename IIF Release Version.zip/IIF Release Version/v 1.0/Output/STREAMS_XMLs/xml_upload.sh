xml_path=/hhome/latammisdev/Demo/STREAMS  
env_path=/hhome/latammisdev/Demo/env_setting.properties
cd $xml_path 
source $env_path
##path of location of XML
for filename in s_*.xml
do
dicmd import -u lmaddineni -w Cis@co666 -p ingest_cl_b85p -l Technical_Zone -f $xml_path/$filename  
echo $filename imported#For exporting just use export in place of import in dicmd command
done
