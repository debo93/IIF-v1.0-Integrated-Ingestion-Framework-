xml_path=/home/lmaddineni/Output_IIF/STREAMS_XMLs
count_path=/home/lmaddineni/Output_IIF/UT_Check
env_path=/home/lmaddineni/Output_IIF/STREAMS_XMLs/env_setting.properties
####################################################################################################
#SOURCING ENVIRONMENTAL PROPERTIES
####################################################################################################
cd $xml_path
chmod 777 *
source $env_path
#####################################################################################################
#INGESTION STREAM IMPORT
#####################################################################################################
for filename in s_*.xml
do
dicmd import -u $DI_USER -w $DI_PASSWORD -p $DI_PROJECT -l $DI_LAYER -f $xml_path/$filename
echo $filename imported
done
######################################################################################################
#COUNT STREAM IMPORT
######################################################################################################
cd $count_path
chmod 777 *
for filename in s_*.xml
do
dicmd import -u $DI_USER -w $DI_PASSWORD -p $DI_PROJECT -l $DI_LAYER -f $count_path/$filename
echo $filename imported
done
