import os

i = os.getcwd()
b = len(i)
k=0
g=0
base_path=""
for k in range(1,b):
    c=b-k
    #print i[0:c]
    try:
        if("Input" in os.listdir(i[0:c])):
            base_path = i[0:c]
    except:
        g=1
        
print base_path
        


