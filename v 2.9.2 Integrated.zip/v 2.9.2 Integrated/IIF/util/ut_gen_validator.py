###################################################################################################
# Title : COUNT XML GENERATE
# Author : Avishek Chatterjee <AC00478691@TECHMAHINDRA.COM>
# Description : Generating Count xmls for DB2 System
# System : DB2
# Version : 0.2
# Changes : Added connection read mechanism
# Changes By : Shobha Rana
###################################################################################################

import paramiko
import logging
import os
from dict_paths import *

TABLE_DICT = {}

def get_table_and_fields(frame):
    frame = frame.reset_index().drop("index", axis=1)
    table_name = frame.table_name.values.tolist()[0]

    if table_name not in TABLE_DICT:
        TABLE_DICT[table_name] = {}
        #print len(frame)


def _get_ssh_client():
    try:
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect('172.25.12.52', port=22, username=User_id, password=password)
    except:
        print "SSH Connection failed."
        client = ""
    
    return client

def init(scDict, tcDict):
    
    logging.basicConfig(filename= log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')
    logging.info('UNIT TESTING CODE STARTED..')
    
    PROJECT_EPM = Prj_EPM_Code
    SOURCE_SYS_EPM = SRC_ID
    if(Country_Code!=''):
    	COUNTRY_CODE=Country_Code
    else :
    	COUNTRY_CODE='_'

    SRC_SCHEMA_NAME = SRC_Schema_Name
    TGT_SCHEMA_NAME = TGT_Schema_Name
    ## database in case of hive
    UNIT_TESTING = output_folder_path+"UT_Check\\"
    SRC_FILE_NAME = UNIT_TESTING+"s_src_" + PROJECT_EPM + "_" + SOURCE_SYS_EPM
    TGT_FILE_NAME = UNIT_TESTING+"s_tgt_" + PROJECT_EPM + "_" + SOURCE_SYS_EPM

     
    DF = df
    
    if not os.path.exists(UNIT_TESTING):
        os.makedirs(UNIT_TESTING)
        logging.info('UNIT TESTING XMLS CREATION STARTED')
    
    DF.groupby(DF.table_name).apply(get_table_and_fields)

    
    SQL = ""
    i = 0
    for table_name, ft in sorted(TABLE_DICT.iteritems()):
        if i == 0:
            SQL = ("select &apos;" + table_name + "&apos; , &apos; " +
                   SRC_SCHEMA_NAME + "&apos; AS schema_name , count(*) AS count ,"+
                   " TO_CHAR(TIMESTAMP_FORMAT(&apos;$$CurrentDateString&apos;," +
                   "&apos;YYYYMMDDHH24MISS&apos;),::TS::) AS load_time, &apos;" +
                   PROJECT_EPM + "&apos; AS PROJECT_EPM, &apos;" + SOURCE_SYS_EPM +
                   "&apos; AS SOURCE_SYS_EPM, &apos;" + COUNTRY_CODE + "&apos; " +
                   "AS COUNTRY_CODE, TO_CHAR($$CurrentDate,::D::) AS load_date " +
                   " from " + SRC_SCHEMA_NAME + "." + table_name + " &#xd; "+" \n"
                  )
        else:
            SQL += ("union all select &apos;" + table_name + "&apos; , &apos; " +
                    SRC_SCHEMA_NAME + "&apos; AS schema_name , count(*) AS count ,"+
                    " TO_CHAR(TIMESTAMP_FORMAT(&apos;$$CurrentDateString&apos;," +
                    "&apos;YYYYMMDDHH24MISS&apos;),::TS::) AS load_time, &apos;" +
                    PROJECT_EPM + "&apos; AS PROJECT_EPM, &apos;" + SOURCE_SYS_EPM+
                    "&apos; AS SOURCE_SYS_EPM, &apos;" + COUNTRY_CODE + "&apos; " +
                    "AS COUNTRY_CODE, TO_CHAR($$CurrentDate,::D::) AS load_date " +
                    " from " + SRC_SCHEMA_NAME + "." + table_name + " &#xd; "+" \n"
                   )
        i = i + 1
    
    SRC_CONN_NAME = ''
    SRC_CONN_DB_NAME = ''
    SRC_CONN_ID = ''
    SRC_CONN_DB_ID = ''
 
    for val in scDict.values():
        #print(val)
        
        if val['nm'].upper() == SRC_SCHEMA_NAME.upper():
            
            SRC_CONN_NAME = val['con_name']
            #print(SRC_CONN_NAME)
            SRC_CONN_DB_NAME = val['dbParamNm']
            #print(SRC_CONN_DB_NAME)
            SRC_CONN_ID = val['conn_Id']
            #print(SRC_CONN_ID)
            SRC_CONN_DB_ID = val['conn_Db_Id']
            SRC_SCHEMA_NAME = val['nm']
            break
            
           
            

    
    if SRC_CONN_DB_NAME.isspace():
        print "Source connection invalid.\nUser needs to map connection manually in Diyotta"
    else:
        logging.info( SRC_CONN_NAME + ", " + SRC_CONN_DB_NAME + ", " + SRC_CONN_ID +
                     ", " + SRC_CONN_DB_ID + ", " + SRC_SCHEMA_NAME)

    TGT_CONN_NAME = ''
    TGT_CONN_DB_NAME = ''
    TGT_CONN_ID = ''
    TGT_CONN_DB_ID = ''
    TGT_CONN_PARAM_NM =''


    for val in tcDict.values():
        if val['nm'].upper() == TGT_SCHEMA_NAME.upper():
            TGT_CONN_NAME = val['con_name']
            TGT_CONN_DB_NAME = val['dbParamNm']
            TGT_CONN_ID = val['conn_Id']
            TGT_CONN_DB_ID = val['conn_Db_Id']
            TGT_SCHEMA_NAME = val['nm']
            TGT_CONN_PARAM_NM = val['connParamNm']
            #print(val['connParamNm'])
            break

    if TGT_CONN_ID.isspace():
        print "Target connection invalid.\nUser needs to map connection manually in Diyotta"
    else:
        logging.info(TGT_CONN_NAME + ", " + TGT_CONN_DB_NAME + ", " + TGT_CONN_ID +
                     ", " + TGT_CONN_DB_ID + ", " + TGT_SCHEMA_NAME )
    template_folder_path = base_path+"\\IIF\\template\\"
    
    with open(template_folder_path+"s_src_template.xml", "r") as fin:
        with open(SRC_FILE_NAME + ".xml", "w") as fout:
            for line in fin:
                if "@src_conn" in line :
                    line = line.replace('@src_conn_Id', SRC_CONN_ID)
                    line = line.replace('@src_conn_Db_Id', SRC_CONN_DB_ID)
                    line = line.replace('@src_conn_name', SRC_CONN_NAME)
                    line = line.replace("@src_nm", SRC_SCHEMA_NAME)
                    fout.write(line.replace('@src_conn_sch_db_name', SRC_CONN_DB_NAME))
                elif "@tgt_conn_Id" in line :
                    line = line.replace("@tgt_conn_Id", TGT_CONN_ID)
                    line = line.replace("@tgt_conn_Db_Id", TGT_CONN_DB_ID)
                    line = line.replace("@tgt_conn_name", TGT_CONN_NAME)
                    line = line.replace("@tgt_nm", TGT_SCHEMA_NAME)
                    line = line.replace("@tgt_Conn_param_name", TGT_CONN_PARAM_NM)
                    fout.write(line.replace("@tgt_conn_sch_db_name", TGT_CONN_DB_NAME))            
                elif "@filename" in line:
                    fout.write(line.replace("@filename", "src_" + PROJECT_EPM + "_" + SOURCE_SYS_EPM))
                elif "@@@@@@@@@@@@@@@@@@@" in line:
                    fout.write(line.replace('@@@@@@@@@@@@@@@@@@@', SQL))
                else:
                    fout.write(line)
    #print "source count stream generated"
    ## end source count xml ##
    
    ## start target count xml ##
    
    SQL = ""
    i = 0
    for table_name, ft in sorted(TABLE_DICT.iteritems()):
        if i == 0:
            SQL = ("set hive.exec.dynamic.partition=TRUE;&#xd;set hive.exec.dynamic.partition.mode=nonstrict;&#xd;"+
                   "&#xd;INSERT OVERWRITE TABLE target_ut_tbl" +
                   "&#xd;PARTITION( PROJECT_EPM,SOURCE_SYS_EPM,COUNTRY_CODE," +
                   "load_date)&#xd;"
                  )
            SQL += ("SELECT &apos;"+Technical_Zone_Name+SOURCE_SYS_EPM+COUNTRY_CODE+ table_name +"&apos;" +
                    ", &apos;" + PROJECT_EPM + "_mis&apos; AS schema_name, count(*)" +
                    " AS count, current_timestamp AS load_time, &apos;" + PROJECT_EPM +
                    "&apos; AS PROJECT_EPM , &apos;" + SOURCE_SYS_EPM + "&apos; AS " +
                    "SOURCE_SYS_EPM,&apos;" + COUNTRY_CODE + "&apos; AS COUNTRY_CODE," +
                    "current_date AS load_date from " + TGT_Schema_Name+"." +Technical_Zone_Name +SOURCE_SYS_EPM+ 
                    COUNTRY_CODE + table_name + " where created_date=" +
                    "current_date&#xd;"+" \n"
                   )
        else:
            SQL += ("UNION ALL SELECT &apos;"+Technical_Zone_Name + SOURCE_SYS_EPM + COUNTRY_CODE + table_name +
                    "&apos;, &apos;" + PROJECT_EPM + "_mis&apos; AS schema_name, count(*)" +
                    " AS count, current_timestamp AS load_time, &apos;" + PROJECT_EPM +
                    "&apos; AS PROJECT_EPM , &apos;" + SOURCE_SYS_EPM + "&apos; AS " +
                    "SOURCE_SYS_EPM,&apos;" + COUNTRY_CODE + "&apos; AS COUNTRY_CODE," +
                    "current_date AS load_date from "+ TGT_Schema_Name+"." +Technical_Zone_Name +SOURCE_SYS_EPM+ 
                    COUNTRY_CODE + table_name + " where created_date=" +
                    "current_date&#xd;"+" \n"
                   )
        i = i + 1
    
    #print ti
    with open(template_folder_path+"s_tgt_template.xml", "r") as fin:
        with open(TGT_FILE_NAME + ".xml", "w") as fout:
            for line in fin:
                if "@tgt_conn_Id" in line :
                    line = line.replace("@tgt_conn_Id", TGT_CONN_ID)
                    line = line.replace("@tgt_conn_Db_Id", TGT_CONN_DB_ID)
                    line = line.replace("@tgt_conn_name", TGT_CONN_NAME)
                    line = line.replace("@tgt_nm", TGT_SCHEMA_NAME)
                    line = line.replace("@tgt_Conn_param_name", TGT_CONN_PARAM_NM)
                    fout.write(line.replace("@tgt_conn_sch_db_name", TGT_CONN_DB_NAME))
                elif "@filename" in line:
                    fout.write(line.replace("@filename", "tgt_" + PROJECT_EPM + "_" + SOURCE_SYS_EPM))
                elif "@@@@@@@@@@@@@@@@@@@" in line:
                    fout.write(line.replace('@@@@@@@@@@@@@@@@@@@', SQL))
                else:
                    fout.write(line)
    #print "target count stream generated"    
    ## end target count xml ##
#==============================================================================
#     else:
#         print "No report will be generated, due to connection issue"
#==============================================================================
        
def main():

    # PARSER = argparse.ArgumentParser()
    # PARSER.add_argument("--input_file", type = str, required = True)
    
    # ARGS = PARSER.parse_args()
    
    
    # TABLE_INFO_FILE=""
    # if ARGS.input_file:
        # TABLE_INFO_FILE = ARGS.input_file
    init(scDict, tcDict)

if __name__ == "__main__":
    scDict = ""
    tcDict = ""
    #print "Start unit testing"
    main()
    print "Ending unit testing...."

