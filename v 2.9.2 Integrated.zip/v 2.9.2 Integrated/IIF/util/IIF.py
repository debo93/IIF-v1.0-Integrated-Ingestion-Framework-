import os,shutil,datetime,subprocess,logging
from dict_paths import *
from Input_metadata_validation import *

###############################################################################
#
#DECLARATION SECTION
#
###############################################################################

exe_edl="n"
validated_file="no"    
k=0
g=0

###############################################################################
#
#Creating Backup of Output Folder if anything present and emptying the 
#directory
###############################################################################

items = []
items = os.listdir(base_path)

if("Output" in items):
    if(len(os.listdir(base_path+"\\Output"))>0):
        print "Previous Output Data Found\nTaking Backup ..."
        shutil.copytree(base_path+"\\Output",base_path+"\\Outputs_Back_Up\\"+"Output_BKP_"+str(datetime.datetime.now().strftime("%d-%M-%Y_%H-%M-%S")))
        print "Backup Process Completed...\nPlease Find your previous output in\n\"Outputs_Back_Up\"\nFolder\n\n"
        shutil.rmtree(base_path+"\\Output")
        os.mkdir(base_path+"\\Output")
    elif(len(os.listdir(base_path+"\\Output"))<=0):
        shutil.rmtree(base_path+"\\Output")
        os.mkdir(base_path+"\\Output")
        
else:
    os.mkdir(base_path+"\\Output")

###############################################################################
#
#Creating the Log File and Writing in it
#
###############################################################################

logging.basicConfig(filename= log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='w') 
   
logging.info('SUBPROCESS STARTED...........')
print "Logging Process started ..."
###############################################################################
#
#Validating the Data Frame
#
###############################################################################

print("\nValidating the Input Metadata...")

logging.info("Input File Validation in progress\n")
try:
    blnk_lst={}
    dupli_list={}
    blnk_lst=blnk_inputs(df)
    dupli_list=dupli_col_chck(table_col_dict)
    if(len(blnk_lst)>1) or (len(dupli_list)>1):
        validated_file="no"
        
        if(len(dupli_list)>1):
            logging.info('Metadata Contains invalid inputs\nDuplicate Columns exists at:\n')
            for table_name,ft in dupli_list.iteritems():
                for y in ft:
                    logging.info("Table Name : "+table_name+":"+"Column Name : "+y+'\n')
        elif(len(blnk_lst)>1):
            logging.info("Blank Spaces are found at [row,column] : \n")
            for row,ft in blnk_lst.iteritems():
                for col in ft:
                    logging.info("Row : "+str(row)+","+"Column : "+str(col)+'\n')        
    else:
        validated_file="yes"
        print("\tcompleted Successfully ...")
        
except:
    print "\tMetadata Error"
    logging.info("Input Metadata not valid")
    



cntrl_flg=validated_file

if(cntrl_flg=="yes"):
    
    ###############################################################################
    #
    #Creating the HQL Scripts
    #
    ###############################################################################
    
    print("\nCreating HQLs for tables and views ...")
    
    logging.info('\nHQLs GENERATION STARTED ...')
    try:
        p=subprocess.Popen(['python','generate_DDLs_HQLs.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('Exit Code:'+str(p.returncode)+" "+'for DDLs generation process')
        print "\tcompleted Successfully ..."
        
    except:
        print "\tParsing Error ..."
        logging.info("Subprocess for HQL didnt executed properly")
    
    ###############################################################################
    #
    #Creating the STREAMS
    #
    ###############################################################################
    logging.info('\nSTREAM XMLs GENERATION STARTED ...')
    try:
        print "\nGenerating Scripts to generate streams ..."
        p=subprocess.Popen(['python','gen_dyn_strms.py'])
        stdoutdata, stderrdata = p.communicate()
        stdoutdata, stderrdata = p.communicate()
        logging.info('\tExit Code:'+str(p.returncode)+" "+'for generating scripts for creating stream xmls')
        print "\tcompleted Successfully ..."
        
        print "\nGenerating xmls of Streams from scripts..."
        p=subprocess.Popen(['python','gen_streams.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('\tExit Code:'+str(p.returncode)+" "+'for stream xmls geneartion script')
        print "\tcompleted Successfully ..."
        
    except:
        print "\tParsing Error"
        logging.info("\tSubprocess for STREAM creation didnt executed properly")
    
    
    
    
    ###############################################################################
    #
    #UNIT TESTING
    #
    ###############################################################################
    
    logging.info('\nUT STREAM XMLs GENERATION STARTED ...')
    print("\nGenerating Streams for Unit Testing ...")
    try:
        p=subprocess.Popen(['python','call_Conn_prs_UT_Gen.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('\tExit Code:'+str(p.returncode)+" "+'for UT Streams generation process')
        print "\tcompleted Successfully ..."
        
    except:
        print "]tParsing Error"
        logging.info("\tSubprocess for UT XMLS creation didnt executed properly")
    
    ###############################################################################
    #
    #"RELEASE TAR" FOLDER CREATION
    #
    ###############################################################################
    logging.info('\nRELEASE TAR FOLDER GENERATION STARTED ...')
    print("\nCreating Release Tar Folder ...")
    try:
        p=subprocess.Popen(['python','rels_tar.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('Exit Code:'+str(p.returncode)+" "+'for release_tar script')
        print "\tcompleted Successfully ..."
        
    except:
        print "\tParsing Error"
        logging.info("\tSubprocess for Release Tar creation didnt executed properly")
        quit()
    
    ###############################################################################
    #
    #"SHELL SCRIPT" CREATION
    #
    ###############################################################################
    
    print("\nCreating SHELL scripts to upload and execute streams ...")
    
    try:
        p=subprocess.Popen(['python','Shell_Script_gen.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('Exit Code:'+str(p.returncode)+" "+'for Shell script generations for uploading and executing streams')
        print "\tcompleted Successfully ..."
        
    except:
        print "Parsing Error"
        logging.info("\tSubprocess for SHELL SCRIPT CREATION didnt executed properly")
        quit()

    ###############################################################################
    #
    #COUNT STREAM LIST GENERATE
    #
    ###############################################################################
    
    print("\nCreating UT STREAM LIST ...")
    
    try:
        p=subprocess.Popen(['python','stream_count.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('Exit Code:'+str(p.returncode)+" "+'for COUNT STREAM LIST script')
        print "\tcompleted Successfully ..."
        
    except:
        print "\tParsing Error"
        logging.info("Subprocess for COUNT STREAM LIST didnt executed properly")
        quit()


    ###############################################################################
    #
    #INGESTION STREAM LIST GENERATE
    #
    ###############################################################################
    
    print("\nCreating INGESTION STREAM LIST ...")
    
    try:
        p=subprocess.Popen(['python','File_name_Generate.py'])
        stdoutdata, stderrdata = p.communicate()
        logging.info('Exit Code:'+str(p.returncode)+" "+'for INGESTION STREAM LIST script')
        print "\tcompleted Successfully ..."
        
    except:
        print "\tParsing Error"
        logging.info("Subprocess for INGESTION STREAM LIST didnt executed properly")
        quit()
    
    input_2=raw_input("\nWant to Move Output_IIF Folder into EDL(172.25.12.52) server? (y/n) : ")
    
    while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
        input_2=raw_input("\nWant to execute streams in EDL(172.25.12.52) server? (y/n) : ")
    if input_2 in ["y","yes","Yes","YES"]:
        exe_edl="y"    
        
    
    
    if(exe_edl=="y"):
        
        ###############################################################################
        #
        #"EDL FILE MOVEMENT" FOLDER CREATION and STREAM Execution
        #
        ###############################################################################
        
        print("\nMoving Streams and HQLs to 172.25.12.52 server ...")
        try:
            p=subprocess.Popen(['python','move_output.py'])
            stdoutdata, stderrdata = p.communicate()
            logging.info('Exit Code:'+str(p.returncode)+" "+'for edl file movement')
            
            
        except:
            print "Parsing Error"
            logging.info("Subprocess for edl file movement didnt executed properly")
            quit()    
        
        ###############################################################################
        #
        #HQL EXECUTION
        #
        ###############################################################################
        
        
        print("\nEXECUTION HQLS..")
        try:
            p=subprocess.Popen(['python','Hive_Table_Exec.py'])
            stdoutdata, stderrdata = p.communicate()
            logging.info('Exit Code:'+str(p.returncode)+" "+'for Hive_Table_Exec.py script')
            
            
        except:
            print "\tParsing Error"
        logging.info("Subprocess for Hive_Table_Exec creation didnt executed properly")



        ###############################################################################
        #
        #Execution of STREAMS
        #
        ###############################################################################
    
        print("\nUploading and Execution of Streams ...")
        
        
        try:
            p=subprocess.Popen(['python','xml_upload_and_exec.py'])
            logging.info('Exit Code:'+str(p.returncode)+" "+'for xml_upload_and_exec.py script')
            p.communicate()
            
    
        except:
            print "Parsing Error"
            logging.info("Subprocess for xml_upload_and_exec.py didnt executed properly")

        '''
        ###############################################################################
        #
        #Executing UT Streams
        #
        ###############################################################################
    
        print "\nLogging HQLs to Log file, to generate\nMissing, Success and Failure Tables List\nFrom hive ..."
        try:
            p=subprocess.Popen(['python','gen_UT_reports.py'])
            logging.info('Exit Code:'+str(p.returncode)+" "+'for UT Reports generation scripts script')
            p.communicate()
            
    
        except:
            print "\tParsing Error"
            logging.info("Subprocess for Reports geneartion didnt executed properly")
        '''
        print "Below Two tables are also populated : \n1. Source_UT_tbl : Source Data Count of Tables"
        print "\n2. Target_UT_tbl : Target Data Count of Tables"
            
else:
    print "\nInput File is not proper\n\nProcess not executed\nPlease refere Log file for errors"

print("\nCleaning residual files")
int_file_path = base_path+"\\Input\\Input.csv"
os.remove(int_file_path)
print "\tcompleted Successfully ..."

print("\nPlease refer :\n\"IIF.Log\"\n for more details in \"OUTPUT\" Folder")

