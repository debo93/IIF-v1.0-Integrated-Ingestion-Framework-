#Function to check whether any data is missing in the Input dataframe

def blnk_inputs(df):
    blank_index_lst={}
    for index, row in df.iterrows():
        
        if(str(row[0])== 'nan'):
            blank_index_lst[index+2]=['A']
        if(str(row[1])== 'nan'):
            blank_index_lst[index+2]=['B']
        if(str(row[2])== 'nan'):
            blank_index_lst[index+2]=['C']
        if(str(row[3])== 'nan'):
            blank_index_lst[index+2]=['D']
        if(str(row[4])== 'nan'):
            blank_index_lst[index+2]=['E']
        if(str(row[5])== 'nan'):
            blank_index_lst[index+2]=['F']
        if(str(row[6])== 'nan'):
            blank_index_lst[index+2]=['G']
        if(str(row[7])== 'nan'):
            blank_index_lst[index+2]=['H']
    return blank_index_lst

#Function to check for duplicate column names in a table in the Input dataframe
    
def dupli_col_chck(table_dict):
    dupli_dict={}    
    for table_name,ft in sorted(table_dict.iteritems()):
        col_list=[]
        for seq,details in ft.iteritems():
            for y in details:
                col1=str(format(y))
                col_list.append(col1)
            for x in details:
                col=str(format(x))
            index_list=[]
            for items in col_list:
                if(items==col):
                    index_list.append(col_list.index(items))
            if(len(index_list)>1):
                dupli_dict[table_name]=[col]
    return dupli_dict