###################################################################################################
#
# Title : HQL GENERATION
# Author : 
# Description : Generating HQLS for Normal and PII enabled tables
# System : ALL
#
###################################################################################################


import datetime
import os
import time
import logging
from dict_paths import *
from termcolor import colored

logging.basicConfig(filename=log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')
logging.info('HQL CODE STARTED..')

table_dict={}

db2_type_to_hive_type_dict={}

db2_type_to_hive_type_dict['VARCHAR']='string'
db2_type_to_hive_type_dict['VARCHAR2']='string'
db2_type_to_hive_type_dict['CHARACTER']='string'
db2_type_to_hive_type_dict['BIT']='smallint'
db2_type_to_hive_type_dict['DATETIME']='Timestamp'
db2_type_to_hive_type_dict['MONEY']='decimal(16,4)'
db2_type_to_hive_type_dict['NUMBER']='DECIMAL'
db2_type_to_hive_type_dict['NUMERIC']='DECIMAL'
db2_type_to_hive_type_dict['DATE']='TIMESTAMP'
db2_type_to_hive_type_dict['numeric']='DECIMAL'
db2_type_to_hive_type_dict['int']='DECIMAL'
db2_type_to_hive_type_dict['INT']='DECIMAL'
db2_type_to_hive_type_dict['Float']='DECIMAL'
db2_type_to_hive_type_dict['FLOAT']='DECIMAL'
db2_type_to_hive_type_dict['date']='TIMESTAMP' 


def get_table_and_fields(frame):
    frame=frame.reset_index().drop("index",axis=1)
    table_name=frame.table_name.values.tolist()[0]
    
    if table_name not in table_dict:
        table_dict[table_name]={}
        #print len(frame)
        for i in range(len(frame)):
            col=frame.loc[i,"column_name"]
            s_tp=frame.loc[i,"source_type"]
            t_tp=frame.loc[i,"source_type"]
            s_tp=s_tp.upper()
            t_tp=t_tp.upper()
            scl=frame.loc[i,"scale"]
            prs=frame.loc[i,"precision"]
            pii=frame.loc[i,"pii_col"]
            seq=i
			# print col,tp
            if t_tp in db2_type_to_hive_type_dict:
                t_tp=db2_type_to_hive_type_dict[t_tp]
            table_dict[table_name][seq]=[col,s_tp,t_tp,scl,prs,pii]

df.groupby(df.table_name).apply(get_table_and_fields)
flt_file="n"
flt_file_flg="n"
add_cntry_cd="n"
corrct_view="y"
pz_flg="y"

print Country_Code


if(Country_Code!=''):
    add_cntry_cd="y"

'''
input_1=raw_input("\n\tWant to add Country Code in Naming Convention? (y/n) : ")
while input_1 not in ["y","n","yes","no","Yes","No","YES","NO"]:
    input_1=input("\tWant to add Country Code in Naming Convention? (y/n) : ")
if input_1 in ["y","yes","Yes","YES"]:
    add_cntry_cd="y"

input_2=raw_input("\tDo you require Correction views and tables? (y/n) : ")
while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
    input_2=input("\tDo you require Correction views and tables? (y/n) : ")
if input_2 in ["y","yes","Yes","YES"]:
    corrct_view="y"

input_3=raw_input("\tWant to create Procudtion Zone Tables and Views? (y/n) : ")
while input_3 not in ["y","n","yes","no","Yes","No","YES","NO"]:
    input_3=raw_input("\tWant to create Procudtion Zone Tables and Views? (y/n) : ")
if input_3 in ["y","yes","Yes","YES"]:
    pz_flg="y"
'''

if SRC_SYS in ["FLATFILES","FlatFiles","Flat Files","FLAT FILES","flat_files","Flat_Files","FLAT_FILES","Files","FILES","file","files","FLATFILE","FlatFile","Flat File","FLAT FILE","flat_file","Flat_File","FLAT_FILE","File","FILES","file"]:
    flt_file="y"

if(flt_file=="y"):
    if (Staging_Zone_DB not in [" ","nan","NULL"] and Staging_Zone_Name not in [" ","nan","NULL"]):
        flt_file_flg="y"
    elif Staging_Zone_Name in [" ","nan","NULL"]:
        print "Staging Zone Naming Convention not provided ..."
    elif Staging_Zone_DB in [" ","nan","NULL"]:
        print "Staging Zone Database not provided ..."
    
if(Technical_Zone_Name not in [" ","nan","NULL"] and Enterprise_Zone_Name not in [" ","nan","NULL"] and Consumer_Zone_Name not in [" ","nan","NULL"]):
    if(flt_file_flg=="y"):
        if(add_cntry_cd == "y" and pz_flg=="y"):
            tech_name=Technical_Zone_Name+SRC_ID+"_"+Country_Code
            ent_name=Enterprise_Zone_Name+SRC_ID+"_"+Country_Code
            stg_name=Staging_Zone_Name+SRC_ID+"_"+Country_Code
            pz_name=Consumer_Zone_Name+SRC_ID+"_"+Country_Code
        if(add_cntry_cd == "y" and pz_flg=="n"):
            tech_name=Technical_Zone_Name+SRC_ID+"_"+Country_Code
            ent_name=Enterprise_Zone_Name+SRC_ID+"_"+Country_Code
            stg_name=Staging_Zone_Name+SRC_ID+"_"+Country_Code
        if(add_cntry_cd == "n" and pz_flg=="y"):
            tech_name=Technical_Zone_Name+SRC_ID
            ent_name=Enterprise_Zone_Name+SRC_ID
            stg_name=Staging_Zone_Name+SRC_ID
        if(add_cntry_cd == "n" and pz_flg=="n"):
            tech_name=Technical_Zone_Name+SRC_ID
            ent_name=Enterprise_Zone_Name+SRC_ID
            stg_name=Staging_Zone_Name+SRC_ID
    if(flt_file_flg=="n"):
        if(add_cntry_cd == "y" and pz_flg=="y"):
            tech_name=Technical_Zone_Name+SRC_ID+"_"+Country_Code
            ent_name=Enterprise_Zone_Name+SRC_ID+"_"+Country_Code
            pz_name=Consumer_Zone_Name+SRC_ID+"_"+Country_Code
        if(add_cntry_cd == "y" and pz_flg=="n"):
            tech_name=Technical_Zone_Name+SRC_ID+"_"+Country_Code
            ent_name=Enterprise_Zone_Name+SRC_ID+"_"+Country_Code
        if(add_cntry_cd == "n" and pz_flg=="y"):
            tech_name=Technical_Zone_Name+SRC_ID
            ent_name=Enterprise_Zone_Name+SRC_ID
        if(add_cntry_cd == "n" and pz_flg=="n"):
            tech_name=Technical_Zone_Name+SRC_ID
            ent_name=Enterprise_Zone_Name+SRC_ID           
    

if not os.path.exists(hql_folder_path):
	os.makedirs(hql_folder_path)
	logging.info('HQLS PATH CREATED')

quotes = '"'
slash='\\'

tech_name_file=Technical_Zone_Name+SRC_ID
ent_name_file=Enterprise_Zone_Name+SRC_ID
stg_name_file=Staging_Zone_Name+SRC_ID
pz_name_file=Consumer_Zone_Name+SRC_ID

if flt_file_flg=="y":
	logging.info('STAGING TABLE CREATION STARTED......')
	writer=open(hql_folder_path+"\\"+"create_" + stg_name_file +".hql","w")
	
	for table_name,ft in sorted(table_dict.iteritems()):
	
		ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
		ti+="--Project: {Project Name} EDL"+ "\n"
		ti+="--Script File Name : "+ "create_" + stg_name + ".hql"+ "\n"
		ti+="--Script Description :"+ "\n"
		ti+="--Database Name:"+ "\n"
		ti+="--Table Name : " + stg_name +"_"+table_name+ "\n"
		ti+="--Table Description : Creation of tech zone table - " + stg_name +"_"+table_name+ "\n"
		ti+="--Details :"+ "\n"
		ti+="--Date : "+ format(datetime.date.today()) + "\n"
		ti+="--Created by : HQL_GEN"+ "\n"
		ti+="--Version: 1.0"+ "\n"
		ti+="--Changes:"+ "\n"
		ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
		ti+="\n"+"\n"+"\n"
		ti+="--/* Specify the database name before creating the table */"
		ti+="\n"+"\n"
		ti+="use ${hiveconf:database_name};\n"	
		ti+="\n"+"\n"
		ti+="--/* If exists, Drop the table before creating unless otherwise */"+ "\n"
		ti+="\n"+"\n"
		ti+="DROP TABLE IF EXISTS " +stg_name+"_"+table_name+ "; \n"
		ti+="\n"+"\n"
		ti+="create table if not exists "+stg_name+"_"+table_name + " (" + "\n"
		no_of_cols=len(ft)
		
		counter=1
		
		for seq,details in ft.iteritems():
			#print seq
			#print details		
			col_cnt =0
			#print "chk count "
			for x in details:
				##if col_cnt ==1:
				##    continue
				col_cnt = col_cnt+1
				#print "bef :col chk count "
				#print col_cnt			
				if col_cnt == 1:
					
					#print "col chk count "
					#print col_cnt  			
					ti+="    " + format(x) + " " + "string" + ",\n" 
				
			
		ti+="    " + "source_id          string"+ ",\n"
		ti+="    " + "batch_id           int"+ ",\n"
		ti+="    " + "audit_date         timestamp"+ ",\n"
		ti+="    " + "source_file_table  string"+ "\n"	
		ti+= ")\n"
		ti+= "PARTITIONED BY(country_code string,Created_DATE date)" + "\n"
		ti+= "ROW FORMAT DELIMITED" + "\n"
		ti+= "FIELDS TERMINATED BY '\u0001'" + "\n"
		ti+= "LINES TERMINATED BY '\\n'" + "\n" 
		ti+= "STORED AS TEXTFILE" + "\n"
		ti+= "LOCATION '${hiveconf:base_dir_loc}/"+stg_name+"_"+table_name.lower()+ "';" + "\n"
		#print ti
		writer.write(ti)
		writer.write("\n")	
	#exit()	
	#EZ base views written  on top of tech zone tables
	
	#writer=open("create_ent_hive_base"+".hql","w")
	logging.info('STAGING TABLES CREATED SUCCESSFULLY')
logging.info('TECHNICAL TABLE CREATION STARTED......')
writer=open(hql_folder_path+"\\"+"create_" + tech_name_file + ".hql","w")

for table_name,ft in sorted(table_dict.iteritems()):

	ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
	ti+="--Project: {Project Name} EDL"+ "\n"
	ti+="--Script File Name : "+ "create_" + tech_name + ".hql"+ "\n"
	ti+="--Script Description :"+ "\n"
	ti+="--Database Name:"+ "\n"
	ti+="--Table Name : " + tech_name+"_"+table_name+ "\n"
	ti+="--Table Description : Creation of tech zone table - " +tech_name+"_"+table_name+ "\n"
	ti+="--Details :"+ "\n"
	ti+="--Date : "+ format(datetime.date.today()) + "\n"
	ti+="--Created by : HQL_GEN"+ "\n"
	ti+="--Version: 1.0"+ "\n"
	ti+="--Changes:"+ "\n"
	ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
	ti+="\n"+"\n"+"\n"
	ti+="--/* Specify the database name before creating the table */"
	ti+="\n"+"\n"
	ti+="use ${hiveconf:database_name};\n"	
	ti+="\n"+"\n"
	ti+="--/* If exists, Drop the table before creating unless otherwise */"+ "\n"
	ti+="\n"+"\n"
	ti+="DROP TABLE IF EXISTS " +tech_name+"_"+table_name+ "; \n"
	ti+="\n"+"\n"
	ti+="create table if not exists "+tech_name+"_"+table_name + " (" + "\n"
	no_of_cols=len(ft)
	
	counter=1
	  
	for seq,details in ft.iteritems():
		cnt=1
		prs=""
		scl=""
		chkdeci="N"
		datatp=""
		for x in details:
			#print table_name,col,x
			#print "blue"
			tc=str(format(x))
			if tc=="DECIMAL":
				#print tc
				#print "hi"
				chkdeci="Y"
				datatp=tc
			else:
				if cnt==1:
					colnam=tc
					#print datatp
					#print "loop1"
				elif cnt==3:
					datatp=tc
					#print datatp
					#print "loop1"
				elif cnt==4:
					#print chkdeci
					#print tc
					if chkdeci=="Y" and tc>="0":
						#print "decimal"
						datatp="decimal"
						scl=str(tc)
						#print "hi"
						#print scl 
					#else chkdeci=="Y" and tc=="0":
						#print "int"
						#datatp="int"
						#print "As is from config"
					#else:
					#	print "As is from config"
					#print tc
					
					#print "loop2"
				elif cnt==5:
					#print tc
					if chkdeci=="Y" and tc>="0" and datatp=="decimal":
						prs= tc
						#print prs
					#print "loop3"
			#print cnt
			cnt+=1					
		if datatp=="decimal":
			synt=datatp + " (" + prs + "," + scl+")"
		else:
			synt=datatp

		ti+="    " + colnam + "  " + synt + ",\n"

		    
	ti+="    " + "source_id          string"+ ",\n"
	ti+="    " + "batch_id           int"+ ",\n"
	ti+="    " + "audit_date         timestamp"+ ",\n"
	ti+="    " + "source_file_table  string"+ "\n"	
	ti+= ")\n"
	ti+= "PARTITIONED BY(country_code string,Created_DATE date)" + "\n"
	ti+= "ROW FORMAT DELIMITED" + "\n"
	ti+= "FIELDS TERMINATED BY '\u0001'" + "\n"
	ti+= "LINES TERMINATED BY '\\n'" + "\n" 
	ti+= "STORED AS TEXTFILE" + "\n"
	if flt_file_flg=="y":
		ti+= "LOCATION '${hiveconf:base_dir_loc}/"+stg_name+"_"+table_name.lower()+ "';" + "\n"
	else:	
		ti+= "LOCATION '${hiveconf:base_dir_loc}/"+tech_name+"_"+table_name.lower()+ "';" + "\n"
	#print ti
	writer.write(ti)
	writer.write("\n")	
#exit()	
#EZ base views written  on top of tech zone tables

#writer=open("create_ent_hive_base"+".hql","w")
logging.info('TECHNICAL TABLES CREATED SUCCESSFULLY')
logging.info('ENTERPRISE VIEWS CREATION STARTED......')

writer=open(hql_folder_path+"\\"+"create_" + ent_name_file +".hql","w")

for table_name,ft in table_dict.iteritems():
	
	ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
	ti+="--Project:CEDL EDL"+ "\n"
	ti+="--Script File Name : "+ "create_"+ ent_name + "_" +table_name+"_base.hql "+ "\n"
	ti+="--Script Description :"+ "\n"
	ti+="--Database Name:"+ "\n"
	ti+="--Table Name : "+ ent_name+ "_" + table_name+ "\n"
	ti+="--Table Description : Creation of Ent zone base view - " + ent_name+ "_" + table_name+ "" +"\n"
	ti+="--Details :"+ "\n"
	ti+="--Date : "+ format(datetime.date.today()) + "\n"
	ti+="--Created by : HQL_GEN"+ "\n"
	ti+="--Version: 1.0"+ "\n"
	ti+="--Changes:"+ "\n"
	ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
	ti+="\n"+"\n"+"\n"
	ti+="--/* Specify the database name before creating the view */"
	ti+="\n"+"\n"
	ti+="use ${hiveconf:database_name};\n"	
	ti+="\n"+"\n"
	ti+="--/* If exists, Drop the view before creating unless otherwise */"+ "\n"
	ti+="\n"+"\n"
	if flt_file_flg=="y":
			ti+="CREATE OR REPLACE VIEW " +ent_name+"_"+table_name+ " AS \n"
	else:
		if corrct_view=="y":
			ti+="CREATE OR REPLACE VIEW " +ent_name+"_"+table_name+  "_base" +" AS \n"
		else:
			ti+="CREATE OR REPLACE VIEW " +ent_name+"_"+table_name+ " AS \n"
	no_of_cols=len(ft)
	#print no_of_cols
	count=1
	for seq,details in ft.iteritems():
         #print seq
         #print details		
         col_cnt =0
         #print "chk count "
         for x in details:
            ##if col_cnt ==1:
            ##    continue
            col_cnt = col_cnt+1
            #print "bef :col chk count "
            #print col_cnt			
            if col_cnt == 1:
                
                #print "col chk count "
                #print col_cnt
                if count==1:
                    ti+=" " +"SELECT " + format(x) + "\n"
                else:
                    ti+="   ," + format(x) + "\n"				
                count+=1
	
	ti+="    " + ",source_id"+ "\n"
	ti+="    " + ",batch_id "+ "\n"
	ti+="    " + ",audit_date "+ "\n"
	ti+="    " + ",source_file_table"+"\n"
	ti+="    " + ",country_code"+ "\n"
	ti+="    " + "created_date"+ "\n"
	ti+= "FROM "+tech_name+"_"+table_name+ "\n"
	ti+="    " + "Where "+tech_name+"_"+table_name+".created_date IN (SELECT MAX(created_date) from latam_cntrl_v where country_code = "+ tech_name +"_"+table_name+".country_code and source_id="+"'"+SRC_ID+"'"+");"+ "\n"
	#print ti
	writer.write(ti)
	writer.write("\n")

logging.info('ENTERPRISE VIEWS CREATED SUCCESSFULLY')

if corrct_view=="y":
	logging.info('CORRECTION TABLE CREATION STARTED......')
	writer=open(hql_folder_path+"\\"+"create_" + ent_name_file +"_crrctns.hql","w")
	
	for table_name,ft in sorted(table_dict.iteritems()):
	
		ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
		ti+="--Project: {Project Name} EDL"+ "\n"
		ti+="--Script File Name : "+ "create_" + ent_name + "_crrctns.hql"+ "\n"
		ti+="--Script Description :"+ "\n"
		ti+="--Database Name:"+ "\n"
		ti+="--Table Name : " + ent_name+"_"+table_name+ "_crrctns" + "\n"
		ti+="--Table Description : Creation of tech zone table - " +ent_name+"_"+table_name+ "_crrctns" + "\n"
		ti+="--Details :"+ "\n"
		ti+="--Date : "+ format(datetime.date.today()) + "\n"
		ti+="--Created by : HQL_GEN"+ "\n"
		ti+="--Version: 1.0"+ "\n"
		ti+="--Changes:"+ "\n"
		ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
		ti+="\n"+"\n"+"\n"
		ti+="--/* Specify the database name before creating the table */"
		ti+="\n"+"\n"
		ti+="use ${hiveconf:database_name};\n"	
		ti+="\n"+"\n"
		ti+="--/* If exists, Drop the table before creating unless otherwise */"+ "\n"
		ti+="\n"+"\n"
		ti+="DROP TABLE IF EXISTS " +ent_name+"_"+table_name+ "_crrctns;" + "\n"
		ti+="\n"+"\n"
		ti+="create table if not exists "+ent_name+"_"+table_name + "_crrctns (" + "\n"
		no_of_cols=len(ft)
		#print no_of_cols
		counter=1
		#for col,tp in sorted(ft.iteritems()):
		#    print table_name,col,tp
		
		for seq,details in ft.iteritems():
			cnt=1
			prs=""
			scl=""
			chkdeci="N"
			datatp=""
			for x in details:
				#print table_name,col,x
				#print "blue"
				tc=str(format(x))
				if tc=="DECIMAL":
					#print tc
					#print "hi"
					chkdeci="Y"
					datatp=tc
				else:
					if cnt==1:
						colnam=tc
						#print datatp
						#print "loop1"
					elif cnt==3:
						datatp=tc
						#print datatp
						#print "loop1"
					elif cnt==4:
						#print chkdeci
						#print tc
						if chkdeci=="Y" and tc>="0":
							#print "decimal"
							datatp="decimal"
							scl=str(tc)
							#print "hi"
							#print scl 
						#else chkdeci=="Y" and tc=="0":
							#print "int"
							#datatp="int"
							#print "As is from config"
						#else:
						#	print "As is from config"
						#print tc
						
						#print "loop2"
					elif cnt==5:
						#print tc
						if chkdeci=="Y" and tc>="0" and datatp=="decimal":
							prs= tc
							#print prs
						#print "loop3"
				#print cnt
				cnt+=1					
			if datatp=="decimal":
				synt=datatp + " (" + prs + "," + scl+")"
			else:
				synt=datatp
			#print synt
			ti+="    " + colnam + "  " + synt + ",\n"
			#for col,tp in sorted(ft.iteritems()):
			#    print counter
			#    if counter<no_of_cols:
			#	    print "d1 : ",ti,col,tp
			#	    ti+="    " + col + "  " + tp + ",\n"
			#        counter+=1
			#    else:
			#	    print "d2 : ",ti,col,tp
			#	    ti+="    " + col + "  " + tp + "\n"
				
		ti+="    " + "source_id string"+ ",\n"
		ti+="    " + "batch_id int"+ ",\n"
		ti+="    " + "audit_date timestamp"+ ",\n"
		ti+="    " + "source_file_table string"+ "\n"	
		ti+= ")\n"
		ti+= "PARTITIONED BY(country_code string,Created_DATE date)" + "\n"
		ti+= "ROW FORMAT DELIMITED" + "\n"
		ti+= "FIELDS TERMINATED BY '\u0001'" + "\n"
		ti+= "LINES TERMINATED BY '\\n'" + "\n" 
		ti+= "STORED AS textfile" + "\n"
		ti+= "LOCATION '${hiveconf:base_dir_loc}/"+ent_name+"_"+table_name+"_crrctns" + "';" + "\n"
		#print ti
		writer.write(ti)
		writer.write("\n")	
	logging.info('CORRECTION TABLES CREATED SUCCESSFULLY')

if(pz_flg=="y"):
    logging.info('PRODUCTION VIEWS CREATION STARTED......')

    writer=open(hql_folder_path+"\\"+"create_"+pz_name_file +".hql","w")
    
    for table_name,ft in table_dict.iteritems():
    	
    	ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
    	ti+="--Project: EDL"+ "\n"
    	ti+="--Script File Name : "+ "create_pz_"+ SRC_ID + "_" + Country_Code +"_" + table_name+"_base.hql "+ "\n"
    	ti+="--Script Description :"+ "\n"
    	ti+="--Database Name:"+ "\n"
    	ti+="--Table Name : pz_"+ SRC_ID + "_" + Country_Code + "_" +table_name+ " "+ "\n"
    	ti+="--Table Description : Creation of Prod zone base view - "+Consumer_Zone_Name+table_name+ "_view" +"\n"
    	ti+="--Details :"+ "\n"
    	ti+="--Date : "+ format(datetime.date.today()) + "\n"
    	ti+="--Created by : HQL_GEN"+ "\n"
    	ti+="--Version: 1.0"+ "\n"
    	ti+="--Changes:"+ "\n"
    	ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
    	ti+="\n"+"\n"+"\n"
    	ti+="--/* Specify the database name before creating the view */"
    	ti+="\n"+"\n"
    	ti+="use ${hiveconf:database_name};\n"	
    	ti+="\n"+"\n"
    	ti+="--/* If exists, Drop the view before creating unless otherwise */"+ "\n"
    	ti+="\n"+"\n"
    	ti+="CREATE OR REPLACE VIEW "+table_name+ " AS \n"
    	no_of_cols=len(ft)
    	#print no_of_cols
    	count=1
    	for seq,details in ft.iteritems():
             #print seq
             #print details		
             col_cnt =0
             #print "chk count "
             for x in details:
                ##if col_cnt ==1:
                ##    continue
                col_cnt = col_cnt+1
                #print "bef :col chk count "
                #print col_cnt			
                if col_cnt == 1:
                    
                    #print "col chk count "
                    #print col_cnt
                    if count==1:
                        ti+=" " +"SELECT " + format(x) + "\n"
                    else:
                        ti+="   ," + format(x) + "\n"				
                    count+=1
    	ti+= "FROM "+Technical_Zone_Name+SRC_ID+"_"+table_name+";" + "\n"
    	#print ti
    	writer.write(ti)
    	writer.write("\n")	
    logging.info('PRODUCTION VIEWS CREATED SUCCESSFULLY')

#
#
#PII enabled tables Section
#
#


pii_enabled_tables=[]
pii=""
for table_name,ft in sorted(table_dict.items()):
    #print table_name
    flag=0
    for seq,details in ft.iteritems():
        col_cnt =0
        for x in details:
            if col_cnt == 0:
                col=str(x)
            if col_cnt == 1:
                s_tp=str(x)
            if col_cnt == 2:
                t_tp=str(x)
            if col_cnt == 3:
                scl=str(x)
            if col_cnt == 4:
                prs=str(x)
            if col_cnt == 5:
                pii=str(x)
            col_cnt = col_cnt+1
            
            if(str(pii)=="Y" or str(pii)=="y"):
                flag=1
    if flag==1:
       pii_enabled_tables.append(table_name) 

#print pii_enabled_tables

if not pii_enabled_tables:
	#print("There is no PII Enabled Tables in the Metadata")
	#print("HQL's created")
	logging.info('HQL SCRIPT EXECUTION ENDS SUCCESSFULLY')
	time.sleep(0.9)
else:

	print pii_enabled_tables
	#logging.info('TECHNICAL TABLES FOR PII CREATION STARTED.....')


	writer=open(hql_folder_path+"\\"+"create_" + tech_name_file + "_PII"+".hql","w")

	for record in pii_enabled_tables:

		
		for table_name,ft in sorted(table_dict.items()):

			if(table_name==record):



				ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
				ti+="--Project: EDL"+ "\n"
				ti+="--Script File Name : "+ "create_"+ tech_name +"_"+table_name+"_pii.hql "+ "\n"
				ti+="--Script Description :"+ "\n"
				ti+="--Database Name:"+ "\n"
				ti+="--Table Name : "+ tech_name +"_"+table_name+"_pii"+ "\n"
				ti+="--Table Description : Creation of tech zone table - "+ tech_name +"_"+table_name+"_pii"+ "\n"
				ti+="--Details :"+ "\n"
				ti+="--Date : "+ format(datetime.date.today()) + "\n"
				ti+="--Created by : HQL_GEN"+ "\n"
				ti+="--Version: 1.0"+ "\n"
				ti+="--Changes:"+ "\n"
				ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
				ti+="\n"+"\n"+"\n"
				ti+="--/* Specify the database name before creating the table */"
				ti+="\n"+"\n"
				ti+="use"+" "+SRC_ID+" "+";"+ "\n"	
				ti+="\n"+"\n"
				ti+="--/* If exists, Drop the table before creating unless otherwise */"+ "\n"
				ti+="\n"+"\n"
				ti+="DROP TABLE IF EXISTS "+ tech_name +"_"+table_name+"_pii"+ "; \n"
				ti+="\n"+"\n"
				ti+="create table if not exists "+ tech_name +"_"+table_name +"_pii"+ " (" + "\n"
				no_of_cols=len(ft)
				#print no_of_cols
				counter=1
				#for col,tp in sorted(ft.iteritems()):
				#    print table_name,col,tp
			    
				for seq,details in ft.iteritems():
					cnt=1
					prs=""
					scl=""
					chkdeci="N"
					datatp=""
					for x in details:
						#print table_name,col,x
						#print "blue"
						tc=str(format(x))
						if tc=="DECIMAL":
							#print tc
							#print "hi"
							chkdeci="Y"
							datatp=tc
						else:
							if cnt==1:
								colnam=tc
								#print datatp
								#print "loop1"
							elif cnt==3:
								datatp=tc
								#print datatp
								#print "loop1"
							elif cnt==4:
								#print chkdeci
								#print tc
								if chkdeci=="Y" and tc>="0":
									#print "decimal"
									datatp="decimal"
									scl=str(tc)
									#print "hi"
									#print scl 
								#else chkdeci=="Y" and tc=="0":
									#print "int"
									#datatp="int"
									#print "As is from config"
								#else:
								#	print "As is from config"
								#print tc
								
								#print "loop2"
							elif cnt==5:
								#print tc
								if chkdeci=="Y" and tc>="0" and datatp=="decimal":
									prs= tc
									#print prs
								#print "loop3"
						#print cnt
						cnt+=1					
					if datatp=="decimal":
						synt=datatp + " (" + prs + "," + scl+")"
					else:
						synt=datatp
					#print synt
					ti+="    " + colnam + "  " + synt + ",\n"
					#for col,tp in sorted(ft.iteritems()):
					#    print counter
					#    if counter<no_of_cols:
					#	    print "d1 : ",ti,col,tp
					#	    ti+="    " + col + "  " + tp + ",\n"
					#        counter+=1
					#    else:
					#	    print "d2 : ",ti,col,tp
					#	    ti+="    " + col + "  " + tp + "\n"
					    
				ti+="    " + "source_id string"+ ",\n"
				ti+="    " + "batch_id int"+ ",\n"
				ti+="    " + "audit_date timestamp"+ ",\n"
				ti+="    " + "source_file_table string"+ "\n"	
				ti+= ")\n"
				ti+= "PARTITIONED BY(country_code string,Created_DATE date)" + "\n"
				ti+= "ROW FORMAT DELIMITED" + "\n"
				ti+= "FIELDS TERMINATED BY '\u0001'" + "\n"
				ti+= "LINES TERMINATED BY '\\n'" + "\n" 
				ti+= "STORED AS TEXTFILE" + "\n"
				ti+= "LOCATION '${hiveconf:base_dir_loc}/"+ tech_name +"_"+table_name.lower() +"_pii"+ "';" + "\n"
				#print ti
				writer.write(ti)
				writer.write("\n")	

        logging.info('TECHNICAL TABLES FOR PII CREATED SUCCESSFULLY')
        logging.info('ENT ZONE VIEWS CREATION STARTED FOR PII........')
    

	writer=open(hql_folder_path+"\\"+"create_" + ent_name_file + "_PII"+".hql","w")

	for record in pii_enabled_tables:

		
		for table_name,ft in sorted(table_dict.items()):

			if(table_name==record):



				ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
				ti+="--Project: {} EDL"+ "\n"
				ti+="--Script File Name : "+ "create_"+ ent_name +"_" + table_name+"_pii.hql "+ "\n"
				ti+="--Script Description :"+ "\n"
				ti+="--Database Name:"+ "\n"
				ti+="--Table Name : "+ ent_name +"_"+table_name+ "_pii"+ "\n"
				ti+="--Table Description : Creation of Ent zone base view - "+ ent_name +"_" +table_name+ "_pii" +"\n"
				ti+="--Details :"+ "\n"
				ti+="--Date : "+ format(datetime.date.today()) + "\n"
				ti+="--Created by : HQL_GEN"+ "\n"
				ti+="--Version: 1.0"+ "\n"
				ti+="--Changes:"+ "\n"
				ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
				ti+="\n"+"\n"+"\n"
				ti+="--/* Specify the database name before creating the view */"
				ti+="\n"+"\n"
				ti+="use"+" "+SRC_ID+" "+";"+ "\n"	
				ti+="\n"+"\n"
				ti+="--/* If exists, Drop the view before creating unless otherwise */"+ "\n"
				ti+="\n"+"\n"
				if corrct_view=="y":
					ti+="CREATE OR REPLACE VIEW " +ent_name+"_"+table_name+  "_PII_base" +" AS \n"
				else:
					ti+="CREATE OR REPLACE VIEW " +ent_name+"_"+table_name+ "_PII AS \n"
				no_of_cols=len(ft)
				#print no_of_cols
				count=1
				for seq,details in ft.iteritems():
			         #print seq
			         #print details		
			         col_cnt =0
			         #print "chk count "
			         for x in details:
			            ##if col_cnt ==1:
			            ##    continue
			            col_cnt = col_cnt+1
			            #print "bef :col chk count "
			            #print col_cnt			
			            if col_cnt == 1:
			                
			                #print "col chk count "
			                #print col_cnt
			                if count==1:
			                    ti+=" " +"SELECT " + format(x) + "\n"
			                else:
			                    ti+="   ," + format(x) + "\n"				
			                count+=1
				
				ti+="    " + ",source_id"+ "\n"
				ti+="    " + ",batch_id "+ "\n"
				ti+="    " + ",audit_date "+ "\n"
				ti+="    " + ",source_file_table"+"\n"
				ti+="    " + ",country_code"+ "\n"
				ti+="    " + "created_date"+ "\n"
				ti+= "FROM "+tech_name+"_"+table_name+"_pii"+ "\n"
				ti+="    " + "Where "+tech_name+"_"+table_name+"_pii"+".created_date IN (SELECT MAX(created_date) from latam_cntrl_v where country_code = "+tech_name+"_"+table_name+".country_code and source_id="+"'"+dic_prop.get('source_id')+"'"+");"+ "\n"
				#print ti
				writer.write(ti)
				writer.write("\n")
				logging.info('ENTERPRISE ZONE FOR PII CREATED SUCCESSFULLY')
	if flt_file=="n":
		if corrct_view=="n":
                 logging.info('CORRECTION TABLE CREATION STARTED FOR PII........')
                 writer=open(hql_folder_path+"\\"+"create_" + ent_name_file + "_crrctns_PII"+".hql","w")
                 for record in pii_enabled_tables:
                     for table_name,ft in sorted(table_dict.items()):
		
					if(table_name==record):
		
		
		
						ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
						ti+="--Project: EDL"+ "\n"
						ti+="--Script File Name : "+ "create_"+ ent_name +"_"+table_name+"_crrctns_pii.hql "+ "\n"
						ti+="--Script Description :"+ "\n"
						ti+="--Database Name:"+ "\n"
						ti+="--Table Name : "+ ent_name +"_"+table_name+"_crrctns_pii"+ "\n"
						ti+="--Table Description : Creation of tech zone table - "+ ent_name +"_"+table_name+"_crrctns_pii"+ "\n"
						ti+="--Details :"+ "\n"
						ti+="--Date : "+ format(datetime.date.today()) + "\n"
						ti+="--Created by : HQL_GEN"+ "\n"
						ti+="--Version: 1.0"+ "\n"
						ti+="--Changes:"+ "\n"
						ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
						ti+="\n"+"\n"+"\n"
						ti+="--/* Specify the database name before creating the table */"
						ti+="\n"+"\n"
						ti+="use"+" "+Technical_Zone_DB+" "+";"+ "\n"	
						ti+="\n"+"\n"
						ti+="--/* If exists, Drop the table before creating unless otherwise */"+ "\n"
						ti+="\n"+"\n"
						ti+="DROP TABLE IF EXISTS "+ ent_name +"_"+table_name+"_crrctns_pii"+ "; \n"
						ti+="\n"+"\n"
						ti+="create table if not exists "+ ent_name +"_"+table_name +"_crrctns_pii"+ " (" + "\n"
						no_of_cols=len(ft)
						#print no_of_cols
						counter=1
						#for col,tp in sorted(ft.iteritems()):
						#    print table_name,col,tp
						
						for seq,details in ft.iteritems():
							cnt=1
							prs=""
							scl=""
							chkdeci="N"
							datatp=""
							for x in details:
								#print table_name,col,x
								#print "blue"
								tc=str(format(x))
								if tc=="DECIMAL":
									#print tc
									#print "hi"
									chkdeci="Y"
									datatp=tc
								else:
									if cnt==1:
										colnam=tc
										#print datatp
										#print "loop1"
									elif cnt==3:
										datatp=tc
										#print datatp
										#print "loop1"
									elif cnt==4:
										#print chkdeci
										#print tc
										if chkdeci=="Y" and tc>="0":
											#print "decimal"
											datatp="decimal"
											scl=str(tc)
											#print "hi"
											#print scl 
										#else chkdeci=="Y" and tc=="0":
											#print "int"
											#datatp="int"
											#print "As is from config"
										#else:
										#	print "As is from config"
										#print tc
										
										#print "loop2"
									elif cnt==5:
										#print tc
										if chkdeci=="Y" and tc>="0" and datatp=="decimal":
											prs= tc
											#print prs
										#print "loop3"
								#print cnt
								cnt+=1					
							if datatp=="decimal":
								synt=datatp + " (" + prs + "," + scl+")"
							else:
								synt=datatp
							#print synt
							ti+="    " + colnam + "  " + synt + ",\n"
							#for col,tp in sorted(ft.iteritems()):
							#    print counter
							#    if counter<no_of_cols:
							#	    print "d1 : ",ti,col,tp
							#	    ti+="    " + col + "  " + tp + ",\n"
							#        counter+=1
							#    else:
							#	    print "d2 : ",ti,col,tp
							#	    ti+="    " + col + "  " + tp + "\n"
								
						ti+="    " + "source_id string"+ ",\n"
						ti+="    " + "batch_id int"+ ",\n"
						ti+="    " + "audit_date timestamp"+ ",\n"
						ti+="    " + "source_file_table string"+ "\n"	
						ti+= ")\n"
						ti+= "PARTITIONED BY(country_code string,Created_DATE date)" + "\n"
						ti+= "ROW FORMAT DELIMITED" + "\n"
						ti+= "FIELDS TERMINATED BY '\u0001'" + "\n"
						ti+= "LINES TERMINATED BY '\\n'" + "\n" 
						ti+= "STORED AS TEXTFILE" + "\n"
						ti+= "LOCATION '${hiveconf:base_dir_loc}/"+ ent_name +"_"+table_name.lower() +"_crrctns_pii"+ "';" + "\n"
						#print ti
						writer.write(ti)
						writer.write("\n")	
        logging.info('CORRECTION TABLES FOR PII CREATED SUCCESSFULLY')
        logging.info('PRODUCTION ZONE VIEWS CREATION STARTED FOR PII........')

	writer=open(hql_folder_path+"\\"+pz_name_file+ "_PII"+".hql","w")

	for record in pii_enabled_tables:

		
		for table_name,ft in sorted(table_dict.items()):

			if(table_name==record):



				ti="-------------------------------------------------------------------------------------------------------------------------------"+ "\n"
				ti+="--Project:CEDL EDL"+ "\n"
				ti+="--Script File Name : "+ "create_pz_"+table_name+"_pii.hql "+ "\n"
				ti+="--Script Description :"+ "\n"
				ti+="--Database Name:"+ "\n"
				ti+="--Table Name : ent_"+table_name+ "_pii"+ "\n"
				ti+="--Table Description : Creation of Prod zone base view - pz_"+table_name+ "_vw_pii" +"\n"
				ti+="--Details :"+ "\n"
				ti+="--Date : "+ format(datetime.date.today()) + "\n"
				ti+="--Created by : HQL_GEN"+ "\n"
				ti+="--Version: 1.0"+ "\n"
				ti+="--Changes:"+ "\n"
				ti+="--------------------------------------------------------------------------------------------------------------------------------"+ "\n"
				ti+="\n"+"\n"+"\n"
				ti+="--/* Specify the database name before creating the view */"
				ti+="\n"+"\n"
				ti+="use"+" "+Consumer_Zone_DB+" "+";"+ "\n"	
				ti+="\n"+"\n"
				ti+="--/* If exists, Drop the view before creating unless otherwise */"+ "\n"
				ti+="\n"+"\n"
				ti+="CREATE OR REPLACE VIEW "+table_name+"_PII" " AS \n"
				no_of_cols=len(ft)
				#print no_of_cols
				count=1
				for seq,details in ft.iteritems():
			         #print seq
			         #print details		
			         col_cnt =0
			         #print "chk count "
			         for x in details:
			            ##if col_cnt ==1:
			            ##    continue
			            col_cnt = col_cnt+1
			            #print "bef :col chk count "
			            #print col_cnt			
			            if col_cnt == 1:
			                
			                #print "col chk count "
			                #print col_cnt
			                if count==1:
			                    ti+=" " +"SELECT " + format(x) + "\n"
			                else:
			                    ti+="   ," + format(x) + "\n"				
			                count+=1
				ti+= "FROM tsz_"+SRC_ID+"_"+table_name+"_pii"+";" + "\n"
				#print ti
				writer.write(ti)
				writer.write("\n")	
        logging.info('PRODUCTION ZONE FOR PII CREATED SUCCESSFULLY')
        logging.info('HQLS SCRIPT EXECUTED SUCCESFULLY')