import os
import pandas as pd
import gc



#To get Tables and its related Column Names, Data Type, Scale, Precision,
#Stream Names and PII Flag
table_col_dict={}
def get_table_and_cols(frame):
    frame=frame.reset_index().drop("index",axis=1)
    table_name=frame.table_name.values.tolist()[0]
    if table_name not in table_col_dict:
        table_col_dict[table_name]={}
        for i in range(len(frame)):
            col=frame.loc[i,"column_name"]
            seq=i
            table_col_dict[table_name][seq]=[col]



###############################################################################
#
#DECLARATION SECTION
#
###############################################################################

Input_Metadata_Name=""
SRC_SYS=""
Prj_EPM_Code=""
SRC_ID=""
Country_Code=""
Target_Connection_XML_Path=""
TGT_Schema_Name=""
Technical_Zone_DB=""
Enterprise_Zone_DB=""
Consumer_Zone_DB=""
Technical_Zone_Name=""
Enterprise_Zone_Name=""
Consumer_Zone_Name=""
HDFS_Location=""
Source_Connection_XML_Path=""
SRC_Schema_Name=""
Staging_Zone_Name=""
Staging_Zone_DB=""
Project_Folder=""
Layer_name=""
User_id=""
password=""
edl_folder=""
audit_columns_country_code=""
folder_name = "Output_IIF"
WATCHER_LOC = ""
ARCHIVE_LOC = ""
FILE_TYPE = ""

###############################################################################
#
#Determinig the Base Directory of the project folder
#
###############################################################################

code_base_path = os.getcwd()
b = len(code_base_path)
k=0
g=0
base_path=""
for k in range(1,b):
    c=b-k
    try:
        if("Input" in os.listdir(code_base_path[0:c]) and ("Output" in os.listdir(code_base_path[0:c]))):
            base_path = code_base_path[0:c-1]
            break
    except:
        g=1

###############################################################################
#
#All paths required
#
###############################################################################

input_folder_path = base_path+"\\Input\\"
output_folder_path = base_path+"\\Output\\"
config_prop_path = base_path+"\\Input\\config.properties"
log_file_path = output_folder_path+"IIF.Log"
hql_folder_path = output_folder_path+"HQLs"
streams_fldr = output_folder_path+"STREAMS_XMLs\\"

###############################################################################
#
#READING INPUT FILE AND GETTING THE DATA
#
###############################################################################
file = open(config_prop_path)

for lines in file:
    if("=" in lines):
        lst=lines.split("=")
        if(lst[0] == "Input_Metadata_Name"):
            Input_Metadata_Name=lst[1][:-1].strip()
        if(lst[0] == "Source_System"):
            SRC_SYS=lst[1][:-1].strip()
        if(lst[0] == "Project_EPM_Code"):
            Prj_EPM_Code=lst[1][:-1].strip()
        if(lst[0] == "Source_System_EPM_Code"):
            SRC_ID=lst[1][:-1].strip()
        if(lst[0] == "Table_Naming_Convention_Country_Code"):
            Country_Code=lst[1][:-1].strip()
        if(lst[0] == "Target_Connection_XML_Path"):
            Target_Connection_XML_Path=lst[1][:-1].strip()
        if(lst[0] == "TGT_Schema_Name"):
            TGT_Schema_Name=lst[1][:-1].strip()
        if(lst[0] == "Technical_Zone_DataBase"):
            Technical_Zone_DB=lst[1][:-1].strip()
        if(lst[0] == "Enterprise_Zone_DataBase"):
            Enterprise_Zone_DB=lst[1][:-1].strip()
        if(lst[0] == "Consumer_Zone_DataBase"):
            Consumer_Zone_DB=lst[1][:-1].strip()
        if(lst[0] == "Technical_Zone_Name"):
            Technical_Zone_Name=lst[1][:-1].strip()
        if(lst[0] == "Enterprise_Zone_Name"):
            Enterprise_Zone_Name=lst[1][:-1].strip()
        if(lst[0] == "Consumer_Zone_Name"):
            Consumer_Zone_Name=lst[1][:-1].strip()
        if(lst[0] == "HDFS_Location"):
            HDFS_Location=lst[1][:-1].strip()
        if(lst[0] == "Source_Connection_XML_Path"):
            Source_Connection_XML_Path=lst[1][:-1].strip()
        if(lst[0] == "SRC_Schema_Name"):
            SRC_Schema_Name=lst[1][:-1].strip()
        if(lst[0] == "Staging_Zone_Name"):
            Staging_Zone_Name=lst[1][:-1].strip()
        if(lst[0] == "Staging_Zone_DataBase"):
            Staging_Zone_DB=lst[1][:-1].strip()
        if(lst[0] == "Diyotta_Project_Folder"):
            Project_Folder=lst[1][:-1].strip()
        if(lst[0] == "Diyotta_Layer_name"):
            Layer_name=lst[1][:-1].strip()
        if(lst[0] == "EDL_User_id"):
            User_id=lst[1][:-1].strip()
        if(lst[0] == "EDL_password"):
            password=lst[1][:-1].strip()
        if(lst[0] == "EDL_Output_Location"):
            edl_folder=lst[1][:-1].strip()
        if(lst[0] == "Audit_Columns_Country_Code"):
            audit_columns_country_code=lst[1][:-1].strip()
        if(lst[0] == "FlatFiles_Wathcher_Location"):
            WATCHER_LOC=lst[1][:-1].strip()
        if(lst[0] == "FlatFiles_archive_Location"):
            ARCHIVE_LOC=lst[1][:-1].strip()
        if(lst[0] == "FlatFiles_Input_Files_Type"):
            FILE_TYPE=lst[1][:-1].strip()
            
##############################################################################
#
#Getting the path of the RAW METADATA from CONFIG.PROPERTIES
#
###############################################################################

input_raw_metadata = input_folder_path+Input_Metadata_Name

###############################################################################
#
#Determining the type of INPUT METADATA FILE and Loading it to a Data Frame
#
###############################################################################

int_input_file=""
int_input_file=input_folder_path+"Input.csv"
file_ext =[]
file_ext = input_raw_metadata.rsplit(".",1)[1]

if(file_ext=="xlsx"):
    data_xls = pd.read_excel(input_raw_metadata)
    data_xls.to_csv(int_input_file,encoding='utf-8', index=False) 
    df=pd.read_csv(int_input_file)
elif (file_ext=="csv"):
    df=pd.read_csv(input_raw_metadata)

df.groupby(df.table_name).apply(get_table_and_cols)    
    
del lst
del file_ext
gc.collect()
