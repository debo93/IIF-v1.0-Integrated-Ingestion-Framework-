import sys
import os
from dict_paths import *

########################################
#PATHS DEFINED
########################################

xml_path=edl_folder+"/"+folder_name+"/STREAMS_XMLs"
count_path=edl_folder+"/"+folder_name+"/UT_Check"
env_path=edl_folder+"/"+folder_name+"/STREAMS_XMLs/env_setting.properties"
FILE_PATH=edl_folder+"/"+folder_name+"/STREAMS_XMLs/stream.list"
FILE_PATH_COUNT_SRC=edl_folder+"/"+folder_name+"/UT_Check/src_stream_count.list"
FILE_PATH_COUNT_TGT=edl_folder+"/"+folder_name+"/UT_Check/tgt_stream_count.list"

##############################################################################################
#SCRIPT FOR XML UPLOAD
##############################################################################################

def create_shell(prjct_name,system_name):
    shell_upload="xml_upload.sh"
    shell_1=open(output_folder_path+"\\"+shell_upload,"wb")
    ti=""
    ti+="xml_path="+xml_path+"\n"
    ti+="count_path="+count_path+"\n"
    ti+="env_path="+env_path+"\n"
    
    ti+="####################################################################################################"+"\n"
    ti+="#SOURCING ENVIRONMENTAL PROPERTIES"+"\n"
    ti+="####################################################################################################"+"\n"
    ti+="cd $xml_path"+"\n"
    ti+="chmod 777 *"+"\n"
    ti+="source $env_path"+"\n"
    ti+="#####################################################################################################"+"\n"
    ti+="#INGESTION STREAM IMPORT"+"\n"
    ti+="#####################################################################################################"+"\n"
    ti+="for filename in s_*.xml"+"\n"
    ti+="do"+"\n"
    ti+="dicmd import -u $DI_USER -w $DI_PASSWORD -p $DI_PROJECT -l $DI_LAYER -f $xml_path/$filename"+"\n"
    ti+="echo "+"$filename imported"+"\n"
    ti+="done"+"\n"
    ti+="######################################################################################################"+"\n"
    ti+="#COUNT STREAM IMPORT"+"\n"
    ti+="######################################################################################################"+"\n"
    ti+="cd $count_path"+"\n"
    ti+="chmod 777 *"+"\n"
    ti+="for filename in s_*.xml"+"\n"
    ti+="do"+"\n"
    ti+="dicmd import -u $DI_USER -w $DI_PASSWORD -p $DI_PROJECT -l $DI_LAYER -f $count_path/$filename"+"\n"
    ti+="echo "+"$filename imported"+"\n"
    ti+="done"+"\n"
    shell_1.write(ti)
    return shell_upload

##############################################################################################
#SCRIPT FOR XML EXECUTE
##############################################################################################

def create_shell_exec(prjct_name,system_name):
    shell_exec="xml_exec.sh"
    shell_2=open(output_folder_path+"\\"+shell_exec,"wb")
    ti=""
    ti+="xml_path="+xml_path+"\n"
    ti+="count_path="+count_path+"\n"
    ti+="env_path="+env_path+"\n"
    ti+="FILE_PATH="+FILE_PATH+"\n"
    ti+="FILE_PATH_COUNT_SRC="+FILE_PATH_COUNT_SRC+"\n"
    ti+="FILE_PATH_COUNT_TGT="+FILE_PATH_COUNT_TGT+"\n"
    ti+="####################################################################################################"+"\n"
    ti+="#SOURCING ENVIRONMENTAL PROPERTIES"+"\n"
    ti+="####################################################################################################"+"\n"
    ti+="#cd $xml_path "+"\n"
    ti+="#chmod 777 *"+"\n"
    ti+="source $env_path"+"\n"
    ti+="#######################################################################################"+"\n"
    ti+="#COUNT STREAM EXECUTE"+"\n"
    ti+="#######################################################################################"+"\n"
    ti+="#cd $count_path"+"\n"
    ti+="Groups=`cat ${FILE_PATH_COUNT_SRC}|cut -d '|' -f 2|uniq`\n"
    ti+="#echo $Groups"+"\n"
    ti+="for Group in $Groups"+"\n"
    ti+="do"+"\n"
    ti+="Streams=`cat ${FILE_PATH_COUNT_SRC}|grep -w "+ "\"\|$Group\""+ "|cut -d '|' -f 1`\n"
    ti+="#echo $Streams"+"\n"
    ti+="for Stream_name_COUNT in $Streams"+"\n"
    ti+="do"+"\n"
    ti+="dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name_COUNT"+"\n"
    ti+="echo $Stream_name_COUNT"+"\n"
    ti+="done"+"\n"
    ti+="done"+"\n"
    ti+="#######################################################################################"+"\n"
    ti+="#INGESTION STREAM EXECUTE"+"\n"
    ti+="#######################################################################################"+"\n"
    ti+="Groups=`cat ${FILE_PATH}|cut -d '|' -f 2|uniq`\n"
    ti+="#echo $Groups_1"+"\n"
    ti+="for Group in $Groups"+"\n"
    ti+="do"+"\n"
    ti+="Streams_1=`cat "+"${FILE_PATH}"+"|grep -w "+ "\"\|$Group\""+ "|cut -d '|' -f 1`\n"
    ti+="#echo $Streams_1"+"\n"
    ti+="for Stream_name in $Streams_1"+"\n"
    ti+="do"+"\n"
    ti+="dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name"+"\n"
    ti+="echo $Stream_name"+"\n"
    ti+="done"+"\n"
    ti+="done"+"\n"
    ti+="#######################################################################################"+"\n"
    ti+="#COUNT STREAM EXECUTE"+"\n"
    ti+="#######################################################################################"+"\n"
    ti+="#cd $count_path"+"\n"
    ti+="Groups=`cat ${FILE_PATH_COUNT_TGT}|cut -d '|' -f 2|uniq`\n"
    ti+="#echo $Groups"+"\n"
    ti+="for Group in $Groups"+"\n"
    ti+="do"+"\n"
    ti+="Streams=`cat ${FILE_PATH_COUNT_TGT}|grep -w "+ "\"\|$Group\""+ "|cut -d '|' -f 1`\n"
    ti+="#echo $Streams"+"\n"
    ti+="for Stream_name_COUNT in $Streams"+"\n"
    ti+="do"+"\n"
    ti+="dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name_COUNT"+"\n"
    ti+="echo $Stream_name_COUNT"+"\n"
    ti+="done"+"\n"
    ti+="done"+"\n"

    shell_2.write(ti)
    return shell_exec

if __name__ == '__main__':
    prjct_name=Prj_EPM_Code
    system_name=SRC_SYS
    create_shell(prjct_name,system_name)
    create_shell_exec(prjct_name,system_name)