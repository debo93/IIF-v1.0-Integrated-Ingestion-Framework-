#------------------------------------------------------------------------------ 
#Create tar files and folder for release
#Author :Saby
#Module:Tarels
#ip:metadata frame
#op:tar file,release meta data,ingestion and installer scripts
#Version:0.4
#Modification Log
#Initial Version 23-07-2017
#Added Diyotta xml and env properties pointed to dev upload 25-07-2017
#------------------------------------------------------------------------------     

import os
import shutil
import logging
import glob
from dict_paths import *
import re

#------------------------------------------------------------------------------  
#Initiatlize Global Variables
#------------------------------------------------------------------------------  

logging.basicConfig(filename=log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')

installer_file_name=""
ingestion_file_name=""
config_prp_name =""
envsett_prp_name=""
diyotta_import_file =""

#-----------------------------------------------------------------------------
#DECLARATION OF ENVIRONMENTAL PROPERTIES FILE VARIABLES
#-----------------------------------------------------------------------------

USER_ID=User_id
PASSWORD=password
PROJECT_DIYOTTA=Project_Folder
LAYER_DIYOTTA=Layer_name
#------------------------------------------------------------------------------  
#Function to create tar file folders
#------------------------------------------------------------------------------  

logging.info('RELEASE TAR PY CODE STARTED..')

RELEASE_TAR= output_folder_path+"RELEASE_TAR"
#print(RELEASE_TAR)
stream_imprt_path=output_folder_path + "STREAMS_XMLs"

if not os.path.exists(RELEASE_TAR):
  os.makedirs(RELEASE_TAR)
  logging.info('Release tar creation started..')



def create_rels_folder(tar_name,prjct_name,system_name):
    if not os.path.exists(RELEASE_TAR+"\\"+tar_name):
        os.makedirs(RELEASE_TAR+"\\"+tar_name)
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"bin/" +"installer")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"bin/" +"workflows/"+"diyotta_streams/"+"ingestion")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"bin/" +"workflows/"+"shell_scripts")        
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"conf/"+system_name)
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"lib")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"logs/"+"diyotta_logs/"+"data_ingestion")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"logs/"+"diyotta_logs/"+"transformations")        
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"src/"+system_name+"/"+"enterprise")        
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"src/"+system_name+"/"+"production")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"src/"+system_name+"/"+"staging")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"src/"+system_name+"/"+"technical")
        os.makedirs(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"util")
#------------------------------------------------------------------------------ 
#Function to Create installer script fn
#Inputs are project name- bbcv(eg) and system_name - bc4p
#------------------------------------------------------------------------------ 
def create_installer(prjct_name,system_name):
    installer_file_name=system_name+"_installer.sh"
    ins=open(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"bin/" +"installer"+"\\"+installer_file_name,"w")
    ti=""
    ti=ti+"\n"
    ti= ti+"#!/usr/bin/bash"+"\n"
    ti= ti+"####################################################################"+"\n"
    ti= ti+"#"+"\n"
    ti= ti+"# Title : "+system_name+"_installer.sh"+"\n"
    ti= ti+"# Author : \"GEN\" "+"\n"
    ti= ti+"# Description : Initiate creation of  hive tables for "+prjct_name.upper()+""+"\n"
    ti= ti+"#"+"\n"
    ti= ti+"#####################################################################"+"\n"
    ti=ti+"\n"
    ti=ti+"\n"    
    ti= ti+"dir=$(echo $(pwd) | awk -F\"/"+prjct_name+"/common\" '{print $1}')"+"\n"
    ti= ti+"configfile=$dir/"+prjct_name+"/common/conf/"+system_name+"/config_"+system_name+".properties"+"\n"
    ti= ti+"logfile_name=$dir/"+prjct_name+"/common/logs/"+system_name+"_installer_log_$(date \"+%Y-%m-%d-%H:%M:%S\").log"+"\n"
    ti= ti+"echo \"Check the deployment status in log file\" > $logfile_name"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" "+prjct_name.upper()+" Deployment parameters setting intiated :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" properties file:$configfile\" >> $logfile_name"+"\n"
    ti= ti+"envfile=$dir/"+prjct_name+"/common/conf/"+system_name+"/env_setting.properties"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" environment setting file: $envfile\" >> $logfile_name"+"\n"
    ti= ti+"#Hive details"+"\n"
    ti= ti+"echo \"--------Hive Database details-------\" >> $logfile_name"+"\n"
    ti= ti+"stg_database=$(grep -i 'stg_database' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment staging database name : $stg_database\" >> $logfile_name"+"\n"
    ti= ti+"tsz_database=$(grep -i 'tsz_database' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment tsz database name : $tsz_database\" >> $logfile_name"+"\n"
    ti= ti+"edz_database=$(grep -i 'edz_database' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment edz database name : $edz_database\" >> $logfile_name"+"\n"
    ti= ti+"crz_database=$(grep -i 'crz_database' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment crz database name : $edz_database\" >> $logfile_name"+"\n"
    ti= ti+"# Diyotta environment details"+"\n"
    ti= ti+"echo \"--------Diyotta environment details-------\" >> $logfile_name"+"\n"
    ti= ti+"di_user=$(grep -i 'DI_USER' $envfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment Diyotta user name : $di_user\" >> $logfile_name"+"\n"
    ti= ti+"di_pwd=$(grep -i 'DI_PASSWORD' $envfile | cut -f2 -d'=')"+"\n"
    ti= ti+"di_project=$(grep -i 'DI_INGEST_PROJECT' $envfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment Diyotta project name : $di_project\" >> $logfile_name"+"\n"
    ti= ti+"di_folder=$(grep -i 'DI_INGEST_LAYER' $envfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment Diyotta project folder name to import streams : $di_folder\" >> $logfile_name"+"\n"
    ti= ti+"di_code=$dir/"+prjct_name+"/common/bin/workflows/diyotta_streams/ingestion/*.xml"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment Diyotta code package name : $di_code\" >> $logfile_name"+"\n"
    ti= ti+"#HDFS environment details"+"\n"
    ti= ti+"echo \"--------HDFS environment details-------\" >> $logfile_name"+"\n"
    ti= ti+"hdfs_sp_lz_path=$(grep -i 'hdfs_sp_lz_path' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment hdfs lz path : $hdfs_sp_lz_path\" >> $logfile_name"+"\n"
    ti= ti+"hdfs_sp_tz_path=$(grep -i 'hdfs_sp_tz_path' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment hdfs tz path : $hdfs_sp_tz_path\" >> $logfile_name"+"\n"
    ti= ti+"hdfs_sp_ez_path=$(grep -i 'hdfs_sp_ez_path' $configfile | cut -f2 -d'=')"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" enviroment hdfs ez path : $hdfs_sp_ez_path\" >> $logfile_name"+"\n"
    ti= ti+"base_dir=$(grep -i 'base_dir' $configfile | cut -f2 -d'=' )"+"\n"
    ti= ti+""+system_name+"_script_dir=$base_dir"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" deployment script directory: $"+system_name+"_script_dir\" >> $logfile_name"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" "+prjct_name.upper()+" Deployment parameters setting completed :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"current_date=$(date +'%Y-%m-%d')"+"\n"
    #ti= ti+"#echo \"!echo ---Rolback script "+system_name+"_rollback_script.hql execution started :$(date)\" > "+system_name+"_rollback_script.hql"+"\n"
    #ti= ti+"cat ${"+system_name+"_script_dir}/staging/"+system_name+"_rollback_script.hql > "+system_name+"_rollback_script.hql"+"\n"
    #ti= ti+"echo \"!echo ---Rolback script "+system_name+"_rollback_script.hql execution completed :$(date)\" >> "+system_name+"_rollback_script.hql"+"\n"
    #ti= ti+"hive -f "+system_name+"_rollback_script.hql >> $logfile_name"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" "+prjct_name.upper()+" Deployment hql consolidation started :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"echo \"!echo create_STG_"+system_name.upper()+"_hive_tables.hql excution started : $(date)\" > bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"cat ${"+system_name+"_script_dir}/staging/create_STG_"+system_name.upper()+"_hive_tables.hql|sed s/'${hiveconf:database_name}'/$stg_database/g |sed s~'${hiveconf:base_dir_loc}'~${hdfs_sp_lz_path}~g > bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"echo \"!echo create_STG_"+system_name.upper()+"_hive_tables.hql excution completed successfully: $(date)\" >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"#echo \"!echo create_TSZ_"+system_name.upper()+"_hive_tables.hql excution started : $(date)\" > bigfat_"+prjct_name+"_installer_"+system_name+".hql    "+"\n"
    ti= ti+"cat ${"+system_name+"_script_dir}/technical/create_TSZ_"+system_name.upper()+"_hive_tables.hql  |sed s/'${hiveconf:database_name}'/$tsz_database/g |sed s~'${hiveconf:base_dir_loc}'~${hdfs_sp_tz_path}~g >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"echo \"!echo create_TSZ_"+system_name.upper()+"_hive_tables.hql execution completed successfully:$(date)\" >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"#echo \"!echo create_EDZ_"+system_name.upper()+"_hive_tables.hql excution started : $(date)\" > bigfat_"+prjct_name+"_installer_"+system_name+".hql    "+"\n"
    ti= ti+"cat ${"+system_name+"_script_dir}/enterprise/create_EDZ_"+system_name.upper()+"_hive_base.hql  |sed s/'${hiveconf:database_name}'/$edz_database/g >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"echo \"!echo create_EDZ_"+system_name.upper()+"_hive_base.hql execution completed successfully:$(date)\" >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"#echo \"!echo create_PZ_"+system_name.upper()+"_hive_tables.hql excution started : $(date)\" > bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"cat ${"+system_name+"_script_dir}/production/create_PZ_"+system_name.upper()+"_hive_view.hql  |sed s/'${hiveconf:database_name}'/$crz_database/g >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"echo \"!echo create_PZ_"+system_name.upper()+"_hive_base.hql execution completed successfully:$(date)\" >> bigfat_"+prjct_name+"_installer_"+system_name+".hql"+"\n"
    ti= ti+"echo \""+prjct_name.upper()+" "+prjct_name.upper()+" Deployment hql consolidation completed :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"# Execution of bigfat_"+prjct_name+"_installer_"+system_name+".hql file"+"\n"
    ti= ti+"echo \"Execution of bigfat_"+prjct_name+"_installer_"+system_name+".hql file started :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"hive -f bigfat_"+prjct_name+"_installer_"+system_name+".hql >> $logfile_name"+"\n"
    ti= ti+"echo \"Execution of bigfat_"+prjct_name+"_installer_"+system_name+".hql file completed :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"echo \"--list of Tables/views created :$(date)\" >> $logfile_name"+"\n"
    ti= ti+"hive -e \"use $stg_database; show tables;\" >>$logfile_name"+"\n"
    ti= ti+"hive -e \"use $tsz_database; show tables;\" >>$logfile_name"+"\n"
    ti= ti+"hive -e \"use $edz_database; show tables;\" >>$logfile_name"+"\n"
    ti= ti+"hive -e \"use $crz_database; show tables;\" >>$logfile_name"+"\n"
    ti= ti+"###########################################################################################################################"+"\n"
    ti= ti+"# diyotta stream Import"+"\n"
    ti= ti+"echo $di_user"+"\n"
    ti= ti+"echo $di_pwd"+"\n"
    ti= ti+"echo $di_project"+"\n"
    ti= ti+"echo $di_folder"+"\n"
    ti= ti+"echo $di_code"+"\n"
    ti= ti+"echo \"import of Diyotta code $di_code  started :$(date): user:$di_user,project:$di_project,layer:$di_folder\" >> $logfile_name"+"\n"
    ti= ti+"dicmd import -u $di_user -w $di_pwd -p $di_project -l $di_folder -f $di_code "+"\n"
    ti= ti+"echo \"import of Diyotta code $di_code completed :$(date)\" >> $logfile_name"+"\n"
    ins.write(ti)
    return installer_file_name
#------------------------------------------------------------------------------
#Function to Create ingestion script  script fn
#Inputs are project name- bbcv(eg) and system_name - bc4p
#------------------------------------------------------------------------------    
def create_ingestion_file(prjct_name,system_name):
    ingestion_file_name=prjct_name+"_"+system_name +"_data_ingestion.sh"
    ing=open(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"bin/" +"workflows/"+"shell_scripts"+"\\"+ingestion_file_name,"w")
    ti=""
    ti= "############################################################################"+"\n"
    ti= ti+"# OPERATIONAL INFORMATION"+"\n"
    ti= ti+"# Script Name  : " +prjct_name+"_"+system_name +"_data_ingestion.sh" +"\n"
    ti= ti+"# Function     : Runs Diyotta Stream based on the parameters passed"+"\n"
    ti= ti+"# Frequency    :"+"\n"
    ti= ti+"############################################################################"+"\n"
    ti= ti+"#Initialize variables"+"\n"
    ti= ti+"#!/bin/sh"+"\n"
    ti= ti+"dir=$(echo $(pwd) | awk -F\"/"+prjct_name+"/common\" '{print $1}');"+"\n"
    ti= ti+"env_file=$dir/"+prjct_name+"/common/conf/"+system_name+"/env_setting.properties"+"\n"
    ti= ti+"check_readme_file_Day0=false"+"\n"
    ti= ti+"readme_file=$dir/"+prjct_name+"/common/logs/diyotta_logs/shell_removeme_after_day0_DI.txt"+"\n"
    ti= ti+"if [ -f \"$readme_file\" ];then "+"\n"
    ti= ti+"   echo \"An Initial run\""+"\n"
    ti= ti+"   FILE_PATH=$dir/"+prjct_name+"/common/conf/"+system_name+"/stream_names.list"+"\n"
    ti= ti+"   check_readme_file_Day0=true"+"\n"
    ti= ti+" else "+"\n"
    ti= ti+"   echo \"An Incremental Run\""+"\n"
    ti= ti+"   FILE_PATH=$dir/"+prjct_name+"/common/conf/"+system_name+"/stream_names.list"+"\n"
    ti= ti+" fi"+"\n"
    ti= ti+"source $env_file"+"\n"
    ti= ti+"server_status=\"$(dicmd serverstatus)\""+"\n"
    ti= ti+"echo \"${server_status}\""+"\n"
    ti= ti+"if [[ $server_status == *\"running\"* ]]"+"\n"
    ti= ti+"then"+"\n"
    ti= ti+"  echo \"server status is pass\";"+"\n"
    ti= ti+"  current_time=$(date \"+%Y-%m-%d-%H:%M:%S\")"+"\n"
    ti= ti+"  current_date=$(date \"+%Y-%m-%d\")"+"\n"
    ti= ti+"   if [ ! -d \"$dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date\" ]; then"+"\n"
    ti= ti+"   mkdir $dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date"+"\n"
    ti= ti+"   fi "+"\n"
    ti= ti+"   Groups=`cat ${FILE_PATH}|cut -d '|' -f 2|uniq`"+"\n"
    ti= ti+"   #echo $Groups"+"\n"
    ti= ti+"   for Group in $Groups"+"\n"
    ti= ti+"   do"+"\n"
    ti= ti+"   Streams=`cat ${FILE_PATH}|grep -w \"\|$Group\" |cut -d '|' -f 1`"+"\n"
    ti= ti+"   #echo $Streams"+"\n"
    ti= ti+"   for Stream_name in $Streams"+"\n"
    ti= ti+"   do"+"\n"
    ti= ti+"   dicmd execute -u $DI_USER -w $DI_PASSWORD -c start -p $DI_PROJECT -l $DI_LAYER -s $Stream_name >> $dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date/group_$Group.$current_time.log 2>&1 &"+"\n"
    ti= ti+"   done"+"\n"
    ti= ti+"   wait"+"\n"
    ti= ti+"   if [[ $Group -eq 01 ]]; then "+"\n"
    ti= ti+"    Error_Check=`cat $dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date/group_$Group.$current_time.log|grep \"ExitCode:1\"`"+"\n"
    ti= ti+"    if [ ! -z \"$Error_Check\" ]; then"+"\n"
    ti= ti+"    echo \"Group $Group has failed\""+"\n"
    ti= ti+"cat $dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date/group_$Group.$current_time.log"+"\n"
    ti= ti+"    exit 1"+"\n"
    ti= ti+"    else"+"\n"
    ti= ti+"    echo \"Group $Group has Succeeded\""+"\n"
    ti= ti+"    fi"+"\n"
    ti= ti+"   fi"+"\n"
    ti= ti+"   done"+"\n"
    ti= ti+"   Error_Check=`cat $dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date/group_*.$current_time.log|grep \"ExitCode:1\"`"+"\n"
    ti= ti+"   if [ ! -z \"$Error_Check\" ]; then"+"\n"
    ti= ti+"    echo \"Data Ingestion Failed\""+"\n"
    ti= ti+"cat $dir/"+prjct_name+"/common/logs/diyotta_logs/data_ingestion/D$current_date/group_*.$current_time.log"+"\n"
    ti= ti+"    exit 1"+"\n"
    ti= ti+"   else"+"\n"
    ti= ti+"    echo \"Data Ingestion Successful\" "+"\n"
    ti= ti+"if [[ $check_readme_file_Day0 == *\"true\"* ]]"+"\n"
    ti= ti+"     then"+"\n"
    ti= ti+"     rm $readme_file"+"\n"
    ti= ti+"fi  "+"\n"
    ti= ti+"   fi"+"\n"
    ti= ti+"else"+"\n"
    ti= ti+"  echo \"server status is failed\";"+"\n"
    ti= ti+"fi"+"\n"
    ing.write(ti)
    return ingestion_file_name
#------------------------------------------------------------------------------ 
#Function to Create Config properties for the project .
#------------------------------------------------------------------------------ 
def create_cofigprp_file(prjct_name,system_name):
    config_prp_name="config_"+system_name +".properties"
    conf=open(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"conf/"+system_name+"\\"+config_prp_name,"w")
    ti=""
    ti="###################################################################################################"+"\n"
    ti=ti+ "#"+"\n"
    ti=ti+ "# Title : config_"+system_name +".properties"+"\n"
    ti=ti+ "# Author : GEN"+"\n"
    ti=ti+ "# Description : Initiate creation of  hive tables for "+system_name +""+"\n"
    ti=ti+ "#"+"\n"
    ti=ti+ "###################################################################################################"+"\n"
    ti=ti+ ""+"\n"
    ti=ti+ "# NOTE: Do not add spaces while filling the data"+"\n"
    ti=ti+ "#hdfs_connection_node=hdfs://hd7"+"\n"
    ti=ti+ "#hdfs_sp_lz_path=/data/lz/cpi/tsz/bc4p"+"\n"
    ti=ti+ "#hdfs_sp_tz_path=/data/lz/cpi/tsz/bc4p"+"\n"
    ti=ti+ "#hdfs_sp_ez_path=/data/edz/bc4p/cpi/"+"\n"
    ti=ti+ "#hdfs_ps_pz_path=/data/crz/bb4p/cpi/"+"\n"
    ti=ti+ "#stg_database=tsz_ibs_sbt"+"\n"
    ti=ti+ "#tsz_database=tsz_ibs_sbt"+"\n"
    ti=ti+ "#edz_database=edz_ibs_sbt"+"\n"
    ti=ti+ "#crz_database=crz_bbcv_mis"+"\n"
    ti=ti+ "#base_dir=/app/edlu_bbcv_etlid/bbcv/common/src/bc4p"+"\n"
    ti=ti+ "#xml_path=/app/edlu_bbcv_etlid/bbcv/common/bin/workflows/diyotta_streams/bc4p/ingestion"+"\n"
    ti=ti+ "#env_path=/app/edlu_bbcv_etlid/bbcv/common/conf/bc4p/env_setting.properties"+"\n"
    ti=ti+ "#file_path=/landing1/ib/bc4p/"+"\n"
    ti=ti+ "#log_path=/app/edlu_bbcv_etlid/bbcv/common/logs/diyotta_bc4p/data_ingestion"+"\n"
    conf.write(ti)
    return config_prp_name
#------------------------------------------------------------------------------ 
# Function to Create env_settings properties for the project .
#------------------------------------------------------------------------------ 
def create_envsett_prop(prjct_name,system_name):
    envsett_prp_name="env_setting.properties"
    envset=open(RELEASE_TAR+"\\"+tar_name+"/"+prjct_name+"/"+"common/"+"conf/"+system_name+"\\"+envsett_prp_name,"wb")
    ti=""
    ti=ti+ "export DI_HOME=/hhome/latammisdev/diyotta/dicli"+"\n"
    ti=ti+ "export DI_HOST=sddsvrwm367.scglobaluat.aduat.scotiacapital.com"+"\n"
    ti=ti+ "export DI_PORT=9100"+"\n"
    ti=ti+ "export DI_USER="+USER_ID+"\n"
    ti=ti+ "export DI_PASSWORD="+PASSWORD+"\n"
    ti=ti+ "export DI_LAYER="+LAYER_DIYOTTA+"\n"
    ti=ti+ "export DI_PROJECT="+PROJECT_DIYOTTA+"\n"
    ti=ti+ "export JAVA_HOME=/usr/java/jdk1.8.0_65"+"\n"
    ti=ti+ "export PATH=$JAVA_HOME/bin:$PATH:$DI_HOME/bin"+"\n"
    envset.write(ti)
    return envsett_prp_name
#------------------------------------------------------------------------------ 
#Function for dev import
#------------------------------------------------------------------------------ 
def create_diyota_dev_import(prjct_name,system_name):	
    diyotta_import_file="xml_upload.sh"
    diyimp=open(stream_imprt_path + "\\" + diyotta_import_file,"w")
    ti="xml_path=/hhome/latammisdev/Demo/STREAMS  "+"\n"
    ti=ti+ "env_path=/hhome/latammisdev/Demo/env_setting.properties"+"\n"
    ti=ti+ "cd $xml_path "+"\n"
    ti=ti+ "source $env_path"+"\n"
    ti=ti+ "##path of location of XML"+"\n"
    ti=ti+ "for filename in s_*.xml"+"\n"
    ti=ti+ "do"+"\n"
    ti=ti+ "dicmd import -u "+User_id+" -w "+password+" -p "+Project_Folder+" -l "+Layer_name+" -f $xml_path/$filename  "+"\n"
    ti=ti+ "echo ""$filename imported""#For exporting just use export in place of import in dicmd command"""+"\n"
    ti=ti+ "done"+"\n"
    diyimp.write(ti)
    return diyotta_import_file    
#------------------------------------------------------------------------------ 
#Move files in tar folder
#------------------------------------------------------------------------------ 
def move_files(tar_name,prjct_name,system_name):
    #------Move installer file from local folder to tar ingestion folder
    dummy_flg=0
    files=[]
    files=os.listdir(output_folder_path+"HQLs\\")
    for items in files:
        ext=[]
        pat=[]
        try:
            ext=items.rsplit(".",1)[1]
        except:
            dummy_flg=0        
        pat=re.split('_', items)
        if ext=="hql": 
            if pat[1] in [Technical_Zone_Name]:
                shutil.copy(hql_folder_path+"\\"+items,RELEASE_TAR+"\\"+tar_name+"\\"+prjct_name+"\\"+"common\\"+"src\\"+system_name+"\\"+"technical\\")
            elif pat[1] in [Enterprise_Zone_Name]:
                shutil.copy(hql_folder_path+"\\"+items,RELEASE_TAR+"\\"+tar_name+"\\"+prjct_name+"\\"+"common\\"+"src\\"+system_name+"\\"+"enterprise\\")
            elif pat[1] in [Consumer_Zone_Name]:
                shutil.copy(hql_folder_path+"\\"+items,RELEASE_TAR+"\\"+tar_name+"\\"+prjct_name+"\\"+"common\\"+"src\\"+system_name+"\\"+"production\\")
    shutil.copy(RELEASE_TAR+"\\"+tar_name+"\\"+prjct_name+"\\"+"common\\"+"conf\\"+system_name+"\\"+"env_setting.properties",streams_fldr)
    source_dir=streams_fldr+"\\"
    dest_dir=RELEASE_TAR+"\\"+tar_name+"\\"+prjct_name+"\\"+"common\\"+"bin\\" +"workflows\\"+"diyotta_streams\\"+"ingestion\\"
    for filename in glob.glob(os.path.join(source_dir, '*.*')):
        shutil.copy(filename, dest_dir)
    
if __name__ == '__main__':
    #Inputs from Parameter file
    #inputs for tar and folder creation
    prjct_name=Prj_EPM_Code
    system_name=SRC_ID
    tar_name=prjct_name +"_" +system_name+"_v0.1"
    create_rels_folder(tar_name,prjct_name,system_name)
    installer_file_name=create_installer(prjct_name,system_name)
    #print installer_file_name
    create_ingestion_file(prjct_name,system_name)
    create_cofigprp_file(prjct_name,system_name)
    create_envsett_prop(prjct_name,system_name)
    create_diyota_dev_import(prjct_name,system_name)
    move_files(tar_name,prjct_name,system_name)
logging.info('TAR created SUCCESSFULLY')
