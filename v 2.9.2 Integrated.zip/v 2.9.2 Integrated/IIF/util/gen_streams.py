
###################################################################################################
#
# Title : XML GENERATOR FOR MANUAL FEED
# Author : AVISHEK CHATTERJEE<AC00478691@TECHMAHINDRA.COM>
# Description : CODE FOR CREATION OF MANUAL FEED XMLS 
# System : MANUAL_FEED
#
###################################################################################################

import gc
import os
import logging
from dict_paths import *
import re

table_dict={}   #For storing tables and its related attributes
group_dict={}   #For storing Groups and its related table names\

tgt_conn_id = "250105"
src_conn_id = ""
src_schema = ""
tgt_schema = ""

if(Country_Code!=''):
    country_code=Country_Code
else :
    country_code='_'
quotes = '"'
slash='\\'
f_n=""
logging.basicConfig(filename=log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')    

# SOURCE ATTRIBUTE DATATYPE_ID MAPPING

FILE_to_hive_type_dict_1={}

FILE_to_hive_type_dict_1['VARCHAR']='1212'
FILE_to_hive_type_dict_1['VARCHAR2']='1212'
FILE_to_hive_type_dict_1['VARCHAR3']='1212'
FILE_to_hive_type_dict_1['VARCHAR4']='1212'
FILE_to_hive_type_dict_1['NVARCHAR2']='1212'
FILE_to_hive_type_dict_1['CHARACTER']='1212'
FILE_to_hive_type_dict_1['CHAR']='12'
FILE_to_hive_type_dict_1['INT']='04'
FILE_to_hive_type_dict_1['DATETIME']='93'
FILE_to_hive_type_dict_1['DATE']='91'
FILE_to_hive_type_dict_1['NUMBER']='1212'
FILE_to_hive_type_dict_1['NUMERIC']='1212'
FILE_to_hive_type_dict_1['DECIMAL']='1212'
FILE_to_hive_type_dict_1['FLOAT']='12'
FILE_to_hive_type_dict_1['STRING']='1212'
FILE_to_hive_type_dict_1['INTEGER']='1212'


# TARGET ATTRIBUTE DATATYPE_ID MAPPING

FILE_to_hive_type_dict_2={}

FILE_to_hive_type_dict_2['STRING']='12'
FILE_to_hive_type_dict_2['DECIMAL']='12'
FILE_to_hive_type_dict_2['TIMESTAMP']='93'
FILE_to_hive_type_dict_2['DATE']='91'

def get_table_and_fields(frame):
    frame=frame.reset_index().drop("index",axis=1)
    table_name=frame.table_name.values.tolist()[0]
                
    if table_name not in table_dict:
        table_dict[table_name]={}
                                                
        for i in range(len(frame)):
            col=frame.loc[i,"column_name"]
            s_tp=frame.loc[i,"source_type"]
            s_tp=s_tp.upper()
            t_tp="STRING"
            scl=frame.loc[i,"scale"]
            prs=frame.loc[i,"precision"]
            f_n=frame.loc[i,"flatfile_name"]
            seq=i
            if s_tp in FILE_to_hive_type_dict_1:
                s_tp=FILE_to_hive_type_dict_1[s_tp]
            if t_tp in FILE_to_hive_type_dict_2:
                t_tp=FILE_to_hive_type_dict_2[t_tp]

            table_dict[table_name][seq]=[col,s_tp,t_tp,scl,prs,f_n]
            

#To get Groups and its related Table Names
            
def get_streams_and_table_names(frame):
        frame=frame.reset_index().drop("index",axis=1)
        stream_names=frame.stream_names.values.tolist()[0]
        group_dict[stream_names]={}
        seq=0
        for i in range(len(frame)):
            table_name=frame.loc[i,"table_name"]
            seq=i
            if(table_name not in group_dict.values()):
                group_dict[stream_names][seq]=[table_name]
                        
                                                




df.groupby(df.table_name).apply(get_table_and_fields)
df.groupby(df.stream_names).apply(get_streams_and_table_names)

if not os.path.exists(streams_fldr):
    os.makedirs(streams_fldr)
    logging.info('STREAM PATH CREATED')

for stream_names,ft1 in sorted(group_dict.items()):
    
    cnt1=95539000  #src_attr_Id
    cnt2=95539     #src_obj_id
    cnt3=120753000 #stg_attr_id
    cnt4=120753    #stg_obj_id
    cnt5=95542000  #src_inst_attr_id
    cnt6=95541     #dxmp_id
    cnt7=95543     #tgt_dObj_Inst_Id
    cnt8=95542000  
    cnt9=120753000
    cnt10=95542 #source_ref_id
    dxflow_id=146458
    watcher=146462
    Archive=146461
    dbcmd=124206
    temp_table_lists=[]
    
    writer=open(streams_fldr+"s_"+stream_names+".xml","w")
    
    
    writer.write("<repository rep_Id=\"11\""+ " "+ "fldr_Id=\"-1\""+ " "+ "nm=\"DIREP\""+ " "+ "description=\"DI Repository\""+ " "+ "updateBy=\"rpunuru\""+ " "+ "lastUpdateBy=\"rpunuru\""+ " "+ "updateDt=\"2016-08-24 17:45:34.394 UTC\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "change_Ind=\"N\""+ " "+ "ver=\"36240000\""+ " "+ "exportLevel=\"DXFLOW\""+ " "+ "build_Id=\"2088\""+ " "+ "relVer=\"3.6.0\"" + " "+ "patch_Id=\"005\""+" "+ "global_Fldr_Id=\"-1\""+">")
    writer.write("\n")
    writer.write("<folders>")
    writer.write("\n")
    writer.write("<fldrObject repositoryName=\"DIREP\""+" "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+">")
    writer.write("\n")
    writer.write("<fldr fldr_Id=\"75218\""+ " "+ "nm="+quotes+Project_Folder+quotes+" "+ "description=\"costa rica SGC\""+ " "+ "updateBy=\"Administrator\""+ " "+ "lastUpdateBy=\"Administrator\""+ " "+ "updateDt=\"2017-02-09 21:23:50.985 UTC\""+ " "+ "reusableFlag=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\"" + " "+ "change_Ind=\"N\"" +" "+"/>")
    writer.write("\n")
    writer.write("<dataObjects>\n")
        
    for seq,details in ft1.iteritems():
        table_nm=""
        i=1
        for x in details:
            tc=str(format(x))
            table_nm=tc
            if table_nm not in temp_table_lists:
                temp_table_lists.insert(i,table_nm)
                i=i+1
    
    
    ti=""
    src_id=[]
    tgt_id=[]

    #######################################################################
    #Source Data Object(STAGING TABLE)
    #######################################################################

    for record in temp_table_lists:
        for table_name,ft in sorted(table_dict.items()):
            if(table_name==record):
    
                src_id.append(cnt2)
                no_of_col=len(ft)
                cnt_srt=0
                ti+="<dataObject fldr_Id=\"75218\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm="+"\""+"ingest_cr_bc74\""+">"+ "\n"
                ti+="<dObj dObj_Id="+quotes+str(cnt2)+quotes+" "+ "nm=\""+table_name+"\""+ " "+ "aliasNm=\"LANDING_ZONE\""+ " "+ "description=\"\""+ " "+ "ver=\"9\""+ " "+ "dbTyp_Id=\"3\""+ " "+ "valid_Cd=\"0\""+ " "+ "localFlag=\"N\""+ " "+ "updateBy=\"vradhakrishnan\""+ " "+ "lastUpdateBy=\"vradhakrishnan\""+ " "+ "updateDt=\"2017-04-03 09:24:05.147 UTC\""+ " "+ "dObj_ParamNm=\"$DO_FF_LANDING_ZONE_"+table_name+"\""+ " "+ "codepage=\"7-bit ASCII\""+">"+ "\n"
                ti+="<transient_ScopeFlg>P</transient_ScopeFlg>"+ "\n"
                ti+="<caseSensitiveFlg>N</caseSensitiveFlg>"+ "\n"
                ti+="</dObj>"+ "\n"
                ti+="<attributes>"+ "\n"
                
                for seq,details in ft.iteritems():
                    col_cnt =0
                    for x in details:
                        
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        col_cnt = col_cnt+1
                    ti+="<attribute attr_Id="+ "\""+str(cnt1)+ "\""+" " +"obj_Id="+"\""+str(cnt2)+"\""+ " "+ "attrNm="+ " \""+col+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+s_tp+"\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+"\n"
                    cnt1=cnt1+1
                    cnt_srt=cnt_srt+1
            
                
                ti+="</attributes>"+"\n"
                ti+="<dObj_FlatFile_Property dObj_Id="+quotes+str(cnt2)+quotes+ " "+ "fileType=\"D\""+ " "+ "colDelim=\",\""+ " "+ "rowDelim="+quotes+slash+"n"+quotes+" "+"txtQual=\"DOUBLE\""+ " "+"dateTimeFormat=\"YYYY-MM-DD HH:MM:SS.fffffffff\""+ " "+ "skipRows=\"1\""+ " "+ "escapeChar=\"\""+ " "+ "writeHdrFlag=\"N\""+ " "+ "fileNm=\""+table_name+".csv\""+" "+ "collItemsDelim="+quotes+slash+"002"+quotes+" "+ "mapKeysDelim="+quotes+slash+"003"+quotes+" "+  "nullValue=\"\""+ " "+ "inputFormatClass=\"\""+ " "+ "outputFormatClass=\"\""+ " "+ "orc_Compression=\"NONE\""+ " "+ "orc_Stripe_Size=\"268435456\""+ " "+ "orc_Row_Index_Stride=\"10000\""+ " "+ "orc_Compress_Size=\"262144\""+ " "+ "orc_Create_Index=\"N\""+ " "+ "compression=\"FALSE\""+ " "+ "compressionClass=\"\""+ " "+ "fileFormat=\"\""+ " "+ "convTable=\"Cp037\""+" "+ "distFldSize=\"0\""+ " "+ "newLineSize=\"0\""+ " "+ "serdeJarPath=\"\""+ " "+ "serdeClass=\"com.bizo.hive.serde.csv.CSVSerde\""+ " "+ "serdeProperties=\"\""+ " "+ "rootElmnt=\"root\""+ " "+ "nameSpc=\"\""+ " "+ "compressionType=\"NONE\""+ " "+ "interCompression=\"FALSE\""+ " "+ "interCompressionClass=\"\""+ " "+ "location=\"\""+ " "+ "dateFormat=\"YYYY-MM-DD\""+ " "+ "parq_Dfs_Blocksize=\"256\""+ " "+ "parq_Page_Size=\"65536\""+ " "+ "parq_Dictionary_Page_Size=\"65536\""+ " "+ "parq_Block_Size=\"256\""+ " "+ "parq_Enable_Dictionary=\"Y\""+ " "+ "parq_Compression=\"SNAPPY\""+"/>"+"\n"
                ti+="</dataObject>"+"\n"
                
    #######################################################################
    #Target Data Object(STAGING TABLE)
    #######################################################################
    
    for record in temp_table_lists:
        for table_name,ft in sorted(table_dict.items()):
            if(table_name==record):            
                tgt_id.append(cnt4)
                ti+="<dataObject fldr_Id=\"75287\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm="+quotes+Project_Folder+quotes+">"+ "\n"
                ti+="<dObj dObj_Id="+quotes+str(cnt4)+quotes+ " "+"nm="+quotes+"STG_"+Prj_EPM_Code+country_code+table_name+quotes+" "+ "aliasNm=\"LANDING_ZONE\""+ " "+ "description=\"\""+ " "+ "ver=\"1\""+ " "+ "dbTyp_Id=\"6\""+ " "+ "valid_Cd=\"0\""+ " "+ "localFlag=\"N\""+ " "+ "updateBy=\"lmaddineni\""+ " "+ "lastUpdateBy=\"lmaddineni\""+" "+ "updateDt=\"2017-03-11 07:30:01.906 UTC\""+ " "+ "dObj_ParamNm="+quotes+"$DO_HV_LANDING_ZONE_STG_"+Prj_EPM_Code+"_"+table_name+quotes+" "+ "codepage=\"7-bit ASCII\""+">"+"\n"
                ti+="<transient_ScopeFlg>P</transient_ScopeFlg>"+"\n"
                ti+="<caseSensitiveFlg>N</caseSensitiveFlg>"+"\n"
                ti+="</dObj>"+"\n"
                ti+="<attributes>"+"\n"
                
                cnt_srt=0
            
                for seq,details in ft.iteritems():
                    col_cnt =0
                    for x in details:
                        cnt_srt=0
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        col_cnt = col_cnt+1
                    ti+="<attribute attr_Id="+"\""+str(cnt3)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm="+ " \""+col+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id=\"12\""+" "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+"\n"
                    cnt3=cnt3+1
                    cnt_srt=cnt_srt+1
                
                ti+="<attribute attr_Id="+"\""+str(cnt3+1)+ "\""+ " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"source_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+SRC_ID+"&apos;"+quotes+" "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+1)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+ "\n"
                ti+="<attribute attr_Id="+"\""+str(cnt3+2)+ "\""+ " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"batch_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"04\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$RunId\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+2)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+ "\n"
                ti+="<attribute attr_Id="+"\""+str(cnt3+3)+ "\""+ " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"audit_date\""+ " "+ "attrPrec=\"30\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"93\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentTimeStamp\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+3)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+ "\n"
                ti+="<attribute attr_Id="+"\""+str(cnt3+4)+ "\""+ " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"source_file_table\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"&apos;$$SrcName&apos;\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+4)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+ "\n"
                ti+="<attribute attr_Id="+"\""+str(cnt3+5)+ "\""+ " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"country_code\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"1\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+audit_columns_country_code+"&apos;"+quotes+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+5)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+ "\n"
                ti+="<attribute attr_Id="+"\""+str(cnt3+6)+ "\""+ " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"created_date\""+ " "+ "attrPrec=\"10\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"91\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"2\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentDate\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+6)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+"/>"+ "\n"
                ti+="</attributes>"+ "\n"
                ti+="<dObj_FlatFile_Property dObj_Id="+quotes+str(cnt4)+quotes+" "+ "fileType=\"D\""+ " "+ "colDelim=\"01\""+ " "+ "rowDelim="+quotes+slash+"n"+quotes+" "+ "txtQual=\"\""+ " "+ "dateTimeFormat=\"\""+ " "+ "skipRows=\"-1\""+ " "+ "escapeChar=\"04\""+ " "+ "writeHdrFlag=\"N\""+ " "+ "fileNm="+quotes+"STG_"+Prj_EPM_Code+"_"+table_name+".dat"+quotes+" "+ "collItemsDelim="+quotes+slash+"u0002"+quotes+ " "+ "mapKeysDelim="+quotes+slash+"u0003"+quotes+ " "+ "nullValue=\"NULL\""+ " "+ "inputFormatClass=\"org.apache.hadoop.mapred.TextInputFormat\""+ " "+ "outputFormatClass=\"org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat\""+ " "+ "orc_Compression=\"\""+ " "+ "orc_Stripe_Size=\"-1\""+ " "+ "orc_Row_Index_Stride=\"-1\""+ " "+ "orc_Compress_Size=\"-1\""+" "+ "orc_Create_Index=\"N\""+ " "+ "compression=\"N\""+ " "+ "compressionClass=\"\""+" "+ "fileFormat=\"TEXTFILE\""+" "+ "convTable=\"Cp037\""+" "+ "distFldSize=\"0\""+ " "+ "newLineSize=\"0\""+ " "+ "serdeJarPath=\"\""+ " "+ "serdeClass=\"org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe\""+ " "+ "serdeProperties=\"&quot;separatorChar&quot;=&quot;\u0001&quot;,&quot;quoteChar&quot;=&quot;&apos;&quot;,&quot;escapeChar&quot;=&quot;\u0004&quot;\""+" "+ "rootElmnt=\"root\""+ " "+ "nameSpc=\"\""+ " "+ "compressionType=\"NONE\""+ " "+ "interCompression=\"FALSE\""+ " "+ "interCompressionClass=\"\""+ " "+ "location="+quotes+table_name+".csv"+quotes+" "+ "dateFormat=\"YYYY-MM-DD\""+ " "+ "parq_Dfs_Blocksize=\"256\""+" "+ "parq_Page_Size=\"65536\""+ " "+ "parq_Dictionary_Page_Size=\"65536\""+ " "+ "parq_Block_Size=\"256\""+ " "+ "parq_Enable_Dictionary=\"Y\""+ " "+ "parq_Compression=\"SNAPPY\""+"/>"+ "\n"
                ti+="</dataObject>"+ "\n"
            
                cnt2=cnt2+1
                cnt1=((cnt2)*1000)+1
                cnt4=cnt4+1
                cnt3=((cnt4)*1000)+1
    
    
    
    writer.write(ti)
    ti="</dataObjects>"+ "\n"
    ti+="<dBFuns/>"+ "\n"
    ti+="<udfs/>"+ "\n"
    ti+="<layers>"+ "\n"
    ti+="<layerObject>"+ "\n"
    ti+="<layer layer_Id=\"-1\""+ " "+ "fldr_Id=\"-1\""+ " "+ "nm=\"\""+" "+ "description=\"\""+ " "+ "srt_Order=\"-1\""+ " "+ "updateDt=\"1900-01-01 00:00:00.0 UTC\""+ " "+ "updateBy=\"\""+" "+ "lastUpdateBy=\"\""+" "+ "change_Ind=\"N\""+ "/>"+ "\n"
    ti+="<designs/>"+ "\n"
    ti+="<streams/>"+ "\n"
    ti+="<solutions/>"+ "\n"
    ti+="</layerObject>"+ "\n"
    ti+="<layerObject>"+ "\n"
    ti+="<layer layer_Id=\"66601\""+ " "+ "fldr_Id=\"66600\""+ " "+ "nm=\"Technical_Zone\""+ " "+ "description=\"\""+" "+ "srt_Order=\"1\""+" "+ "updateDt=\"2017-01-28 14:34:27.755 UTC\""+ " "+ "updateBy=\"\""+ " "+ "lastUpdateBy=\"\""+" "+ "change_Ind=\"N\""+"/>"+ "\n"
    ti+="<designs>"+ "\n"
    writer.write(ti)
    ti=""
    
    cnt1=95539000  #src_attr_Id
    cnt2=95539     #src_obj_id
    cnt3=120753000 #stg_attr_id
    cnt4=120753    #stg_obj_id
    cnt5=95542000  #src_inst_attr_id
    cnt6=95541     #dxmp_id
    cnt7=95543     #tgt_dObj_Inst_Id
    cnt8=95542000  
    cnt9=120753000
    cnt10=11111 #source_ref_id
    exp_cnt=33333
    cnt11=(cnt10*1000)
    cnt12=22222#target_ref_id
    
    for record in temp_table_lists:
        for table_name,ft in sorted(table_dict.items()):
            if(table_name==record):
                ti+="<design fldr_Id=\"66600\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+" "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+" "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm="+quotes+Project_Folder+quotes+ " "+ "layerNm=\"Technical_Zone\""+">"+ "\n"
                ti+="<dxMp dxMp_Id=\"95541\""+ " "+ "layer_Id=\"66601\""+ " "+ "nm="+quotes+"d_"+table_name+quotes+" "+ "description=\"\""+ " "+ "ver=\"9\""+ " "+ "nativeDbTyp_Id=\"6\""+ " "+ "reusableFlag=\"N\""+" "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"jkuppuswamy\""+ " "+ "lastUpdateBy=\"jkuppuswamy\""+ " "+ "updateDt=\"2017-03-15 10:11:04.934 UTC\""+ " "+ "change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ "/>"+ "\n"
                ti+="<params/>"+ "\n"
                ti+="<sqlParams/>"+ "\n"
                
                ######################################################################
                #Source INSTANCE OBJECT
                #######################################################################
                
                ti+="<objects>"+ "\n"
                ti+="<source change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+" "+ "ref_Id="+quotes+str(cnt10)+quotes+">"+ "\n"
                ti+="<src_Inst src_Inst_Id="+quotes+str(cnt10)+quotes+" "+ "dxMp_Id=\"95541\""+ " "+ "dObj_Id="+quotes+str(cnt2)+quotes+ " "+ "instNm="+quotes+"SRC_"+table_name+quotes+" "+ "description=\"\""+ " "+ "ver=\"2\""+ " "+ "nativeFlag=\"N\""+ " "+ "srcFltrCnd=\"\""+ " "+ "srcFltrCndValid_Cd=\"0\""+ " "+ "srcSelDistinctFlag=\"N\""+ " "+ "tformCreateFlag=\"N\""+" "+ "srcRowLimit=\"-1\""+ " "+ "pl_Srt_Order=\"0\""+ " "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"jkuppuswamy\""+ " "+ "updateDt=\"2017-03-15 10:11:04.943 UTC\""+ " "+ "normalizeFlg=\"Y\""+ " "+ "processOn=\"DI\""+">"+ "\n"
                ti+="<src_OverrideSql></src_OverrideSql>"+ "\n"
                ti+="<src_OverrideSql_Flg>N</src_OverrideSql_Flg>"+ "\n"
                ti+="</src_Inst>"+ "\n"
                ti+="<attributes>"+ "\n"
            
                cnt_srt=0
             
                for seq,details in ft.iteritems():
                    col_cnt =0
                    for x in details:
                        
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        col_cnt = col_cnt+1
                    ti+="<attribute attr_Id="+ "\""+str(cnt11)+ "\"" +" "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm="+ " \""+col+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+s_tp+"\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id="+ "\""+str(cnt1)+ "\"" + " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id="+ "\""+str(cnt2)+ "\"" + " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+"\n"
                    cnt1=cnt1+1
                    cnt11=cnt11+1
                    cnt_srt=cnt_srt+1
                
                ti+="</attributes>"+ "\n"
                ti+="<derivedAttributes/>"+ "\n"
                ti+="<tx_Inst_Properties/>"+ "\n"
                ti+="<nativeDbTyp_Id>6</nativeDbTyp_Id>"+ "\n"
                ti+="</source>"+ "\n"
    
        ######################################################################
        #Target INSTANCE OBJECT
        #######################################################################
    
    
        cnt11=(cnt10*1000)
        ti+="<target change_Ind=\"N\""+ "  "+ "error_Cd=\"0\""+  " "+ "error_Msg=\"\""+ " "+ "ref_Id="+quotes+str(cnt12)+quotes+">"+ "\n"
        ti+="<tgt_Inst tgt_Inst_Id="+quotes+str(cnt12)+quotes+ " "+ "dxMp_Id=\"95541\""+ " "+ "dObj_Id="+quotes+str(cnt4)+quotes+ " "+ "instNm=\"TGT_"+table_name+ "\""+" "+ "description=\"\""+ " "+ "ver=\"9\""+ " "+ "nativeFlag=\"Y\""+ " "+ "tgtLoadType=\"INS\""+ " "+ "truncFlag=\"Y\""+ " "+  "scdType=\"DATE\""+ " "+ "scdDefStartDt=\"TO_DATE(&apos;01/01/1900&apos;,&apos;MM/DD/YYYY&apos;)\""+ " "+ "scdDefEndDt=\"TO_DATE(&apos;12/31/2099&apos;,&apos;MM/DD/YYYY&apos;)\""+ " "+ "scdDefStartKey=\"19000101\""+ " "+ "scdDefEndKey=\"20991231\""+ " "+ "scdDefStartFlag=\"N\""+ " "+ "scdDefEndFlag=\"Y\""+ " "+ "scdOffset=\"-1\""+ " "+ "pl_Srt_Order=\"0\""+ " "+  "tgt_Srt_Order=\"1\""+ " "+ "tgtCreateFlag=\"N\""+ " "+ "pre_DCmd=\"\""+ " "+ "post_DCmd="+quotes+"msck repair table TSZ_"+Prj_EPM_Code+"_"+table_name+quotes+" "+ "pre_DCmdValid_Cd=\"0\""+ " "+ "post_DCmdValid_Cd=\"0\""+ " "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"mbs\""+ " "+ "updateDt=\"2017-04-14 10:16:27.665 UTC\""+ " "+ "primObjId="+quotes+str(cnt10)+quotes+"/>"+"\n"
        ti+="<tgt_Attr_Lnks>"+ "\n"
       
        for seq,details in ft.iteritems():
            col_cnt =0
            for x in details:
                
                if col_cnt == 0:
                    col=str(x)
                if col_cnt == 1:
                    s_tp=str(x)
                if col_cnt == 2:
                    t_tp=str(x)
                if col_cnt == 3:
                    scl=str(x)
                if col_cnt == 4:
                    prs=str(x)
                col_cnt = col_cnt+1
            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+ " "+"tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3)+"\""+ " "+ "lnk_Obj_Id="+"\""+str(cnt10)+ "\""+ " "+"lnk_Obj_Attr_Id="+"\""+str(cnt11)+ "\""+ " "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+ "/>"+"\n"
            cnt11=cnt11+1
            cnt3=cnt3+1
        ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3+1)+"\""+" "+ "lnk_Obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(exp_cnt*1000)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+ "\n"
        ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3+2)+"\""+" "+ "lnk_Obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(exp_cnt*1000+1)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+ "\n"
        ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3+3)+"\""+" "+ "lnk_Obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(exp_cnt*1000+2)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+ "\n"
        ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3+4)+"\""+" "+ "lnk_Obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(exp_cnt*1000+3)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+ "\n"
        ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3+5)+"\""+" "+ "lnk_Obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(exp_cnt*1000+4)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+ "\n"
        ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt12)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt3+6)+"\""+" "+ "lnk_Obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(exp_cnt*1000+5)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+ "\n"
        ti+="</tgt_Attr_Lnks>"+ "\n"
        ti+="<nativeDbTyp_Id>6</nativeDbTyp_Id>"+ "\n"
        ti+="<mJnr_Inst_Cnds/>"+ "\n"
        ti+="</target>"+ "\n"
        
        ######################################################################
        #DERIVE EXPRESSION (6 AUDIT ATTRIBUTES)
        #######################################################################
        
        ti+="<expression nativeDbTyp_Id=\"6\""+ " "+ "change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+">"+"\n"
        ti+="<expr_Inst expr_Inst_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "nm=\"expression_1\""+ " "+ "description=\"\""+ " "+ "ver=\"3\""+ " "+ "valid_Cd=\"0\""+" "+ "dxMp_Id=\"95541\""+ " "+ "updateBy=\"vradhakrishnan\""+ " "+ "lastUpdateBy=\"vradhakrishnan\""+ " "+ "updateDt=\"2017-04-03 09:24:08.645 UTC\""+"/>"+"\n"
        ti+="<attributes>"+"\n"
        ti+="<attribute attr_Id="+"\""+str(exp_cnt*1000)+ "\""+ " "+ "obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "attrNm=\"source_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+SRC_ID+"&apos;"+quotes+" "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order=\"0\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+ "\n"
        ti+="<attribute attr_Id="+"\""+str(exp_cnt*1000+1)+ "\""+ " "+ "obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "attrNm=\"batch_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"04\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$RunId\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order=\"1\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+ "\n"
        ti+="<attribute attr_Id="+"\""+str(exp_cnt*1000+2)+ "\""+ " "+ "obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "attrNm=\"audit_date\""+ " "+ "attrPrec=\"30\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"93\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentTimeStamp\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order=\"2\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+ "\n"
        ti+="<attribute attr_Id="+"\""+str(exp_cnt*1000+3)+ "\""+ " "+ "obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "attrNm=\"source_file_table\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"&apos;$$SrcName&apos;\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order=\"3\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+ "\n"
        ti+="<attribute attr_Id="+"\""+str(exp_cnt*1000+4)+ "\""+ " "+ "obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "attrNm=\"country_code\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"1\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+audit_columns_country_code+"&apos;"+quotes+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order=\"4\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+ "\n"
        ti+="<attribute attr_Id="+"\""+str(exp_cnt*1000+5)+ "\""+ " "+ "obj_Id="+"\""+str(exp_cnt)+ "\""+ " "+ "attrNm=\"created_date\""+ " "+ "attrPrec=\"10\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"91\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"2\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentDate\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order=\"5\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+"/>"+ "\n"
        ti+="</attributes>"+"\n"
        ti+="</expression>"+"\n"
        ti+="</objects>\n"
        ti+="<dxMp_Fwd_Lnks>\n"
        ti+="<dxMp_Fwd_Lnk dxMp_Id=\"95541\" obj_Id="+"\""+str(exp_cnt)+ "\" fwd_Lnk_Obj_Id="+"\""+str(cnt12)+ "\" grp_Id=\"-1\" fwd_Lnk_Grp_Id=\"-1\" obj_Cd=\"EXPR\" fwd_Lnk_Obj_Cd=\"DOBJIT\" lnkNm=\"\" error_Cd=\"0\" error_Msg=\"\"/>\n"
        ti+="<dxMp_Fwd_Lnk dxMp_Id=\"95541\" obj_Id="+"\""+str(cnt10)+ "\" fwd_Lnk_Obj_Id="+"\""+str(exp_cnt)+ "\" grp_Id=\"-1\" fwd_Lnk_Grp_Id=\"-1\" obj_Cd=\"DOBJIS\" fwd_Lnk_Obj_Cd=\"EXPR\" lnkNm=\"\" error_Cd=\"0\" error_Msg=\"\"/>\n"
        ti+="</dxMp_Fwd_Lnks>\n"
        ti+="<dependent_Ids/>\n"
        ti+="</design>\n"
        cnt10=cnt10+1
        cnt11=(cnt10*1000)+1
        cnt2=cnt2+1
        cnt3=cnt3+1
        cnt1=((cnt2)*1000)+1
        cnt12=cnt12+1
        exp_cnt=exp_cnt+1   
    
    writer.write(ti)
    ti=""
    
    ##############################################################
    #Counters initialisation for watcher,Archive and DB command
    ##############################################################
    
    dxflow_id=146458
    watcher=555555
    Archive=444444
    dbcmd=124206
    dxMp_Inst_Id=146460
    cnt12=22222  
    
    
    ti="</designs>\n"
    ti+="<streams>\n"
    ti+="<stream fldr_Id=\"78287\" lockBy=\"\" mode_Ind=\"W\" change_Ind=\"N\" unlock_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\" fldrNm=\"ingest_cr_bc4p\" isDependent=\"false\">\n"
    ti+="\n"
    ti+="<dxFlow dxFlow_Id=\"82557\""+" "+ "layer_Id=\"66601\""+ " "+ "nm="+quotes+table_name+quotes+" "+ "description=\"\""+" "+ "ver=\"7\""+" "+ "paramFilePath=\"\""+" "+ "paramFileNm=\"\""+" "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"mbs\""+" "+ "lastUpdateBy=\"mbs\""+" "+ "updateDt=\"2017-04-21 14:03:32.568 UTC\""+ " "+ "dxFlow_Type=\"R\""+" "+ "change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+"/>\n"
    ti+="<params/>"+"\n"
    ti+="<sqlParams/>"+"\n"
    ti+="<objects>"+"\n"
    writer.write(ti)
    ti=""
        
    for i in range(0, len(src_id)):
    
        ti+="<taskCommand change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+" "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+">"+"\n"
        ti+="<tCmd_Inst tCmd_Inst_Id="+"\""+str(Archive)+ "\""+ " "+ "nm=\"arhive_file\""+ " "+ "description=\"\""+ " "+ "ver=\"6\""+ " "+ "tCmdScriptPath=\"\""+ " "+ "tCmdScriptNm="+quotes+"mv"+" "+" "+WATCHER_LOC+"/"+table_name+FILE_TYPE+" "+" "+ARCHIVE_LOC+"/"+"Arhive_"+table_name+FILE_TYPE+quotes+" "+ "valid_Cd=\"0\""+ " "+ "dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "flagent_Id=\"3022\""+ " "+ "updateBy=\"jchengamaraju\""+ "lastUpdateBy=\"jchengamaraju\""+ " "+ "updateDt=\"2017-05-11 09:00:20.125 UTC\""+ " "+ "agentGrpInd=\"G\""+ " "+ "disableFlg=\"N\""+ " "+ "success_Codes=\"0,99\""+">"+"\n"
        ti+="<tCmdType>E</tCmdType>"+"\n"
        ti+="</tCmd_Inst>"+"\n"
        ti+="<flagent flagent_Id=\"-1\""+ " "+ "nm=\"\""+ " "+ "description=\"\""+ " "+ "host=\"\""+" "+ "port=\"\""+ " "+ "drFlag=\"Y\""+ " "+ "updateDt=\"1900-01-01 00:00:00.0 UTC\""+ " "+ "updateBy=\"\""+" "+ "error_Cd=\"0\""+" "+ "error_Msg=\"\""+"/>"+"\n"
        ti+="<flagent_Grp flagent_Grp_Id=\"3022\""+ " "+ "nm=\"edl_lin\""+ " "+ "description="+quotes+"Assigned edl_dev_lin to Project"+" "+Project_Folder+ "and edl_bbbf"+quotes+ " "+ "updateDt=\"2017-03-08 13:32:44.667 UTC\""+ " "+ "updateBy=\"Administrator\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+"/>"+"\n"
        ti+="<dxFlow_Obj_Properties>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+" "+ "job_Id="+"\""+str(Archive)+ "\""+" "+ "property_Id=\"-1\""+" "+ "property_Cd=\"JDBC_TRAN_CTL\""+" "+ "property_Nm=\"JDBC_TRAN_CTL\""+" "+ "property_Val=\"N\""+ " "+ "srt_Order=\"-1\""+" "+ "property_Type=\" \""+"/>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+" "+ "job_Id="+"\""+str(Archive)+ "\""" "+ "property_Id=\"-1\""+" "+ "property_Cd=\"LOGGING_LEVEL\""+" "+ "property_Nm=\"LOGGING_LEVEL\""+" "+ "property_Val=\"INFO\""+" "+ "srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+" "+ "job_Id="+"\""+str(Archive)+ "\""+" "+ "property_Id=\"-1\""+" "+ "property_Cd=\"TFORM_CLEANUP\""+" "+ "property_Nm=\"TFORM_CLEANUP\""+" "+ "property_Val=\"Y\""+" "+ "srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="</dxFlow_Obj_Properties>"+"\n"
        ti+="</taskCommand>"+"\n"
        Archive=Archive+1
    
        ######################################################################
        #File watcher Task Command
        #######################################################################
        
        ti+="<taskCommand change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+">"+"\n"
        ti+="<tCmd_Inst tCmd_Inst_Id="+"\""+str(watcher)+ "\""+ " "+ "nm=\"file_watcher\""+ " "+ "description=\"\""+ " "+ "ver=\"7\""+ " "+ "tCmdScriptPath=\"\""+ " "+ "tCmdScriptNm="+quotes+WATCHER_LOC+"/"+str(f_n)+FILE_TYPE+" -w 1"+quotes+ " "+ "valid_Cd=\"0\""+" "+ "dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "flagent_Id=\"3022\""+ " "+ "updateBy=\"jchengamaraju\""+ " "+ "lastUpdateBy=\"jchengamaraju\""+ " "+ "updateDt=\"2017-05-11 07:06:25.724 UTC\""+ " "+ "agentGrpInd=\"G\""+" "+ "disableFlg=\"N\""+ " "+ "success_Codes=\"0,99\""+">"+"\n"
        ti+="<tCmdType>F</tCmdType>"+"\n"
        ti+="</tCmd_Inst>"+"\n"
        ti+="<flagent flagent_Id=\"-1\""+" "+ "nm=\"\""+ " "+ "description=\"\""+ " "+ "host=\"\""+ " "+ "port=\"\""+ " "+ "drFlag=\"Y\""+ " "+ "updateDt=\"1900-01-01 00:00:00.0 UTC\""+ " "+ "updateBy=\"\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+"/>"+"\n"
        ti+="<flagent_Grp flagent_Grp_Id=\"3022\""+ " "+ "nm=\"mx_lin\""+ " "+ "description=\"Assigned edl_dev_lin to Project  ingest_mx_bbcy and edl_bbbf\""+ " "+ "updateDt=\"2017-03-08 13:32:44.667 UTC\""+ " "+ "updateBy=\"Administrator\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+"/>"+"\n"
        ti+="<dxFlow_Obj_Properties>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "job_Id="+"\""+str(watcher)+ "\""+ " "+ "property_Id=\"-1\""+ " "+ "property_Cd=\"JDBC_TRAN_CTL\""+ " "+ "property_Nm=\"JDBC_TRAN_CTL\""+ " "+ "property_Val=\"N\""+ " " +"srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "job_Id="+"\""+str(watcher)+ "\""+ " "+ "property_Id=\"-1\""+ " "+ "property_Cd=\"LOGGING_LEVEL\""+ " "+ "property_Nm=\"LOGGING_LEVEL\""+ " "+ "property_Val=\"INFO\""+ " "+ "srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "job_Id="+"\""+str(watcher)+ "\""+ " "+ "property_Id=\"-1\""+ " "+ "property_Cd=\"TFORM_CLEANUP\""+ " "+ "property_Nm=\"TFORM_CLEANUP\""+ " "+ "property_Val=\"Y\""+ " "+ "srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="</dxFlow_Obj_Properties>"+"\n"
        ti+="</taskCommand>"+"\n"
        watcher=watcher+1
        
        ######################################################################
        #DB command/Audit
        ######################################################################
        
        ti+="<dbCommand change_Ind=\"N\""+" "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+">"+"\n"
        ti+="<dCmd_Inst dxFlow_Id="+"\""+str(dxflow_id)+ "\""+" "+ "dCmd_Inst_Id="+"\""+str(dbcmd)+ "\""+ " "+ "nm="+quotes+table_name+quotes+" "+ "description=\"\""+ " "+ "ver=\"1\""+ " "+ "nativeDbTyp_Id=\"6\""+ " "+ "dCmd="+quotes+"set hive.exec.dynamic.partition=TRUE;&#xd;set hive.exec.dynamic.partition.mode=nonstrict;&#xd;insert into cedl_audit_cntrl_streams partition(created_date,source_id)&#xd;select&#xd;&apos;$$JobName&apos;&#xd;,&apos;stg_"+Prj_EPM_Code+"_"+table_name+"&apos;&#xd;,CASE&#xd; when ::RTSU:"+str(dxMp_Inst_Id)+".Status::=&apos;S&apos; THEN &apos;Success&apos;&#xd; when ::RTSU:"+str(dxMp_Inst_Id)+".Status::=&apos;F&apos; THEN &apos;Failed&apos;&#xd; else &apos;unknown&apos;&#xd; end&#xd;,::RTSU:"+str(dxMp_Inst_Id)+".ReturnCode::&#xd;,$$RunId&#xd;,&apos;$$RunBy&apos;&#xd;,::RTST:"+str(dxMp_Inst_Id)+"."+str(cnt12)+".SourceCount::&#xd;,::RTST:"+str(dxMp_Inst_Id)+"."+str(cnt12)+".TargetCount::&#xd;,::RTST:"+str(dxMp_Inst_Id)+"."+str(cnt12)+".BadCount::&#xd;,$$CurrentTimeStamp&#xd;,$$CurrentDate&#xd;,&apos;bc4p&apos;&#xd;from audit_cntrl_dual;"+quotes+ " "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"vradhakrishnan\""+ " "+ "lastUpdateBy=\"vradhakrishnan\"" + " "+ "updateDt=\"2017-04-03 09:24:10.348 UTC\""+ " "+ "conn_Valid_Cd=\"0\""+ " "+ "disableFlg=\"N\""+ " "+ "fileNm=\"\""+ " "+ "location=\"\""+ " "+ "sqlFileFlg=\"N\""+"/>"+"\n"
        ti+="<conn_Db_Obj_Lnk_Native conn_Id=\"67890\""+ " "+ "dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "dxMp_Inst_Id="+"\""+str(dbcmd)+ "\"" + " "+ "obj_Id=\"1\""+ " "+ "conn_Db_Id=\"67890002\""+ " "+ "obj_Cd=\"NATIVE\""+"/>"+"\n"
        ti+="<conn_Db_Obj_Lnk_Ext conn_Id=\"-1\""+ " "+ "dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "dxMp_Inst_Id="+"\""+str(dbcmd)+ "\""+ " "+ "obj_Id=\"-1\""+ " "+ "conn_Db_Id=\"-1\""+ " "+ "obj_Cd=\"EXT\""+"/>"+"\n"
        ti+="<dxFlow_Obj_Properties>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "job_Id="+"\""+str(dbcmd)+ "\""+ " "+ "property_Id=\"-1\""+ " "+ "property_Cd=\"JDBC_TRAN_CTL\""+ " "+ "property_Nm=\"JDBC_TRAN_CTL\""+ " "+ "property_Val=\"N\""+ " " +"srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "job_Id="+"\""+str(dbcmd)+ "\""+ " "+ "property_Id=\"-1\""+ " "+ "property_Cd=\"LOGGING_LEVEL\""+ " "+ "property_Nm=\"LOGGING_LEVEL\""+ " "+ "property_Val=\"INFO\""+ " "+ "srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "job_Id="+"\""+str(dbcmd)+ "\""+ " "+ "property_Id=\"-1\""+ " "+ "property_Cd=\"TFORM_CLEANUP\""+ " "+ "property_Nm=\"TFORM_CLEANUP\""+ " "+ "property_Val=\"Y\"" + " " "srt_Order=\"-1\""+ " "+ "property_Type=\" \""+"/>"+"\n"
        ti+="</dxFlow_Obj_Properties>"+"\n"
        ti+="</dbCommand>"+"\n"
        
        dbcmd=dbcmd+1
        dxMp_Inst_Id=dxMp_Inst_Id+1
    
    writer.write(ti)
    ti=""
    
    dxMp_Inst_Id=146460
    cnt10=11111 #source_ref_id
    exp_cnt=33333
    cnt11=(cnt10*1000)
    cnt12=22222#target_ref_id
    dxflow_id=146458
    watcher=555555
    Archive=444444
    dbcmd=124206    
    dbcmd_list=[]
    archive_list=[]
    watcher_list=[]
    dxmp_inst=[]
    
    for i in range(0,len(src_id)):
        
        dbcmd_list.append(dbcmd)
        archive_list.append(Archive)
        watcher_list.append(watcher)
        dxmp_inst.append(dxMp_Inst_Id)
        watcher=watcher+1
        Archive=Archive+1
        dbcmd=dbcmd+1
        
        ti+="<designJob change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+">"+"\n"
        ti+="<dxMp_Inst dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+ "\""+ " "+ "dxFlow_Id="+"\""+str(dxflow_id)+ "\""+ " "+ "instNm="+quotes+"d_"+table_name+quotes+ " "+ "description=\"\""+ " "+ "ver=\"29\""+ " "+ "valid_Cd=\"0\""+ " "+ "dxMp_Id=\"95541\""+ " "+"updateBy=\"jchengamaraju\"" + " "+ "lastUpdateBy=\"jchengamaraju\""+ " "+ "updateDt=\"2017-05-11 15:17:17.934 UTC\""+ " "+ "disableFlg=\"N\""+"/>"+"\n"
        ti+="<conn_Db_Obj_Lnks>\n"
        ti+="<Conn_Db_Obj_Lnk conn_Id=\"67890\" dxFlow_Id="+"\""+str(dxflow_id)+ "\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" conn_Db_Id=\"-1\" obj_Cd=\"\"/>\n"
        ti+="<Conn_Db_Obj_Lnk conn_Id=\"74211\" dxFlow_Id="+"\""+str(dxflow_id)+ "\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" conn_Db_Id=\"74211\" obj_Cd=\"DOBJIS\"/>\n"
        ti+="<Conn_Db_Obj_Lnk conn_Id=\"67890\" dxFlow_Id="+"\""+str(dxflow_id)+ "\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt12)+"\" conn_Db_Id=\"67890002\" obj_Cd=\"DOBJIT\"/>\n"
        ti+="</conn_Db_Obj_Lnks>\n"
        
        ti+="<dObj_Inst_Properties>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600000\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"LOADTYPE\" propertyVal=\"HDEXTTBL\" dbTyp_Id=\"3\" srt_Order=\"0\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600000\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"LOADTYPE\" propertyVal=\"HDEXTTBL\" dbTyp_Id=\"3\" srt_Order=\"0\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300000\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_NAME\" propertyVal=\""+str(f_n)+"\" dbTyp_Id=\"3\" srt_Order=\"1\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20700001\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"BATCHSIZE\" propertyVal=\"500000\" dbTyp_Id=\"3\" srt_Order=\"1\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300000\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_NAME\" propertyVal=\""+str(f_n)+"\" dbTyp_Id=\"3\" srt_Order=\"1\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20700001\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"BATCHSIZE\" propertyVal=\"500000\" dbTyp_Id=\"3\" srt_Order=\"1\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300002\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_TYPE\" propertyVal=\"D\" dbTyp_Id=\"3\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600003\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"TRANSFER_TYPE\" propertyVal=\"hadoop\" dbTyp_Id=\"3\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300002\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_TYPE\" propertyVal=\"D\" dbTyp_Id=\"3\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600003\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"TRANSFER_TYPE\" propertyVal=\"hadoop\" dbTyp_Id=\"3\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300015\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_DATA_REF\" propertyVal=\"D\" dbTyp_Id=\"3\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300015\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_DATA_REF\" propertyVal=\"D\" dbTyp_Id=\"3\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300003\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COLUMN_DELIMITER\" propertyVal=\"|\" dbTyp_Id=\"3\" srt_Order=\"4\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300003\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COLUMN_DELIMITER\" propertyVal=\",\" dbTyp_Id=\"3\" srt_Order=\"4\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600100\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"PROFILE\" propertyVal=\"HdfsTextSimple\" dbTyp_Id=\"3\" srt_Order=\"5\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600100\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"PROFILE\" propertyVal=\"HdfsTextSimple\" dbTyp_Id=\"3\" srt_Order=\"5\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300004\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_STYLE\" propertyVal=\"YMD\" dbTyp_Id=\"3\" srt_Order=\"5\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300004\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_STYLE\" propertyVal=\"YMD\" dbTyp_Id=\"3\" srt_Order=\"5\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300009\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TEXT_QUALIFIER\" propertyVal=\"DOUBLE\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600505\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"REJ_REC_DIR\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600101\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"L_FORMAT\" propertyVal=\"TEXT\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300005\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_DELIM\" propertyVal=\"-\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300009\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TEXT_QUALIFIER\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300005\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_DELIM\" propertyVal=\"-\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600505\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"REJ_REC_DIR\" propertyVal=\"SRC_SABANA_MAESTRA_$$AuditId_$$UnitId_$$JobId.bad\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600101\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"L_FORMAT\" propertyVal=\"TEXT\" dbTyp_Id=\"3\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600102\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"FORMATTER\" propertyVal=\"pxfwritable_import\" dbTyp_Id=\"3\" srt_Order=\"7\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600102\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"FORMATTER\" propertyVal=\"pxfwritable_import\" dbTyp_Id=\"3\" srt_Order=\"7\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300006\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_STYLE\" propertyVal=\"24HOUR\" dbTyp_Id=\"3\" srt_Order=\"7\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300006\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_STYLE\" propertyVal=\"24HOUR\" dbTyp_Id=\"3\" srt_Order=\"7\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300007\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_DELIM\" propertyVal=\":\" dbTyp_Id=\"3\" srt_Order=\"8\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600103\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMIT\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"8\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600103\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMIT\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"8\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300007\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_DELIM\" propertyVal=\":\" dbTyp_Id=\"3\" srt_Order=\"8\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600104\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMITTYPE\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300008\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ESC_CHAR\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300008\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ESC_CHAR\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600104\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMITTYPE\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300016\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"SERDE\" propertyVal=\"org.apache.hadoop.hive.serde2.OpenCSVSerde\" dbTyp_Id=\"3\" srt_Order=\"10\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300016\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"SERDE\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"10\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600105\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORTABLE\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"10\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600105\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORTABLE\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"10\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300018\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"PARTITION_EXTRACT_TYPE\" propertyVal=\"NTE\" dbTyp_Id=\"3\" srt_Order=\"11\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300017\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"NO_OF_JDBC_PARTITIONS\" propertyVal=\"2\" dbTyp_Id=\"3\" srt_Order=\"11\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300017\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"NO_OF_JDBC_PARTITIONS\" propertyVal=\"2\" dbTyp_Id=\"3\" srt_Order=\"11\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300018\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"PARTITION_EXTRACT_TYPE\" propertyVal=\"NTE\" dbTyp_Id=\"3\" srt_Order=\"11\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600107\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"GPXFPORT\" propertyVal=\"50070\" dbTyp_Id=\"3\" srt_Order=\"12\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600107\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"GPXFPORT\" propertyVal=\"50070\" dbTyp_Id=\"3\" srt_Order=\"12\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300011\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"IN_REGEXP\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"12\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300011\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"IN_REGEXP\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"12\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300012\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"OUT_FORMAT_STR\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"13\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600108\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXT_TBL_SCOPE\" propertyVal=\"L\" dbTyp_Id=\"3\" srt_Order=\"13\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600108\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXT_TBL_SCOPE\" propertyVal=\"L\" dbTyp_Id=\"3\" srt_Order=\"13\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300012\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"OUT_FORMAT_STR\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"13\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600109\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"CREATE_EXTERNAL_TABLE_FLAG\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"14\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600109\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"CREATE_EXTERNAL_TABLE_FLAG\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"14\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300013\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"SERDEJAR_LOC\" propertyVal=\"hdfs://hd0/tmp/csv-serde-1.1.2-0.11.0-all.jar\" dbTyp_Id=\"3\" srt_Order=\"14\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300013\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"SERDEJAR_LOC\" propertyVal=\"\" dbTyp_Id=\"3\" srt_Order=\"14\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600110\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXTERNAL_TABLE_NAME\" propertyVal=\"SRC_SABANA_MAESTRA\" dbTyp_Id=\"3\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600110\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXTERNAL_TABLE_NAME\" propertyVal=\"instNm\" dbTyp_Id=\"3\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300014\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"LOAD_FROM\" propertyVal=\"remote\" dbTyp_Id=\"3\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300020\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"ENABLE_PARTITION\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300020\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"ENABLE_PARTITION\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300014\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"LOAD_FROM\" propertyVal=\"remote\" dbTyp_Id=\"3\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300010\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"NULLVALUE\" propertyVal=\"NULL\" dbTyp_Id=\"3\" srt_Order=\"16\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600111\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"DATA_LAYOUT_CHECK\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"16\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600111\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"DATA_LAYOUT_CHECK\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"16\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300010\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"NULLVALUE\" propertyVal=\"NULL\" dbTyp_Id=\"3\" srt_Order=\"16\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600112\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"RECORD_SAMPLE\" propertyVal=\"10\" dbTyp_Id=\"3\" srt_Order=\"17\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600112\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"RECORD_SAMPLE\" propertyVal=\"10\" dbTyp_Id=\"3\" srt_Order=\"17\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300032\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"18\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300032\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"18\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600113\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"MAX_REJ_REC\" propertyVal=\"1\" dbTyp_Id=\"3\" srt_Order=\"18\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600113\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"MAX_REJ_REC\" propertyVal=\"1\" dbTyp_Id=\"3\" srt_Order=\"18\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300033\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION_TYPE\" propertyVal=\"gzip\" dbTyp_Id=\"3\" srt_Order=\"19\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300033\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION_TYPE\" propertyVal=\"gzip\" dbTyp_Id=\"3\" srt_Order=\"19\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600115\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"NO_OF_MAPPERS\" propertyVal=\"1\" dbTyp_Id=\"3\" srt_Order=\"20\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600115\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"NO_OF_MAPPERS\" propertyVal=\"1\" dbTyp_Id=\"3\" srt_Order=\"20\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600116\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"SKIP_RECORDS\" propertyVal=\"0\" dbTyp_Id=\"3\" srt_Order=\"21\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600116\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"SKIP_RECORDS\" propertyVal=\"1\" dbTyp_Id=\"3\" srt_Order=\"21\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600117\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"MIN_SPLIT_SIZE\" propertyVal=\"8388608\" dbTyp_Id=\"3\" srt_Order=\"22\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600117\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"MIN_SPLIT_SIZE\" propertyVal=\"8388608\" dbTyp_Id=\"3\" srt_Order=\"22\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600502\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"REJ_EXC_LENGTH\" propertyVal=\"n\" dbTyp_Id=\"3\" srt_Order=\"26\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600502\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"REJ_EXC_LENGTH\" propertyVal=\"n\" dbTyp_Id=\"3\" srt_Order=\"26\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600503\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"OUTPUT_FILE_DELIM\" propertyVal=\"01\" dbTyp_Id=\"3\" srt_Order=\"27\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600503\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"OUTPUT_FILE_DELIM\" propertyVal=\"01\" dbTyp_Id=\"3\" srt_Order=\"27\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600504\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"DTYPEVALIDCHECK\" propertyVal=\"n\" dbTyp_Id=\"3\" srt_Order=\"28\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600504\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"DTYPEVALIDCHECK\" propertyVal=\"n\" dbTyp_Id=\"3\" srt_Order=\"28\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600506\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"TRIM_SPACE\" propertyVal=\"Y\" dbTyp_Id=\"3\" srt_Order=\"29\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"20600506\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"TRIM_SPACE\" propertyVal=\"Y\" dbTyp_Id=\"3\" srt_Order=\"29\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300021\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_FLAG\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"50\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300021\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_FLAG\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"50\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300022\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_DIRECTORY_EXTENSION\" propertyVal=\"$$ArchFileDir\" dbTyp_Id=\"3\" srt_Order=\"51\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300022\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_DIRECTORY_EXTENSION\" propertyVal=\"$$ArchFileDir\" dbTyp_Id=\"3\" srt_Order=\"51\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300023\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_THRESHOLD\" propertyVal=\"0\" dbTyp_Id=\"3\" srt_Order=\"52\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300023\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_THRESHOLD\" propertyVal=\"0\" dbTyp_Id=\"3\" srt_Order=\"52\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300026\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"STATISTICS\" propertyVal=\"ON\" dbTyp_Id=\"3\" srt_Order=\"53\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300026\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"STATISTICS\" propertyVal=\"ON\" dbTyp_Id=\"3\" srt_Order=\"53\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300034\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_FAIL_FLAG\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"54\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300034\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_FAIL_FLAG\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"54\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300027\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_FAIL_DIRECTORY_EXTENSION\" propertyVal=\"$$ArchFileDir\" dbTyp_Id=\"3\" srt_Order=\"55\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300027\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ARCHIVE_FAIL_DIRECTORY_EXTENSION\" propertyVal=\"$$ArchFileDir\" dbTyp_Id=\"3\" srt_Order=\"55\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300029\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"56\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300029\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"56\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300030\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION_TYPE\" propertyVal=\"AES-128\" dbTyp_Id=\"3\" srt_Order=\"57\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300030\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION_TYPE\" propertyVal=\"AES-128\" dbTyp_Id=\"3\" srt_Order=\"57\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300031\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTED_AES_SECRET_KEY\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"58\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300031\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTED_AES_SECRET_KEY\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"58\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300035\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"CONVERT_TO_UTF8\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"59\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300035\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"CONVERT_TO_UTF8\" propertyVal=\"N\" dbTyp_Id=\"3\" srt_Order=\"59\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300036\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id="+"\""+str(cnt10)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_ENCODING\" propertyVal=\"iso-8859-1\" dbTyp_Id=\"3\" srt_Order=\"60\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" property_Id=\"10300036\" dxMp_Inst_Id="+"\""+str(dxMp_Inst_Id)+"\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_ENCODING\" propertyVal=\"iso-8859-1\" dbTyp_Id=\"3\" srt_Order=\"60\" defView=\"Y\"/>\n"
        ti+="</dObj_Inst_Properties>\n"
        ti+="<dxFlow_Obj_Properties>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000002\" property_Cd=\"LOGGING_LEVEL\" property_Nm=\"Logging Level\" property_Val=\"INFO\" srt_Order=\"1\" property_Type=\"O\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000003\" property_Cd=\"TFORM_CLEANUP\" property_Nm=\"Tform Cleanup\" property_Val=\"Y\" srt_Order=\"2\" property_Type=\"O\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id=\"248008\" property_Id=\"900068\" property_Cd=\"hive.exec.dynamic.partition\" property_Nm=\"hive.exec.dynamic.partition\" property_Val=\"TRUE\" srt_Order=\"2\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id=\"248008\" property_Id=\"900069\" property_Cd=\"hive.exec.dynamic.partition.mode\" property_Nm=\"hive.exec.dynamic.partition.mode\" property_Val=\"nonstrict\" srt_Order=\"2\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000020\" property_Cd=\"COMPRESSION_CODEC\" property_Nm=\"Compression Codec\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000019\" property_Cd=\"COMPRESSION_TYPE\" property_Nm=\"Compression Type\" property_Val=\"NONE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000005\" property_Cd=\"ESCAPE_CHARECTER\" property_Nm=\"Escape charecter\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000004\" property_Cd=\"FIELD_DELIMITER\" property_Nm=\"Field Delimiter\" property_Val=\"01\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000010\" property_Cd=\"FILE_FORMAT\" property_Nm=\"File Format\" property_Val=\"ORC\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900003\" property_Cd=\"hive.auto.convert.sortmerge.join\" property_Nm=\"hive.auto.convert.sortmerge.join\" property_Val=\"NA\" srt_Order=\"3\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000022\" property_Cd=\"INTERMEDIATE_COMPRESSION_CODEC\" property_Nm=\"Intermediate Compression Codec\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000018\" property_Cd=\"COMPRESSION\" property_Nm=\"Compression\" property_Val=\"FALSE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000015\" property_Cd=\"ORC_COMPRESSION_SIZE\" property_Nm=\"Orc Compression Size\" property_Val=\"262144\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000011\" property_Cd=\"ORC_COMPRESSION_TYPE\" property_Nm=\"Orc Compression Type\" property_Val=\"ZLIB\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000014\" property_Cd=\"ORC_CREATE_INDEX\" property_Nm=\"Orc Create Index\" property_Val=\"FALSE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000013\" property_Cd=\"ORC_ROW_INDEX_STRIDE\" property_Nm=\"Orc Row Index Stride\" property_Val=\"10000\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000012\" property_Cd=\"ORC_STRIPE_SIZE\" property_Nm=\"Orc Stripe Size\" property_Val=\"268435456\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000017\" property_Cd=\"OUTPUT_FORMAT_CLASS\" property_Nm=\"Output Format Class\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000016\" property_Cd=\"INPUT_FORMAT_CLASS\" property_Nm=\"Input Format Class\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000021\" property_Cd=\"INTERMEDIATE_COMPRESSION\" property_Nm=\"Intermediate Compression\" property_Val=\"FALSE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000006\" property_Cd=\"COLLECTION_ITEMS_DELIMITER\" property_Nm=\"Collections Items Delimiter\" property_Val=\"\\002\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000008\" property_Cd=\"LINE_DELIMITER\" property_Nm=\"Line Delimiter\" property_Val=\"\\n\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000007\" property_Cd=\"MAP_KEYS_DELIMITER\" property_Nm=\"Map keys Delimiter\" property_Val=\"\\003\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"10000009\" property_Cd=\"NULL_VALUE\" property_Nm=\"Null Value\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900004\" property_Cd=\"hive.optimize.bucketmapjoin\" property_Nm=\"hive.optimize.bucketmapjoin\" property_Val=\"NA\" srt_Order=\"4\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900006\" property_Cd=\"hive.optimize.bucketmapjoin.sortedmerge\" property_Nm=\"hive.optimize.bucketmapjoin.sortedmerge\" property_Val=\"NA\" srt_Order=\"5\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900007\" property_Cd=\"hive.auto.convert.sortmerge.join.noconditionaltask\" property_Nm=\"hive.auto.convert.sortmerge.join.noconditionaltask\" property_Val=\"NA\" srt_Order=\"6\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900008\" property_Cd=\"hive.auto.convert.sortmerge.join.bigtable.selection.policy\" property_Nm=\"hive.auto.convert.sortmerge.join.bigtable.selection.policy\" property_Val=\"NA\" srt_Order=\"7\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900011\" property_Cd=\"mapred.map.output.compression.codec\" property_Nm=\"mapred.map.output.compression.codec\" property_Val=\"NA\" srt_Order=\"10\" property_Type=\"S\"/>\n"
        ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id="+"\""+str(dxMp_Inst_Id)+"\" property_Id=\"900013\" property_Cd=\"mapred.output.compression.type\" property_Nm=\"mapred.output.compression.type\" property_Val=\"NA\" srt_Order=\"12\" property_Type=\"S\"/>\n</dxFlow_Obj_Properties>\n<rce_DxMpUnits/>\n<rce_DxMpUnit_OVs/>\n<params/>\n</designJob>\n"
        dxMp_Inst_Id=dxMp_Inst_Id+1
        
     
    ti+="</objects>\n"
    ti+="<dxFlow_Fwd_Lnks>\n"
    
    for a in range(0,len(watcher_list)):
        ti+="<dxFlow_Fwd_Lnk dxFlow_Id="+"\""+str(dxflow_id)+ "\" obj_Id="+"\""+str(watcher_list[a])+ "\" fwd_Lnk_Obj_Id="+"\""+str(dxmp_inst[a])+"\" obj_Cd=\"TCMD\" fwd_Lnk_Obj_Cd=\"DXMPI\" lnkCndVal=\"::RTSU:146462.Status::=&apos;SUCCEEDED&apos;\" lnkCndValid_Cd=\"0\"/>\n"
    
    for b in range(0,len(watcher_list)):
        ti+="<dxFlow_Fwd_Lnk dxFlow_Id="+"\""+str(dxflow_id)+ "\" obj_Id="+"\""+str(dxmp_inst[b])+"\" fwd_Lnk_Obj_Id="+"\""+str(dbcmd_list[b])+ "\" obj_Cd=\"DXMPI\" fwd_Lnk_Obj_Cd=\"DCMD\" lnkCndVal=\"::RTSU:146460.Status::=&apos;SUCCEEDED&apos;\" lnkCndValid_Cd=\"0\"/>\n"
    
    for c in range(0,len(watcher_list)):
        
        ti+="<dxFlow_Fwd_Lnk dxFlow_Id="+"\""+str(dxflow_id)+ "\" obj_Id="+"\""+str(dbcmd_list[c])+ "\" fwd_Lnk_Obj_Id="+"\""+str(archive_list[c])+ "\" obj_Cd=\"DCMD\" fwd_Lnk_Obj_Cd=\"TCMD\" lnkCndVal=\"::RTSU:124206.Status::=&apos;SUCCEEDED&apos;\" lnkCndValid_Cd=\"0\"/>\n"
    
    ti+="</dxFlow_Fwd_Lnks>\n"
    cnt10=cnt10+1
    cnt12=cnt12+1
    writer.write(ti)
    ti=""
    dxflow_id=146458
    
    
    ti="<dxFlow_Obj_Properties>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id=\"-1\" property_Id=\"-1\" property_Cd=\"JDBC_TRAN_CTL\" property_Nm=\"JDBC_TRAN_CTL\" property_Val=\"N\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id=\"-1\" property_Id=\"-1\" property_Cd=\"LOGGING_LEVEL\" property_Nm=\"LOGGING_LEVEL\" property_Val=\"INFO\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id="+"\""+str(dxflow_id)+ "\" job_Id=\"-1\" property_Id=\"-1\" property_Cd=\"TFORM_CLEANUP\" property_Nm=\"TFORM_CLEANUP\" property_Val=\"Y\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="</dxFlow_Obj_Properties>\n"
    ti+="<dependent_Ids>\n"
    
    for i in range(0,len(tgt_id)):
        ti+="<long>"+str(src_id[i])+"</long>\n"
        ti+="<long>"+str(tgt_id[i])+"</long>\n"
        ti+="<long>"+str(dxmp_inst[i])+"</long>\n"
    
    ti+="<long>74211</long>\n"
    ti+="<long>67890</long>\n"
    ti+="</dependent_Ids>\n"
    ti+="</stream>\n"
    ti+="</streams>\n"
    ti+="<solutions/>\n"
    ti+="</layerObject>\n"
    ti+="</layers>\n"
    ti+="<connections>\n"
    ti+="<repConn fldr_Id=\"66600\" lockBy=\"\" mode_Ind=\"W\" unlock_Ind=\"N\" change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\" reusableFlag=\"N\" isDependent=\"true\" isLinkExist=\"false\" fldrNm=\"ingest_mx_bbcy\">\n"
    ti+="          <conn conn_Id=\"250105\" nm=\"TEST_HDP_HD0_POC\" aliasNm=\"HADOOP\" host=\"sddsvrwm369.scglobaluat.aduat.scotiacapital.com\" port=\"10000\" nativeFlag=\"Y\" connParamNm=\"$CN_HV_HADOOP_TEST_HDP_HD0_POC\" dbTyp_Id=\"6\" connType=\"Hive\" ver=\"2\" description=\"\" valid_Cd=\"0\" updateDt=\"2017-07-24 14:11:47.191 UTC\" updateBy=\"Administrator\" hdfshost=\"sddsvrwm367.scglobaluat.aduat.scotiacapital.com\" hdfsport=\"8020\" wrhloc=\"\" hadoop_Dist=\"Hortonworks\" flagent_Id=\"3022\" fileloc=\"$$SrcFileDir\" ftpFlag=\"N\" ftpHost=\"\" ftpPort=\"\" ftpUsr=\"\" ftpPasswd=\"\" fileProtocol=\"FTP\" secAuth=\"Kerberos\" hive_Principal=\"hive/sddsvrwm369.scglobaluat.aduat.scotiacapital.com@SCGLOBALUAT.ADUAT.SCOTIACAPITAL.COM\" user_Principal=\"dev_bbcv_etl@SCGLOBALUAT.ADUAT.SCOTIACAPITAL.COM\" secKeyTab=\"/app/dev_bbcv_etl/keytab/dev_bbcv_etl.keytab\" secToken=\"\" url=\"https://www.salesforce.com/services/Soap/c/23.0\" dbVersion=\"2.5.5\" exe_Engine=\"tez\" hdfs_Temp_Loc=\"/user/dev_bbcv_etl\" yarnRMHost=\"sddsvrwm368.scglobaluat.aduat.scotiacapital.com\" yarnRMPort=\"8050\" mrJobHistHost=\"sddsvrwm369.scglobaluat.aduat.scotiacapital.com\" mrJobHistPort=\"10020\" hdfsPrincipal=\"dn/sddsvrwm368.scglobaluat.aduat.scotiacapital.com@SCGLOBALUAT.ADUAT.SCOTIACAPITAL.COM\" yarnPrincipal=\"rm/sddsvrwm368.scglobaluat.aduat.scotiacapital.com@SCGLOBALUAT.ADUAT.SCOTIACAPITAL.COM\" mapRedPrincipal=\"jhs/sddsvrwm369.scglobaluat.aduat.scotiacapital.com@SCGLOBALUAT.ADUAT.SCOTIACAPITAL.COM\" hdfs_Location=\"/tmp\" jobTracker_Host=\"\" jobTracker_Port=\"\" agentGrpInd=\"G\" dbAliasNm=\"\" hbase_Master_Host=\"\" hbase_Master_Port=\"\" zookeeper_Quorum_Host=\"\" zookeeper_Client_Port=\"\" hbase_Location=\"\" spark_WebUrl_Port=\"\" zookeeper_Znode_Parent=\"/hbase\" consumerKey=\"\" consumerSecret=\"\" accessToken=\"\" accessTokenSecret=\"\" queueNm=\"int_default\" kerb_Server=\"scvmuatdc102.scglobaluat.aduat.scotiacapital.com\" kdc_Host=\"scvmuatdc102.scglobaluat.aduat.scotiacapital.com\" default_Releam=\"SCGLOBALUAT.ADUAT.SCOTIACAPITAL.COM\" archive_Dir_Flg=\"N\" archive_Dir_Loc=\"$$ArchFileDir\">"
    ti+="            <hiveServe2HACnf_Flg>N</hiveServe2HACnf_Flg>"
    ti+="            <dfsHAConfig_Flg>Y</dfsHAConfig_Flg>"
    ti+="            <dfsNameService>hd0</dfsNameService>"
    ti+="            <nameNodeIDs>nn1,nn2</nameNodeIDs>"
    ti+="            <rpcAddrNameNodeID1>sddsvrwm368.scglobaluat.aduat.scotiacapital.com:8020</rpcAddrNameNodeID1>"
    ti+="            <rpcAddrNameNodeID2>sddsvrwm369.scglobaluat.aduat.scotiacapital.com:8020</rpcAddrNameNodeID2>"
    ti+="            <zookeeperNameSpace></zookeeperNameSpace>"
    ti+="            <amazonS3Host></amazonS3Host>"
    ti+="            <bucketNm></bucketNm>"
    ti+="            <tempLoc_Azs3></tempLoc_Azs3>"
    ti+="            <amzon_s3_mount></amzon_s3_mount>"
    ti+="            <clusterNm></clusterNm>"
    ti+="            <jmsProvider>JMS</jmsProvider>"
    ti+="            <jmsProviderURL></jmsProviderURL>"
    ti+="            <destinationType>Topic</destinationType>"
    ti+="            <destinationNm></destinationNm>"
    ti+="            <connectionFactory></connectionFactory>"
    ti+="            <sparkMode></sparkMode>"
    ti+="            <sparkYarnJarLocation></sparkYarnJarLocation>"
    ti+="            <hadoop_Conf_Path>$DI_HOME/app/control/hadoop/conf</hadoop_Conf_Path>"
    ti+="            <hdfs_SecAuth>Kerberos</hdfs_SecAuth>"
    ti+="            <sftpAuthMode></sftpAuthMode>"
    ti+="            <pvtKeyFileNm></pvtKeyFileNm>"
    ti+="          </conn>"
    ti+="          <conn_Dbs>"
    ti+="            <conn_Db conn_Id=\"250105\" conn_Db_Id=\"250105000\" nm=\"dyota_pilot\" description=\"\" databaseNm=\"default\" dbParamNm=\"$DB_HV_HADOOP_TEST_HDP_HD0_POC_DYOTA_PILOT\" schemaNm=\"\" schemaParamNm=\"$SC_HV_HADOOP_TEST_HDP_HD0_POC_DYOTA_PILOT_\" stgDb_Flag=\"N\" srt_Order=\"0\" updateDt=\"2017-07-24 14:11:47.352 UTC\" updateBy=\"srana1\"/>"
    ti+="            <conn_Db conn_Id=\"250105\" conn_Db_Id=\"250105001\" nm=\"dyota_tform_bbcv_mis\" description=\"\" databaseNm=\"dyota_tform_bbcv_mis\" dbParamNm=\"$DB_HV_HADOOP_TEST_HDP_HD0_POC_DYOTA_TFORM_BBCV_MIS\" schemaNm=\"\" schemaParamNm=\"$SC_HV_HADOOP_TEST_HDP_HD0_POC_DYOTA_TFORM_BBCV_MIS_\" stgDb_Flag=\"Y\" srt_Order=\"1\" updateDt=\"2017-07-24 14:11:47.353 UTC\" updateBy=\"srana1\"/>"
    ti+="            <conn_Db conn_Id=\"250105\" conn_Db_Id=\"250105002\" nm=\"bbcv_mis\" description=\"\" databaseNm=\"bbcv_mis\" dbParamNm=\"$DB_HV_HADOOP_TEST_HDP_HD0_POC_BBCV_MIS\" schemaNm=\"\" schemaParamNm=\"$SC_HV_HADOOP_TEST_HDP_HD0_POC_BBCV_MIS_\" stgDb_Flag=\"N\" srt_Order=\"2\" updateDt=\"2017-07-24 14:11:47.353 UTC\" updateBy=\"srana1\"/>"
    ti+="          </conn_Dbs>"
    ti+="          <conn_Usr conn_Id=\"250105\" conn_Usr_Id=\"250105\" conn_Usr=\"dev_bbcv_etl\" usrPasswd=\"jmLUXv5sS7ljF+I5VLy2ag==\" connUsrParamNm=\"\" usrPasswdParamNm=\"\" updateDt=\"2017-07-24 14:11:47.356 UTC\" updateBy=\"srana1\"/>"
    ti+="          <flagent flagent_Id=\"-1\" nm=\"\" description=\"\" host=\"\" port=\"\" drFlag=\"Y\" updateDt=\"1900-01-01 00:00:00.0 UTC\" updateBy=\"\" error_Cd=\"0\" error_Msg=\"\"/>"
    ti+="          <flagent_Grp flagent_Grp_Id=\"3022\" nm=\"edl_lin\" description=\"Assigned edl_dev_lin to Project  ingest_mx_bbcy and edl_bbbf\" updateDt=\"2017-08-01 19:06:36.189 UTC\" updateBy=\"ashah\" error_Cd=\"0\" error_Msg=\"\"/>"
    ti+="          <conn_Obj_Properties>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.exec.dynamic.partition.mode\" property_Nm=\"hive.exec.dynamic.partition.mode\" property_Val=\"nonstrict\" srt_Order=\"2\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.exec.dynamic.partition\" property_Nm=\"hive.exec.dynamic.partition\" property_Val=\"TRUE\" srt_Order=\"2\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.mapred.supports.subdirectories\" property_Nm=\"hive.mapred.supports.subdirectories\" property_Val=\"TRUE\" srt_Order=\"2\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.auto.convert.sortmerge.join\" property_Nm=\"hive.auto.convert.sortmerge.join\" property_Val=\"NA\" srt_Order=\"3\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.optimize.bucketmapjoin\" property_Nm=\"hive.optimize.bucketmapjoin\" property_Val=\"NA\" srt_Order=\"4\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.optimize.bucketmapjoin.sortedmerge\" property_Nm=\"hive.optimize.bucketmapjoin.sortedmerge\" property_Val=\"NA\" srt_Order=\"5\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.auto.convert.sortmerge.join.noconditionaltask\" property_Nm=\"hive.auto.convert.sortmerge.join.noconditionaltask\" property_Val=\"NA\" srt_Order=\"6\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"hive.auto.convert.sortmerge.join.bigtable.selection.policy\" property_Nm=\"hive.auto.convert.sortmerge.join.bigtable.selection.policy\" property_Val=\"NA\" srt_Order=\"7\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"mapred.map.output.compression.codec\" property_Nm=\"mapred.map.output.compression.codec\" property_Val=\"NA\" srt_Order=\"10\" property_Type=\"S\"/>"
    ti+="            <conn_Obj_Property conn_Id=\"250105\" property_Cd=\"mapred.output.compression.type\" property_Nm=\"mapred.output.compression.type\" property_Val=\"NA\" srt_Order=\"12\" property_Type=\"S\"/>"
    ti+="          </conn_Obj_Properties>"
    ti+="</repConn>\n"
    ti+="<repConn fldr_Id=\"66600\" lockBy=\"\" mode_Ind=\"W\" unlock_Ind=\"N\" change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\" reusableFlag=\"N\" isDependent=\"true\" isLinkExist=\"false\" fldrNm=\"ingest_mx_bbcy\">\n"
    ti+="<conn conn_Id=\"74211\" nm=\"src_manual_feed_datagov\" aliasNm=\"FILE\" host=\"\" port=\"\" nativeFlag=\"N\" connParamNm=\"$CN_FF_FILE_SRC_MANUAL_FEED_DATAGOV\" dbTyp_Id=\"3\" connType=\"N\" ver=\"1\" description=\"\" valid_Cd=\"0\" updateDt=\"2017-02-09 10:46:23.116 UTC\" updateBy=\"jchengamaraju\" hdfshost=\"\" hdfsport=\"\" wrhloc=\"\" hadoop_Dist=\"\" flagent_Id=\"3022\" fileloc=\"/home/jchengamaraju/datagov/landing\" ftpFlag=\"N\" ftpHost=\"\" ftpPort=\"\" ftpUsr=\"\" ftpPasswd=\"\" fileProtocol=\"FTP\" secAuth=\"Simple\" hive_Principal=\"\" user_Principal=\"\" secKeyTab=\"\" secToken=\"\" url=\"https://www.salesforce.com/services/Soap/c/23.0\" dbVersion=\"\" exe_Engine=\"mr\" hdfs_Temp_Loc=\"/tmp\" yarnRMHost=\"\" yarnRMPort=\"\" mrJobHistHost=\"\" mrJobHistPort=\"\" hdfsPrincipal=\"\" yarnPrincipal=\"\" mapRedPrincipal=\"\" hdfs_Location=\"\" jobTracker_Host=\"\" jobTracker_Port=\"\" agentGrpInd=\"G\" dbAliasNm=\"\" hbase_Master_Host=\"\" hbase_Master_Port=\"\" zookeeper_Quorum_Host=\"\" zookeeper_Client_Port=\"\" hbase_Location=\"\" spark_WebUrl_Port=\"\" zookeeper_Znode_Parent=\"/hbase\" consumerKey=\"\" consumerSecret=\"\" accessToken=\"\" accessTokenSecret=\"\" queueNm=\"\" kerb_Server=\"\" kdc_Host=\"\" default_Releam=\"\" archive_Dir_Flg=\"N\" archive_Dir_Loc=\"$$ArchFileDir\">"
    ti+="<hiveServe2HACnf_Flg>N</hiveServe2HACnf_Flg>"
    ti+="<dfsHAConfig_Flg>N</dfsHAConfig_Flg>"
    ti+="<dfsNameService></dfsNameService>"
    ti+="<nameNodeIDs></nameNodeIDs>"
    ti+="<rpcAddrNameNodeID1></rpcAddrNameNodeID1>"
    ti+="<rpcAddrNameNodeID2></rpcAddrNameNodeID2>"
    ti+="<zookeeperNameSpace></zookeeperNameSpace>"
    ti+="<amazonS3Host></amazonS3Host>"
    ti+="<bucketNm></bucketNm>"
    ti+="<tempLoc_Azs3></tempLoc_Azs3>"
    ti+="<amzon_s3_mount></amzon_s3_mount>"
    ti+="<clusterNm></clusterNm>"
    ti+="<jmsProvider>JMS</jmsProvider>"
    ti+="<jmsProviderURL></jmsProviderURL>"
    ti+="<destinationType>Topic</destinationType>"
    ti+="<destinationNm></destinationNm>"
    ti+="<connectionFactory></connectionFactory>"
    ti+="<sparkMode></sparkMode>"
    ti+="<sparkYarnJarLocation></sparkYarnJarLocation>"
    ti+="<hadoop_Conf_Path>$DI_HOME/app/control/hadoop/conf</hadoop_Conf_Path>"
    ti+="<hdfs_SecAuth></hdfs_SecAuth>"
    ti+="<sftpAuthMode>password</sftpAuthMode>"
    ti+="<pvtKeyFileNm></pvtKeyFileNm>"
    ti+="</conn>"
    ti+="<conn_Dbs/>"
    ti+="<conn_Usr conn_Id=\"74211\" conn_Usr_Id=\"74211\" conn_Usr=\"\" usrPasswd=\"\" connUsrParamNm=\"\" usrPasswdParamNm=\"\" updateDt=\"2017-02-09 10:46:23.117 UTC\" updateBy=\"jchengamaraju\"/>"
    ti+="<flagent flagent_Id=\"-1\" nm=\"\" description=\"\" host=\"\" port=\"\" drFlag=\"Y\" updateDt=\"1900-01-01 00:00:00.0 UTC\" updateBy=\"\" error_Cd=\"0\" error_Msg=\"\"/>"
    ti+="<flagent_Grp flagent_Grp_Id=\"3022\" nm=\"edl_lin\" description=\"Assigned edl_dev_lin to Project  ingest_mx_bbcy and edl_bbbf\" updateDt=\"2017-03-08 13:32:44.667 UTC\" updateBy=\"Administrator\" error_Cd=\"0\" error_Msg=\"\"/>"
    ti+="<conn_Obj_Properties/>"
    ti+="</repConn>\n"
    ti+="</connections>\n"
    ti+="<reusables/>\n"
    ti+="<nativeSequences/>\n"
    ti+="</fldrObject>\n"
    ti+="</folders>\n"
    ti+="</repository>\n"
    writer.write(ti)
    del ti
    gc.collect()
    ti=" "