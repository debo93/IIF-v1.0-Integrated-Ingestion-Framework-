###################################################################################################
#
# Title : DB2 XML GENERATE
# Author : Avishek Chatterjee <AC00478691@TECHMAHINDRA.COM>
# Description : Generating xmls for DB2 System 
# System : DB2
#
###################################################################################################


import os
from dict_paths import config_prop_path,log_file_path,df,output_folder_path

path = output_folder_path+"STREAMS_XMLs\\"


a = open(output_folder_path+"STREAMS_XMLs\\"+"stream.list", "w")
for path, subdirs, files in os.walk(output_folder_path+"STREAMS_XMLs\\"):
   for filename in files:
   	if filename.startswith("s_"):

	    f = os.path.join(filename)
	    a.write(os.path.splitext(str(f))[0] +"|"+"01"+"\n")


#p=subprocess.Popen(['python','File_name_Generate.py'])

		