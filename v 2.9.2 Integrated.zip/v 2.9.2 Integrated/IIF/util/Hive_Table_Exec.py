import paramiko
import os
import logging
import re
from dict_paths import *
from termcolor import colored

try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('172.25.12.52',port=22,username=User_id,password=password)
    logging.info('Connection Established')
except:
    print colored("\tUnable to connect to server ...",'red',attrs=['reverse'])
    print "\tProcess Terminated ..."
    exit()
logging.basicConfig(filename= log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')
logging.info('EXECUTION OF HQLS STARTED..')

remotepath=edl_folder
files=[]
files=os.listdir(hql_folder_path)
exe_edl="n"
for items in files:
    ext=[]
    pat=[]
    try:
        ext=items.rsplit(".",1)[1]
    except:
        dummy_flg=0        
    
    if ext=="hql":
        
        ''' 
        if search in [Staging_Zone_Name]:
         input_2=raw_input("\tDo you want to execute staging zone scripts? (y/n) : ")
         while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
             input_2=raw_input("\tDo you want to execute staging zone scripts? (y/n) : ")
         if input_2 in ["y","yes","Yes","YES"]:
             exe_edl="y"
         if(exe_edl=="y"):
             command_move_0="cd" " "+remotepath+"/"+folder_name+"/HQLs/\n ls\n Chmod 777 *\n ls -lrt\n chmod 777 *\nhive -f "+items+" -hiveconf database_name="+Staging_Zone_DB+" "+"-hiveconf base_dir_loc="+HDFS_Location+"\n"
             #print command_move_0
             logging.info(command_move_0)
             print"\tSTAGING Zone Tables Execution is in process ..."
             stdin,stdout,stderr =ssh.exec_command(command_move_0)
             coms =stdout.read()
             #print coms
             logging.info('EXECUTION OF STAGING HQLS FINISHED..')
        '''
        
        if items in "create_" + Technical_Zone_Name+SRC_ID +".hql":
         #input_2=raw_input("\tDo you want to execute technical zone scripts? (y/n) : ")
         #while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
         #    input_2=raw_input("\tDo you want to execute technical zone scripts? (y/n) : ")
         #if input_2 in ["y","yes","Yes","YES"]:
         #    exe_edl="y"
         #if(exe_edl=="y"):
             #print "Inside Yes Loop"
             command_move_1="cd" " "+remotepath+"/"+folder_name+"/HQLs/\n ls\n Chmod 777 *\n ls -lrt\n chmod 777 *\nhive -f "+items+" -hiveconf database_name="+Technical_Zone_DB+" "+"-hiveconf base_dir_loc="+HDFS_Location+"\n"
             logging.info(command_move_1)
             #print command_move_1
             print"\tTECHNICAL Zone Tables Execution is in process ..."
             stdin,stdout,stderr =ssh.exec_command(command_move_1)
             com1 =stdout.read()
         #print com1
             logging.info('EXECUTION OF TECHNICAL HQLS FINISHED..')
        '''     
        elif search in [Enterprise_Zone_Name] and pat[len(pat)-1] not in ["crrctns"]:
            input_2=raw_input("\tDo you want to execute enterprise zone scripts? (y/n) : ")
            while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
                input_2=raw_input("\tDo you want to execute enterprise zone scripts? (y/n) : ")
            if input_2 in ["y","yes","Yes","YES"]:
                exe_edl="y"
            if(exe_edl=="y"):
                command_move_2="cd" " "+remotepath+"/"+folder_name+"/HQLs/\n ls\n Chmod 777 *\n ls -lrt\n chmod 777 *\nhive -f "+items+" -hiveconf database_name="+Enterprise_Zone_DB+" "+"-hiveconf base_dir_loc="+HDFS_Location+"\n"
                logging.info(command_move_2)
                print"\tENTERPRISE Zone Tables Execution is in process ..."
                stdin,stdout,stderr =ssh.exec_command(command_move_2)
                com3 =stdout.read()
                logging.info('EXECUTION OF ENTERPRISE HQLS FINISHED..')
        
        elif search in [Enterprise_Zone_Name] and pat[len(pat)-1] in ["crrctns"]:
            input_2=raw_input("\tDo you want to execute correction table scripts? (y/n) : ")
            while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
                input_2=raw_input("\tDo you want to execute correction table scripts? (y/n) : ")
            if input_2 in ["y","yes","Yes","YES"]:
                exe_edl="y"
            if(exe_edl=="y"):
                command_move_2="cd" " "+remotepath+"/"+folder_name+"/HQLs/\n ls\n Chmod 777 *\n ls -lrt\n chmod 777 *\nhive -f "+items+" -hiveconf database_name="+Enterprise_Zone_DB+" "+"-hiveconf base_dir_loc="+HDFS_Location+"\n"
                logging.info(command_move_2)
                print"\tENTERPRISE Zone Correction Tables Execution is in process ..."
                stdin,stdout,stderr =ssh.exec_command(command_move_2)
                com3 =stdout.read()
                logging.info('EXECUTION OF ENTERPRISE HQLS for corrections FINISHED..')
 
        elif search in [Consumer_Zone_Name]:
            input_2=raw_input("\tDo you want to execute consumer zone scripts? (y/n) : ")
            while input_2 not in ["y","n","yes","no","Yes","No","YES","NO"]:
                input_2=raw_input("\tDo you want to execute consumer zone scripts? (y/n) : ")
            if input_2 in ["y","yes","Yes","YES"]:
                exe_edl="y"
            if(exe_edl=="y"):
                command_move_3="cd" " "+remotepath+"/"+folder_name+"/HQLs/\n ls\n Chmod 777 *\n ls -lrt\n chmod 777 *\nhive -f "+items+" -hiveconf database_name="+Consumer_Zone_DB+" "+"-hiveconf base_dir_loc="+HDFS_Location+"\n"
                logging.info(command_move_3)
                print "\tCONSUMER Zone Tables Execution is in process ..."
                stdin,stdout,stderr =ssh.exec_command(command_move_3)
                com4 =stdout.read()
                logging.info('EXECUTION OF PRODUCTION HQLS FINISHED..')
            '''

print colored("\tCompleted Successfully ...",'yellow')