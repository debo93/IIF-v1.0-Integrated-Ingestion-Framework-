###################################################################################################
#
# Title : Connection Parser
# Author : Avishek Chatterjee <AC00478691@TECHMAHINDRA.COM>
# Description : Read connection id from connection xml
# System : DB2, Hive
# Version : 0.1
###################################################################################################

import xml.etree.ElementTree as eTree
import argparse
import os

def _parse_xml(xml):
    cDict = {}
    conn_xml = eTree.parse(xml)
    root = conn_xml.getroot()
    i = 1;

    for conn in root.iter('conn_Db'):
        ccDict = {}
        ccDict['con_name'] = os.path.basename(xml).replace(".xml","")
        ccDict['conn_Db_Id'] = conn.get("conn_Db_Id")
        ccDict['conn_Id'] = conn.get("conn_Id")
        ccDict['nm'] = conn.get("nm")
        ccDict['dbParamNm'] = conn.get("dbParamNm")
        
        for conn_param in root.iter('conn'):
            ccDict['connParamNm'] = conn_param.get("connParamNm")
            cDict[i] = ccDict
            i = i + 1
    return cDict

def connection_parser(src_conn_xml, tgt_conn_xml):
    scDict = _parse_xml(src_conn_xml)
    tcDict = _parse_xml(tgt_conn_xml)
    
    return scDict, tcDict

def main(src_conn_xml, tgt_conn_xml):
    connection_parser(src_conn_xml, tgt_conn_xml)

if __name__ == "__main__":
    
    PARSER = argparse.ArgumentParser()
    PARSER.add_argument("--source_conn_xml",type=str, required=True)
    PARSER.add_argument("--target_conn_xml",type=str, required=True)
    ARGS = PARSER.parse_args()
     
    if ARGS.source_conn_xml:
        SRC_CONN_NAME_XML = ARGS.source_conn_xml
    if ARGS.target_conn_xml:
        TGT_CONN_NAME_XML = ARGS.target_conn_xml
    #print "Start reading source & connection xml"
    
    main(SRC_CONN_NAME_XML, TGT_CONN_NAME_XML)
    
    #print "End reading source & connection xml"
