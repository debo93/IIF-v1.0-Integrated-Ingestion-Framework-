import os
from dict_paths import *
import re

path = output_folder_path+"UT_Check\\"
for path, subdirs, files in os.walk(path):
    for filename in files:
        lst=[]
        lst=re.split("_",filename)
        if filename.startswith("s_"):
            if(lst[1]=="src"):
                a = open(path+"src_stream_count.list", "w")
                f = os.path.join(filename)
                a.write(os.path.splitext(str(f))[0] +"|"+"01"+"\n")
                a.close
            elif(lst[1]=="tgt"):
                b = open(path+"tgt_stream_count.list", "w")
                f = os.path.join(filename)
                b.write(os.path.splitext(str(f))[0] +"|"+"01"+"\n")
                b.close