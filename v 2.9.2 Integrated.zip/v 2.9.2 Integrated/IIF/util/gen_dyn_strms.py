import xml.etree.ElementTree as eTree
from dict_paths import *

src_xml=base_path+"\\"+Source_Connection_XML_Path
tgt_xml=base_path+"\\"+Target_Connection_XML_Path


src_conn_id=""
tgt_conn_id=""

template_file_db2 = base_path+"\\IIF\\template\\stream_gen_template_DB2.py"
template_file_ffd = base_path+"\\IIF\\template\\stream_gen_template_flatfiles_D.py"

db2_stream_py = open(template_file_db2,"r+")
ffd_stream_py = open(template_file_ffd,"r+")

def _parse_xml(xml):
    cDict = {}
    conn_xml = eTree.parse(xml)
    root = conn_xml.getroot()
    i = 1;

    for conn in root.iter('conn_Db'):
        ccDict = {}
        ccDict['nm'] = conn.get("nm")
        ccDict['conn_Db_Id'] = conn.get("conn_Db_Id")
        ccDict['conn_Id'] = conn.get("conn_Id")
        cDict[i] = ccDict
        i = i + 1
    return cDict


tgt_conn_file = open(tgt_xml)
src_conn_file = open(src_xml)
tgt_flg=0
src_flg=0
tgt_conn=""
src_conn=""
for lines in tgt_conn_file:
    if("<conn conn_Id=" in lines):
        tgt_flg=1
    elif("</repConn>" in lines):
        tgt_flg=0
    if(tgt_flg==1):
        tgt_conn+="    ti+=\""
        for i in lines:
            if(i=='"'):
                tgt_conn+='\\"'
            elif(i=="\n"):
                tgt_conn+='\"\n'
            else:
                tgt_conn+=i


for lines in src_conn_file:
    if("<conn conn_Id=" in lines):
        src_flg=1
    elif("</repConn>" in lines):
        src_flg=0
    if(src_flg==1):
        src_conn+="    ti+=\""
        for i in lines:
            if(i=='"'):
                src_conn+='\\"'
            elif(i=="\n"):
                src_conn+='\"\n'
            else:
                src_conn+=i
    
src_dict={}
tgt_dict={}
src_dict=_parse_xml(src_xml)
tgt_dict=_parse_xml(tgt_xml)
src_con_db_id=""
tgt_con_db_id=""
src_conn_Id=""
flag_1=0

for keys,value in src_dict.iteritems():
    for sub_keys,values in value.iteritems():
        if(sub_keys=="conn_Id"):
            src_conn_Id = values
        if(sub_keys=="nm"):
            if(values==SRC_Schema_Name):
                flag_1=keys
                
for keys,value in src_dict.iteritems():
    if(keys==flag_1):
        for sub_keys,values in value.iteritems():
            if(sub_keys=="conn_Db_Id"):
                src_con_db_id=values
                    
flag_2=0
for keys,value in tgt_dict.iteritems():
    for sub_keys,values in value.iteritems():
        if(sub_keys=="conn_Id"):
            tgt_conn_Id = values
        if(sub_keys=="nm"):
            if(values==TGT_Schema_Name):
                flag_2=keys

for keys,value in tgt_dict.iteritems():
    if(keys==flag_2):
        for sub_keys,values in value.iteritems():
            if(sub_keys=="conn_Db_Id"):
                tgt_con_db_id=values

                
if(SRC_SYS=="DB2"):
    new_file=open("gen_streams.py","w")

    for line in db2_stream_py:
        if("tgt_conn_id = " in line):
            new_file.write("tgt_conn_id = \""+tgt_conn_Id+'"\n' if "tgt_conn_id = \"\"" in line else line)
        elif "src_conn_id = " in line:
            new_file.write("src_conn_id = \""+src_conn_Id+'"\n' if "src_conn_id = \"\"" in line else line)
        elif "src_schema = " in line:
            new_file.write("src_schema = \""+src_con_db_id+'"\n' if "src_schema = \"\"" in line else line)
        elif "tgt_schema = " in line:
            new_file.write("tgt_schema = \""+tgt_con_db_id+'"\n' if "tgt_schema = \"\"" in line else line)
        elif "<TARGET_CONNECTION>" in line:
            new_file.write(tgt_conn if "<TARGET_CONNECTION>" in line else line)
        elif "<SOURCE_CONNECTION>" in line:
            new_file.write(src_conn if "<SOURCE_CONNECTION>" in line else line)
        else:
            new_file.write(line)
    new_file.close()
    db2_stream_py.close()
elif(SRC_SYS=="FFD"):
    new_file=open("gen_streams.py","w")

    for line in ffd_stream_py:
        if("tgt_conn_id = " in line):
            new_file.write("tgt_conn_id = \""+tgt_conn_Id+'"\n' if "tgt_conn_id = \"\"" in line else line)
        elif "src_conn_id = " in line:
            new_file.write("src_conn_id = \""+src_conn_Id+'"\n' if "src_conn_id = \"\"" in line else line)
        elif "src_schema = " in line:
            new_file.write("src_schema = \""+src_con_db_id+'"\n' if "src_schema = \"\"" in line else line)
        elif "tgt_schema = " in line:
            new_file.write("tgt_schema = \""+tgt_con_db_id+'"\n' if "tgt_schema = \"\"" in line else line)
        elif "<TARGET_CONNECTION>" in line:
            new_file.write(tgt_conn if "<TARGET_CONNECTION>" in line else line)
        elif "<SOURCE_CONNECTION>" in line:
            new_file.write(src_conn if "<SOURCE_CONNECTION>" in line else line)
        else:
            new_file.write(line)
    new_file.close()
    ffd_stream_py.close()
