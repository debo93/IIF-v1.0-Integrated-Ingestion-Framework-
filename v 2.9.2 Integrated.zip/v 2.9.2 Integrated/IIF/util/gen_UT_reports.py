import paramiko
import logging
from dict_paths import *
from termcolor import colored

logging.basicConfig(filename= log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')
logging.info('EXECUTION OF UT STREAMS..')
remotepath=edl_folder+folder_name
try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('172.25.12.52',port=22,username=User_id,password=password)
    logging.info('Connection Established')
except:
    print colored("\tUnable to connect to server ...",'red',attrs=['reverse'])
    print "\tProcess Terminated ..."
    exit()

if(Country_Code!=''):
  
  COUNTRY_CODE="_"+Country_Code+"_"
else :
  COUNTRY_CODE='_'


def _build_query(DB):
    
    NT_EQ_SQL = ("SELECT Source_UT_tbl.table_name as table_name, Source_UT_tbl.count" +
           " as src_count, Target_UT_tbl.count as tgt_count, (Source_UT_tbl." +
           "count - Target_UT_tbl.count) as count_diff, Target_UT_tbl.load_date" +
           " as run_date from " + DB + ".Source_UT_tbl Left outer join " + DB +
           ".Target_UT_tbl on LOWER(CONCAT('"+Technical_Zone_Name+SRC_ID+COUNTRY_CODE+"',Source_UT_tbl." +
           "table_name)) = LOWER(Target_UT_tbl.table_name) and Source_UT_tbl" +
           ".project_epm = Target_UT_tbl.project_epm and Source_UT_tbl." +
           "source_sys_epm = Target_UT_tbl.source_sys_epm and Source_UT_tbl." +
           "country_code = Target_UT_tbl.country_code and Source_UT_tbl." +
           "load_date = Target_UT_tbl.load_date where Source_UT_tbl.count <>" +
           " Target_UT_tbl.count and Target_UT_tbl.load_date = current_date "
           )
    EQ_SQL = ("SELECT Source_UT_tbl.table_name as table_name, Source_UT_tbl.count" +
           " as src_count, Target_UT_tbl.count as tgt_count, (Source_UT_tbl." +
           "count - Target_UT_tbl.count) as count_diff, Target_UT_tbl.load_date" +
           " as run_date from " + DB + ".Source_UT_tbl Left outer join " + DB +
           ".Target_UT_tbl on LOWER(CONCAT('"+Technical_Zone_Name+SRC_ID+COUNTRY_CODE+"',Source_UT_tbl." +
           "table_name)) = LOWER(Target_UT_tbl.table_name) and Source_UT_tbl" +
           ".project_epm = Target_UT_tbl.project_epm and Source_UT_tbl." +
           "source_sys_epm = Target_UT_tbl.source_sys_epm and Source_UT_tbl." +
           "country_code = Target_UT_tbl.country_code and Source_UT_tbl." +
           "load_date = Target_UT_tbl.load_date where Source_UT_tbl.count =" +
           " Target_UT_tbl.count and Target_UT_tbl.load_date = current_date "
           )
    MS_SQL = ("SELECT Source_UT_tbl.table_name from " + DB + ".Source_UT_tbl Left join" +
              " " + DB + ".Target_UT_tbl on LOWER(CONCAT('"+Technical_Zone_Name+SRC_ID+COUNTRY_CODE+"',Source_UT_tbl." +
              "table_name)) = LOWER(Target_UT_tbl.table_name) and " +
              "Source_UT_tbl.project_epm = Target_UT_tbl.project_epm and " +
              "Source_UT_tbl.source_sys_epm = Target_UT_tbl.source_sys_epm " +
              " and Source_UT_tbl.country_code = Target_UT_tbl.country_code " +
              "and Source_UT_tbl.load_date = Target_UT_tbl.load_date " +
              "where Source_UT_tbl.load_date = current_date and " + 
              "Target_UT_tbl.table_name is null;"
              )
    return NT_EQ_SQL, EQ_SQL, MS_SQL

def _execute_write(CONN, SQL, TYPE, UNIT_TESTING):
   # temp_table_list=[]
    QUERY = 'hive -e "'+ SQL + '"'
    stdin, stdout, stderr = CONN.exec_command(QUERY)
    #print stdout.read()
    with open(UNIT_TESTING+"\\"+TYPE + ".csv", "w") as fout:
        for output in stdout.read().splitlines():
            for line in output:
                fout.write(line.replace('\t', ','))
            fout.write("\n")


def _get_ssh_client():
    try:
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect('172.25.12.52', port=22, username=User_id, password=password)
    except:
        print "SSH Connection failed."
        client = ""
    
    return client
    
PROJECT_EPM = Prj_EPM_Code
SOURCE_SYS_EPM = SRC_ID
COUNTRY_CODE = Country_Code
SRC_SCHEMA_NAME = SRC_Schema_Name
TGT_SCHEMA_NAME = TGT_Schema_Name
UNIT_TESTING = output_folder_path+"UT_Check\\"
SRC_FILE_NAME = UNIT_TESTING+"s_src_" + PROJECT_EPM + "_" + SOURCE_SYS_EPM
TGT_FILE_NAME = UNIT_TESTING+"s_tgt_" + PROJECT_EPM + "_" + SOURCE_SYS_EPM

#print "Generating UT Reports ..."

NT_EQ_SQL, EQ_SQL, MS_SQL = _build_query(TGT_SCHEMA_NAME)

#CONN=_get_ssh_client()

if 1:
    logging.info(NT_EQ_SQL)
    _execute_write(CONN, NT_EQ_SQL, "failure_tbl_list", UNIT_TESTING)
    logging.info(EQ_SQL)
    _execute_write(CONN, EQ_SQL, "success_tbl_list", UNIT_TESTING)
    logging.info(MS_SQL)
    _execute_write(CONN, MS_SQL, "missing_tbl_list", UNIT_TESTING)
    print "\tCompleted Successfully ..."