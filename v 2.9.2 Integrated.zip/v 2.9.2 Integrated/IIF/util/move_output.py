import paramiko
import scp
import os
import logging
from dict_paths import *
import datetime
from termcolor import colored

PROJECT_EPM = Prj_EPM_Code
SOURCE_SYS_EPM = SRC_ID


logging.basicConfig(filename=log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')
logging.info('HQL CODE STARTED..')

############################################################################

#Place Folders Kept to parameterise in the dicmd command
############################################################################

'''
USER_ID = config['UT CHECK']['USER_ID']
PASSWORD = config['UT CHECK']['PASSWORD']
ingestion_folder = config['UT CHECK']['ingestion_folder']
ZONE = config['UT CHECK']['ZONE']
'''
#print(PROJECT_EPM)
#print(SOURCE_SYS_EPM)


server_path = edl_folder

try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('172.25.12.52',port=22,username=User_id,password=password)
    logging.info('Connection Established')
except:
    print colored("\tUnable to connect to server ...",'red',attrs=['reverse'])
    print "\tProcess Terminated ..."
    exit()
    
folders_list=[]
hql_files_list=[]
stream_xmls_list=[]
ut_stream_list=[]

folders_list = (next(os.walk(output_folder_path))[1])
hql_files_list = (next(os.walk(output_folder_path+"\\HQLs"))[2])
stream_xmls_list = (next(os.walk(output_folder_path+"\\Streams_XMLs"))[2])
ut_stream_list = (next(os.walk(output_folder_path+"\\UT_Check"))[2])
#folder_name = "Output_IIF_"+datetime.datetime.now().strftime('%d%m%y%H%M%S')
command_1="cd "+edl_folder+"\n"+"mkdir "+folder_name+"\n"
command=""
stdin, stdout, stderr = ssh.exec_command(command_1+"\nchmod 777 "+folder_name+"\n")
for i in range(0,len(folders_list)):
    command+="mkdir "+folders_list[i]+"\n"
    i=i+1

#print "cd "+edl_folder+"\ncd "+folder_name+"\n"+command    
stdin, stdout, stderr = ssh.exec_command("cd "+edl_folder+"\ncd "+folder_name+"\n"+command)
#stdin, stdout, stderr = ssh.exec_command()

i=0
command_hql = "cd "+output_folder_path+"\\HQLs\\\n"
#print hql_files_list
dummy=0

try : 
    for i in range(0,len(hql_files_list)):
        with scp.SCPClient(ssh.get_transport()) as scp1:
            scp1.put(output_folder_path+"\\HQLs\\"+hql_files_list[i],folder_name+"/HQLs/",preserve_times=True)
            #command_hql+="hive -f "+hql_files_list[i]+";\n"
        i=i+1
except:
    dummy=1

i=0
try:
    for i in range(0,len(stream_xmls_list)):
        with scp.SCPClient(ssh.get_transport()) as scp1:
            scp1.put(output_folder_path+"\\Streams_XMLs\\"+stream_xmls_list[i],folder_name+"/STREAMS_XMLs/",preserve_times=True)
        i=i+1
except:
    dummy=2
i=0

try:
    for i in range(0,len(ut_stream_list)):
        with scp.SCPClient(ssh.get_transport()) as scp1:
            scp1.put(output_folder_path+"\\UT_Check\\"+ut_stream_list[i],folder_name+"/UT_Check/",preserve_times=True)
        i=i+1
except:
    dummy=3

####################################################################################
#xml_uplaod AND xml_exec script movement into EDL
#######################################################################
with scp.SCPClient(ssh.get_transport()) as scp1:
    scp1.put(output_folder_path+"\\xml_upload.sh",folder_name,preserve_times=True)
    logging.info('xml_upload.sh moved to EDL')

with scp.SCPClient(ssh.get_transport()) as scp1:
    scp1.put(output_folder_path+"\\xml_exec.sh",folder_name,preserve_times=True)
    logging.info('xml_exec.sh moved to EDL')
print colored("\tCompleted Successfully ...",'yellow')