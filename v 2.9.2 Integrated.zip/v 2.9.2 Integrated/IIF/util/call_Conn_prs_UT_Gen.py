import ut_gen_validator
import connection_parser
from dict_paths import *

src_conn_path = base_path + "\\"+Source_Connection_XML_Path
tgt_conn_path = base_path + "\\"+Target_Connection_XML_Path
#src_conn_path=r'C:\Users\ac00478691\Desktop\AUTOMATION\Integrated Ingestion Framework v2.5\IIF v 2.0\Input\Connections_XML\Con_CEDL_SIV_test_dont_use.xml'
#tgt_conn_path=r'C:\Users\ac00478691\Desktop\AUTOMATION\Integrated Ingestion Framework v2.5\IIF v 2.0\Input\Connections_XML\HDP_HD_bbcv.xml'

scDict, tcDict = connection_parser.connection_parser(src_conn_path, tgt_conn_path)
#print(tcDict)
#print(scDict)
ut_gen_validator.init(scDict, tcDict)
