import paramiko
import logging
from dict_paths import * 
from termcolor import colored



logging.basicConfig(filename= log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')
logging.info('EXECUTION OF STREAMS..')

####################################################################################################
#CONNECTION ESTABLISHMENT TO THE EDL
####################################################################################################

remotepath=edl_folder+"/"+folder_name
try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('172.25.12.52',port=22,username=User_id,password=password)
    logging.info('Connection Established')
except:
    print colored("\tUnable to connect to server ...",'red',attrs=['reverse'])
    print "\tProcess Terminated ..."
    exit()


####################################################################################################
#XML UPLOAD
####################################################################################################

warning="\n\t\t             IMPORTANT NOTE              \t\t"
warning+="\n\t\t-----------------------------------------\t\t"
warning+="\n\t\tKINDLY TEST THE IMPORTED CONNECTION      \t\t"
warning+="\n\t\tBEFORE EXECUTING THE STREAM              \t\t"  
warning+="\n\t\tTO AVOID LOCKING OF CONNECTION           \t\t"
warning+="\n\t\t-----------------------------------------\t\t"
text = colored(warning, 'yellow', attrs=['reverse'])

print(text)

import_streams="n"
inp_import=raw_input("\tDo you want to import streams in Diyotta? (y/n) : ")

while inp_import not in ["y","n","yes","no","Yes","No","YES","NO"]:
    inp_import=raw_input("\tWant to import streams in Diyotta? (y/n) : ")
if inp_import in ["y","yes","Yes","YES"]:
    import_streams="y"    
    
if(import_streams=="y"):
    command_move="cd" + " "+remotepath+"\nsh xml_upload.sh\n"
    print command_move
    logging.info("upload of the streams Started")
    stdin,stdout,stderr =ssh.exec_command(command_move)
    logging.info("upload of the streams Done 1")
    com1 = stdout.read()
    print "\tStreams Uploaded successfully"
    logging.info(com1)

####################################################################################################
#XML EXECUTE
####################################################################################################
exec_streams="n"

inp_exec=raw_input("\tDo you want to execute the streams in Diyotta? (y/n) : ")

while inp_exec not in ["y","n","yes","no","Yes","No","YES","NO"]:
    inp_exec=raw_input("\tDo you want to execute the streams in Diyotta? (y/n) : ")
if inp_exec in ["y","yes","Yes","YES"]:
    exec_streams="y"    

if (exec_streams=="y"):
    logging.info("execution of the streams Started")
    command_exec="cd" + " "+remotepath+"\nsh xml_exec.sh\n"
    stdin,stdout,stderr =ssh.exec_command(command_exec)
    com2 = stdout.read()
    logging.info(com2)
    print "\tStreams sent for execution"
print colored("\tCompleted Successfully ...",'yellow')