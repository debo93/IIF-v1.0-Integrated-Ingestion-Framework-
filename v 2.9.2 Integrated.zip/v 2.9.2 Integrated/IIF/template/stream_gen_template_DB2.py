
###################################################################################################
#
# Title : DB2 XML GENERATE
# Author : Avishek and Debo
# Description : Generating streams for Normal and PII enabled tables
# System : DB2
# Version: 0.5
###################################################################################################

import gc
import os
import logging
from dict_paths import *
import re

logging.basicConfig(filename=log_file_path,level=logging.DEBUG,format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',filemode='a')

#Taking Input File

table_dict={}   #For storing tables and its related attributes
group_dict={}   #For storing Groups and its related table names\

tgt_conn_id = "" 
src_conn_id = ""
src_schema = ""
tgt_schema = ""

if(Country_Code!=''):
    country_code=Country_Code
else :
    country_code='_'


#SOURCE MAPPING 

db2_type_to_hive_type_dict_1={}

db2_type_to_hive_type_dict_1['VARCHAR']='12'
db2_type_to_hive_type_dict_1['CHARACTER']='1'
db2_type_to_hive_type_dict_1['DATE']='91'
db2_type_to_hive_type_dict_1['NUMERIC']='2'
db2_type_to_hive_type_dict_1['TIMESTAMP']='93'
db2_type_to_hive_type_dict_1['DECIMAL']='3'
db2_type_to_hive_type_dict_1['STRING']='12'
db2_type_to_hive_type_dict_1['NUMBER']='2'
db2_type_to_hive_type_dict_1['INT']='4'
db2_type_to_hive_type_dict_1['CHAR']='1'
db2_type_to_hive_type_dict_1['FLOAT']='6'

#TARGET MAPPING 

db2_type_to_hive_type_dict_2={}

db2_type_to_hive_type_dict_2['CHARACTER']='12'
db2_type_to_hive_type_dict_2['CHAR']='12'
db2_type_to_hive_type_dict_2['VARCHAR']='1212'
db2_type_to_hive_type_dict_2['STRING']='12'
db2_type_to_hive_type_dict_2['DATE']='91'
db2_type_to_hive_type_dict_2['DECIMAL']='3'
db2_type_to_hive_type_dict_2['NUMERIC']='3'
db2_type_to_hive_type_dict_2['TIMESTAMP']='93'
db2_type_to_hive_type_dict_2['NUMBER']='3'
db2_type_to_hive_type_dict_2['INT']='4'
db2_type_to_hive_type_dict_2['FLOAT']='6'


###############################################################################
#
#FUNCTIONS SECTION
#
###############################################################################

#To get Tables and its related Column Names, Data Type, Scale, Precision,
#Stream Names and PII Flag

def get_table_and_fields(frame):
    frame=frame.reset_index().drop("index",axis=1)
    table_name=frame.table_name.values.tolist()[0]
                
    if table_name not in table_dict:
        table_dict[table_name]={}
                                                
        for i in range(len(frame)):
            col=frame.loc[i,"column_name"]
            s_tp=frame.loc[i,"source_type"]
            t_tp=frame.loc[i,"source_type"]
            s_tp=s_tp.upper()
            t_tp=t_tp.upper()
            scl=frame.loc[i,"scale"]
            prs=frame.loc[i,"precision"]
            pii_col=frame.loc[i,"pii_col"]
            seq=i
            if s_tp in db2_type_to_hive_type_dict_1:
                s_tp=db2_type_to_hive_type_dict_1[s_tp]
            if t_tp in db2_type_to_hive_type_dict_2:
                t_tp=db2_type_to_hive_type_dict_2[t_tp]

            table_dict[table_name][seq]=[col,s_tp,t_tp,scl,prs,pii_col]

#To get Groups and its related Table Names

def get_streams_and_table_names(frame):
        frame=frame.reset_index().drop("index",axis=1)
        stream_names=frame.stream_names.values.tolist()[0]
        group_dict[stream_names]={}
        for i in range(len(frame)):
            table_name=frame.loc[i,"table_name"]
            seq=i
            if(table_name not in group_dict.values()):
                group_dict[stream_names][seq]=[table_name]

###############################################################################
#
#DECLARATION SECTION
#                                               
###############################################################################


pii_enabled_tables=[]
quotes = '"'
slash='\\'

streams_fldr = output_folder_path+"STREAMS_XMLs\\"

if not os.path.exists(streams_fldr):
    os.makedirs(streams_fldr)
    logging.info('STREAM PATH CREATED')


#a = open(streams_fldr+"stream_names.list", "w")

df.groupby(df.table_name).apply(get_table_and_fields)           #populating our table_dictionary
df.groupby(df.stream_names).apply(get_streams_and_table_names)  #populating our group_dictionary

###############################################################################
#CREATING A LIST OF ALL PII ENABLED TABLES
###############################################################################

pii=""
for table_name,ft in sorted(table_dict.items()):
    
    flag=0
    for seq,details in ft.iteritems():
        col_cnt =0
        for x in details:
            if col_cnt == 0:
                col=str(x)
            if col_cnt == 1:
                s_tp=str(x)
            if col_cnt == 2:
                t_tp=str(x)
            if col_cnt == 3:
                scl=str(x)
            if col_cnt == 4:
                prs=str(x)
            if col_cnt == 5:
                pii=str(x)
            col_cnt = col_cnt+1
            
            if(pii=="Y" or pii=="y"):
                flag=1
    if flag==1:
       pii_enabled_tables.append(table_name) 

for stream_names,ft1 in sorted(group_dict.items()):
    
    cnt1=238143000
    cnt2=238143
    cnt3=238152000
    cnt4=238152
    cnt5=247994000
    cnt6=247993
    cnt7=247995
    cnt8=247994000
    cnt9=238152000

    cnt11=248001
    cnt_pii=73498000
    cnt_pii_1=73498
    cnt_pii_2=95544
    tgt_pii=120753000
    link_attr_id=2955000
    link_id=2955

    temp_table_lists=[]
    cnt=1
    writer=open(streams_fldr+"s_"+stream_names+".xml","w")
    writer.write("<repository rep_Id=\"11\""+ " "+ "fldr_Id=\"-1\""+ " "+ "nm=\"DIREP\""+ " "+ "description=\"DI Repository\""+ " "+ "updateBy=\"rpunuru\""+ " "+ "lastUpdateBy=\"rpunuru\""+ " "+ "updateDt=\"2016-08-24 17:45:34.394 UTC\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "change_Ind=\"N\""+ " "+ "ver=\"36330000\""+ " "+ "exportLevel=\"DXFLOW\""+ " "+ "build_Id=\"2088\""+ " "+ "relVer=\"3.6.0\"" + " "+ "patch_Id=\"011\""+" "+ "global_Fldr_Id=\"-1\""+">\n")
    writer.write("<folders>\n")
    writer.write("<fldrObject repositoryName=\"DIREP\""+" "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+">\n")
    writer.write("<fldr fldr_Id=\"85427\""+ " "+ "nm=\"ingest_pa_b6xp\""+ " "+ "description=\"\""+ " "+ "updateBy=\"Administrator\""+ " "+ "lastUpdateBy=\"Administrator\""+ " "+ "updateDt=\"2017-02-09 21:23:50.985 UTC\""+ " "+ "reusableFlag=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\"" + " "+ "change_Ind=\"N\"" +" "+"/>\n")
    writer.write("<dataObjects>\n")
    #flag=0
    for seq,details in ft1.iteritems():
        table_nm=""
        i=1
        for x in details:
            tc=str(format(x))
            table_nm=tc
            if table_nm not in temp_table_lists:
                temp_table_lists.insert(i,table_nm)
                i=i+1
    ti=""
    dObj_Id_value=[]
    src_obj_ref_id=[]
    rowsindf = 100
    colsindf = 2
    src_attr_Id = []
    i=0
    #print(stream_names)

###############################################################################
#
#Writing Source data object        
#
###############################################################################
    
    for record in temp_table_lists:

        for table_name,ft in sorted(table_dict.items()):
            
            if(table_name==record):
                
                    
                cnt_srt = 0
                c=cnt2*1000
                src_obj_ref_id.append(cnt2)
                dObj_Id_value.append(cnt2)
                

                ti="<dataObject fldr_Id=\"85427\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm="+"\""+"ingest_cr_bc74\""+">\n"
                ti+="<dObj dObj_Id="+"\""+str(cnt2)+"\""+ " "+"nm=\""+table_name+"\""+ " "+ "aliasNm=\"Technical_Zone\""+ " "+ "description=\"\""+ " "+ "ver=\"2\""+ " "+ "dbTyp_Id=\"5\""+ " "+ "valid_Cd=\"0\""+ " "+ "localFlag=\"N\""+ " "+ "updateBy=\"vradhakrishnan\""+ " "+ "lastUpdateBy=\"vradhakrishnan\""+ " "+ "updateDt=\"2017-04-03 09:24:05.147 UTC\""+ " "+ "dObj_ParamNm=\"$DO_DB_Technical_Zone_"+table_name+"\""+ " "+ "codepage=\"\""+">\n"
                ti+="<transient_ScopeFlg>P</transient_ScopeFlg>\n"
                ti+="<caseSensitiveFlg>N</caseSensitiveFlg>\n"
                ti+="</dObj>\n" +"\n"
                ti+="<attributes>\n"
                #stream_names=""
                for seq,details in ft.iteritems():
                    #print seq
                    #print details
                    col_cnt =0
                    #print "chk count "
            
                    for x in details:
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        if col_cnt == 5:
                            pii=str(x)
                            if(str(pii)=='y' or str(pii)=='Y'):
                                #print ("Found an Yes Column : ",str(c))
                                src_attr_Id.append(str(c))

                            
                           
                        col_cnt = col_cnt+1
                     

                    ti+="<attribute attr_Id="+ "\""+str(c)+ "\""+" " +"obj_Id="+"\""+str(cnt2)+"\""+ " "+ "attrNm="+"\""+col+"\""+" "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+s_tp+"\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"1\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                    ti+="<fldValue></fldValue>\n"
                    ti+="</attribute>\n"
                    cnt1=cnt1+1
                    c=c+1

                    cnt_srt=cnt_srt+1
            
                #print src_attr_Id
                ti+="</attributes>\n"
                ti+="<dObj_FlatFile_Property dObj_Id="+"\""+str(cnt2)+"\""+ " "+ "fileType=\"D\""+ " "+ "colDelim=\"01\""+ " "+ "rowDelim="+quotes+slash+"n"+quotes+" "+"txtQual=\"\""+" "+"dateTimeFormat=\"&apos;MM/DD/YYYY HH24:MI:SS&apos;\""+ " "+ "skipRows=\"0\""+ " "+ "escapeChar=\"04\""+ " "+ "writeHdrFlag=\"N\""+ " "+ "fileNm=\""+table_name.upper()+".dat"+"\""+" "+ "collItemsDelim=\"02\""+" "+"mapKeysDelim=\"03\""+" "+"nullValue=\"\""+ " "+ "inputFormatClass=\"\""+ " "+ "outputFormatClass=\"\""+ " "+ "orc_Compression=\"NONE\""+ " "+ "orc_Stripe_Size=\"268435456\""+ " "+ "orc_Row_Index_Stride=\"10000\""+ " "+ "orc_Compress_Size=\"262144\""+ " "+ "orc_Create_Index=\"N\""+ " "+ "compression=\"N\""+ " "+ "compressionClass=\"\""+ " "+ "fileFormat=\"TEXTFILE\""+ " "+ "convTable=\"Cp037\""+" "+ "distFldSize=\"0\""+ " "+ "newLineSize=\"0\""+ " "+ "serdeJarPath=\"/home/dialphausr/test/csv-serde-1.1.2.jar\""+ " "+ "serdeClass=\"com.bizo.hive.serde.csv.CSVSerde\""+ " "+ "serdeProperties=\"\""+ " "+ "rootElmnt=\"root\""+ " "+ "nameSpc=\"\""+ " "+ "compressionType=\"NONE\""+ " "+ "interCompression=\"FALSE\""+ " "+ "interCompressionClass=\"\""+ " "+ "location=\"\""+ " "+ "dateFormat=\"YYYY-MM-DD\""+ " "+ "parq_Dfs_Blocksize=\"256\""+ " "+ "parq_Page_Size=\"65536\""+ " "+ "parq_Dictionary_Page_Size=\"65536\""+ " "+ "parq_Block_Size=\"256\""+ " "+ "parq_Enable_Dictionary=\"Y\""+ " "+ "parq_Compression=\"SNAPPY\""+">\n"
                ti+="<fldOffset>-1</fldOffset>\n"
                ti+="<headerOffset>-1</headerOffset>\n"
                ti+="</dObj_FlatFile_Property>\n"
                ti+="</dataObject>\n"
                cnt2=cnt2+1
                cnt1=((cnt2)*1000)+1
                writer.write(ti)
                del ti
                gc.collect()
                
                
    
    ti=""
    #print dObj_Id_value
###############################################################################
#
#Writing Target data object        
#
###############################################################################
    
    tgt_obj_ref_id=[]
    for record in temp_table_lists:
        for table_name,ft in sorted(table_dict.items()):
            if(table_name==record):
                #print table_name
                no_of_col=len(ft)
                cnt_srt=0
                tgt_obj_ref_id.append(cnt4)
                d=cnt4*1000
                ti+="<dataObject fldr_Id=\"85427\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm="+"\""+"ingest_cr_bc74\""+">\n"
                ti+="<dObj dObj_Id="+"\""+str(cnt4)+"\""+ " "+ " "+"nm=\""+Technical_Zone_Name+ SRC_ID+country_code + table_name+"\""+ " "+ "aliasNm=\"HADOOP\""+ " "+ "description=\"\""+ " "+ "ver=\"7\""+ " "+ "dbTyp_Id=\"6\""+ " "+ "valid_Cd=\"0\""+ " "+ "localFlag=\"N\""+ " "+ "updateBy=\"lmaddineni\""+ " "+ "lastUpdateBy=\"lmaddineni\""+" "+ "updateDt=\"2017-03-11 07:30:01.906 UTC\""+ " "+ "dObj_ParamNm=\"$DO_HV_HADOOP_"+Technical_Zone_Name+ SRC_ID + country_code +table_name + "\""+ " "+ "codepage=\"\""+">\n"
                ti+="<transient_ScopeFlg>P</transient_ScopeFlg>\n"
                ti+="<caseSensitiveFlg>N</caseSensitiveFlg>\n"
                ti+="</dObj>\n"
                ti+="<attributes>\n"
                for seq,details in ft.iteritems():
                    col_cnt =0
                    #print "Inside Target Data Object"
                    for x in details:
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        col_cnt = col_cnt+1

            
                    ti+="<attribute attr_Id="+ "\""+str(d)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm="+ " \""+col+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+t_tp+"\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id="+"\"-1\""+" "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                    ti+="<fldValue></fldValue>\n"
                    ti+="</attribute>\n"
                    cnt3=cnt3+1
                    cnt2=cnt2+1
                    cnt_srt=cnt_srt+1
                    d=d+1
                ti+="<attribute attr_Id="+ "\""+str(d)+ "\""+" "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"source_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+SRC_ID+"&apos;"+quotes+" "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+1)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+ "\""+str(d+1)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"batch_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"4\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$RunId\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+2)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+ "\""+str(d+2)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"audit_date\""+ " "+ "attrPrec=\"30\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"93\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"DI_CF(TIMESTAMP_FORMAT('$$CurrentDateString','YYYYMMDDHH24MISS'))\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+3)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+ "\""+str(d+3)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"source_file_table\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"&apos;$$SrcName&apos;\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+4)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+ "\""+str(d+4)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"country_code\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"1\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+audit_columns_country_code+"&apos;"+quotes+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+5)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+ "\""+str(d+5)+ "\"" + " "+ "obj_Id="+"\""+str(cnt4)+"\""+ " "+ "attrNm=\"created_date\""+ " "+ "attrPrec=\"10\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"91\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"2\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentDate\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+6)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="</attributes>\n"
                ti+="<dObj_FlatFile_Property dObj_Id="+"\""+str(cnt4)+"\""+ " "+ "fileType=\"D\""+ " "+ "colDelim=\"|\""+ " "+ "rowDelim=\"\""+" "+ "txtQual=\"\""+ " "+ "dateTimeFormat=\"\""+ " "+ "skipRows=\"-1\""+ " "+ "escapeChar=\"\""+ " "+ "writeHdrFlag=\"N\""+ " "+ "fileNm="+quotes+Technical_Zone_Name+ SRC_ID + country_code +table_name+".dat"+quotes+" "+ "collItemsDelim=\"\""+" "+ "mapKeysDelim=\"\""+ " "+ "nullValue=\"NULL\""+ " "+ "inputFormatClass=\"org.apache.hadoop.mapred.TextInputFormat\""+ " "+ "outputFormatClass=\"org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat\""+ " "+ "orc_Compression=\"ZLIB\""+ " "+ "orc_Stripe_Size=\"-1\""+ " "+ "orc_Row_Index_Stride=\"-1\""+ " "+ "orc_Compress_Size=\"-1\""+" "+ "orc_Create_Index=\"N\""+ " "+ "compression=\"N\""+ " "+ "compressionClass=\"\""+" "+ "fileFormat=\"TEXTFILE\""+" "+ "convTable=\"Cp037\""+" "+ "distFldSize=\"0\""+ " "+ "newLineSize=\"0\""+ " "+ "serdeJarPath=\"\""+ " "+ "serdeClass=\"org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe\""+ " "+ "serdeProperties=\"&quot;separatorChar&quot;=&quot;\u0001&quot;,&quot;quoteChar&quot;=&quot;&apos;&quot;,&quot;escapeChar&quot;=&quot;\u0004&quot;\""+" "+ "rootElmnt=\"root\""+ " "+ "nameSpc=\"\""+ " "+ "compressionType=\"NONE\""+ " "+ "interCompression=\"FALSE\""+ " "+ "interCompressionClass=\"\""+ " "+ "location="+quotes+table_name+".csv"+quotes+" "+ "dateFormat=\"YYYY-MM-DD\""+ " "+ "parq_Dfs_Blocksize=\"256\""+" "+ "parq_Page_Size=\"65536\""+ " "+ "parq_Dictionary_Page_Size=\"65536\""+ " "+ "parq_Block_Size=\"256\""+ " "+ "parq_Enable_Dictionary=\"Y\""+ " "+ "parq_Compression=\"SNAPPY\""+">\n"
                ti+="<fldOffset>-1</fldOffset>\n"
                ti+="<headerOffset>-1</headerOffset>\n"
                ti+="</dObj_FlatFile_Property>\n"
                ti+="</dataObject>\n"
                cnt4=cnt4+1
                cnt3=((cnt4)*1000)+1
###############################################################################
#
#Writing Target data object for PII enabled Tables        
#
###############################################################################
        for tables in pii_enabled_tables:
            for table_name,ft in sorted(table_dict.items()):
                    if((tables==record) and (table_name==record)):
                        #print("Iside")
                        ti+="<dataObject fldr_Id=\"85427\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm="+"\""+"ingest_cr_bc74\""+">"+"\n"
                        ti+="<dObj dObj_Id=\"73498\""+ " "+"nm="+quotes+Technical_Zone_Name+ SRC_ID + country_code +table_name+"_pii"+quotes+" "+ "aliasNm=\"HADOOP\""+ " "+ "description=\"\""+ " "+ "ver=\"7\""+ " "+ "dbTyp_Id=\"6\""+ " "+ "valid_Cd=\"0\""+ " "+ "localFlag=\"N\""+ " "+ "updateBy=\"lmaddineni\""+ " "+ "lastUpdateBy=\"lmaddineni\""+" "+ "updateDt=\"2017-03-11 07:30:01.906 UTC\""+ " "+ "dObj_ParamNm=\"$DO_HV_HADOOP_"+Technical_Zone_Name+ SRC_ID + country_code +table_name+"\""+" "+ "codepage=\"\""+">"+"\n"
                        ti+="<transient_ScopeFlg>P</transient_ScopeFlg>"+"\n"
                        ti+="<caseSensitiveFlg>N</caseSensitiveFlg>"+"\n"
                        ti+="</dObj>"+"\n"
                        ti+="<attributes>"+"\n"
                        cnt_srt=0
                        for seq,details in ft.iteritems():
                            col_cnt =0
                            for x in details:
                                if col_cnt == 0:
                                    col=str(x)
                                if col_cnt == 1:
                                    s_tp=str(x)
                                if col_cnt == 2:
                                    t_tp=str(x)
                                if col_cnt == 3:
                                    scl=str(x)
                                if col_cnt == 4:
                                    prs=str(x)
                                if col_cnt == 5:
                                    pii=str(x)
                                
                                col_cnt = col_cnt+1
                                #print "bef :col chk count "
                                #print col_cnt
                                if col_cnt == 1:
                                    #print "col chk count "
                                    #print col_cnt
                                    print ""
                    
                            ti+="<attribute attr_Id="+ "\""+str(cnt_pii)+ "\"" + " "+ "obj_Id="+"\""+str(cnt_pii_1)+"\""+ " "+ "attrNm="+ " \""+col+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+t_tp+"\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id="+"\""+str(link_id)+"\""+" "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                            ti+="<fldValue></fldValue>"+"\n"
                            ti+="</attribute>"+"\n"
                            cnt_pii=cnt_pii+1
                            link_attr_id=link_attr_id+1
                            cnt2=cnt2+1
                            cnt_srt=cnt_srt+1
                            
                    
                        ti+="<attribute attr_Id="+ "\""+str(cnt_pii)+ "\"" + " "+ "obj_Id=\"73498\""+ " "+ "attrNm=\"source_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+SRC_ID+"&apos;"+quotes+" "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+1)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        ti+="<attribute attr_Id="+ "\""+str(cnt_pii+1)+ "\"" + " "+ "obj_Id=\"73498\""+ " "+ "attrNm=\"batch_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"04\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$RunId\""+ " "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6+1)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+2)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        ti+="<attribute attr_Id="+ "\""+str(cnt_pii+2)+ "\"" + " "+ "obj_Id=\"73498\""+ " "+ "attrNm=\"audit_date\""+ " "+ "attrPrec=\"30\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"93\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"DI_CF(TIMESTAMP_FORMAT('$$CurrentDateString','YYYYMMDDHH24MISS'))\""+ " "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6+2)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+3)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        ti+="<attribute attr_Id="+ "\""+str(cnt_pii+3)+ "\"" + " "+ "obj_Id=\"73498\""+ " "+ "attrNm=\"source_file_table\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"&apos;$$SrcName&apos;\""+ " "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6+3)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+4)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        ti+="<attribute attr_Id="+ "\""+str(cnt_pii+4)+ "\"" + " "+ "obj_Id=\"73498\""+ " "+ "attrNm=\"Country_Code\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"1\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+audit_columns_country_code+"&apos;"+quotes+ " "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6+4)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+5)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        ti+="<attribute attr_Id="+ "\""+str(cnt_pii+5)+ "\"" + " "+ "obj_Id=\"73498\""+ " "+ "attrNm=\"created_date\""+ " "+ "attrPrec=\"10\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"91\""+ " "+  "attrType_Cd=\"A\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"2\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentDate\""+ " "+ "lnk_Attr_Id="+"\""+str(link_attr_id+6+5)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt+6)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        ti+="</attributes>"+"\n"
                        ti+="<dObj_FlatFile_Property dObj_Id=\"73498\""+ " "+ "fileType=\"D\""+ " "+ "colDelim=\"|\""+ " "+ "rowDelim=\"\""+" "+ "txtQual=\"\""+ " "+ "dateTimeFormat=\"\""+ " "+ "skipRows=\"-1\""+ " "+ "escapeChar=\"\""+ " "+ "writeHdrFlag=\"N\""+ " "+ "fileNm="+quotes+Technical_Zone_Name+ SRC_ID + country_code +table_name+"_pii.dat"+quotes+" "+ "collItemsDelim=\"\""+" "+ "mapKeysDelim=\"\""+ " "+ "nullValue=\"NULL\""+ " "+ "inputFormatClass=\"org.apache.hadoop.mapred.TextInputFormat\""+ " "+ "outputFormatClass=\"org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat\""+ " "+ "orc_Compression=\"ZLIB\""+ " "+ "orc_Stripe_Size=\"-1\""+ " "+ "orc_Row_Index_Stride=\"-1\""+ " "+ "orc_Compress_Size=\"-1\""+" "+ "orc_Create_Index=\"N\""+ " "+ "compression=\"N\""+ " "+ "compressionClass=\"\""+" "+ "fileFormat=\"TEXTFILE\""+" "+ "convTable=\"Cp037\""+" "+ "distFldSize=\"0\""+ " "+ "newLineSize=\"0\""+ " "+ "serdeJarPath=\"\""+ " "+ "serdeClass=\"org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe\""+ " "+ "serdeProperties=\"&quot;separatorChar&quot;=&quot;\u0001&quot;,&quot;quoteChar&quot;=&quot;&apos;&quot;,&quot;escapeChar&quot;=&quot;\u0004&quot;\""+" "+ "rootElmnt=\"root\""+ " "+ "nameSpc=\"\""+ " "+ "compressionType=\"NONE\""+ " "+ "interCompression=\"FALSE\""+ " "+ "interCompressionClass=\"\""+ " "+ "location="+quotes+table_name+".csv"+quotes+" "+ "dateFormat=\"YYYY-MM-DD\""+ " "+ "parq_Dfs_Blocksize=\"256\""+" "+ "parq_Page_Size=\"65536\""+ " "+ "parq_Dictionary_Page_Size=\"65536\""+ " "+ "parq_Block_Size=\"256\""+ " "+ "parq_Enable_Dictionary=\"Y\""+ " "+ "parq_Compression=\"SNAPPY\""+">"+"\n"
                        ti+="<fldOffset>-1</fldOffset>"+"\n"
                        ti+="<headerOffset>-1</headerOffset>"+"\n"
                        ti+="</dObj_FlatFile_Property>"+"\n"
                        ti+="</dataObject>\n"
                        #writer.write(ti)
                        #ti=""
    
    writer.write(ti)
    del ti
    gc.collect()                
    ti=""
    ti+="</dataObjects>\n"
    ti+="<dBFuns/>\n"
    ti+="<udfs/>\n"
    writer.write(ti)
    writer.write("<layers>\n")
    writer.write("<layerObject>\n")
    writer.write("<layer layer_Id=\"-1\""+ " "+ "fldr_Id=\"-1\""+ " "+ "nm=\"\""+" "+ "description=\"\""+ " "+ "srt_Order=\"-1\""+ " "+ "updateDt=\"1900-01-01 00:00:00.0 UTC\""+ " "+ "updateBy=\"\""+" "+ "lastUpdateBy=\"\""+" "+ "change_Ind=\"N\""+ "/>\n")
    writer.write("<designs/>\n")
    writer.write("<streams/>\n")
    writer.write("<solutions/>\n")
    writer.write("</layerObject>\n")
    writer.write("<layerObject>\n")
    writer.write("<layer layer_Id=\"85430\""+ " "+ "fldr_Id=\"85427\""+ " "+ "nm=\"Technical_Zone\""+ " "+ "description=\"\""+" "+ "srt_Order=\"2\""+" "+ "updateDt=\"2017-01-28 14:34:27.755 UTC\""+ " "+ "updateBy=\"\""+ " "+ "lastUpdateBy=\"\""+" "+ "change_Ind=\"N\""+"/>\n")
    writer.write("<designs>\n")
    writer.write("<design fldr_Id=\"85427\""+ " "+ "lockBy=\"\""+ " "+ "mode_Ind=\"I\""+ " "+ "change_Ind=\"N\""+ " "+ "unlock_Ind=\"Y\""+" "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+" "+ "reusableFlag=\"N\""+ " "+ "isDependent=\"true\""+ " "+ "isLinkExist=\"false\""+ " "+ "fldrNm=\"ingest_pa_b6xp\""+ " "+ "layerNm=\"Technical_Zone\""+">\n")
    #print(stream_names)
    writer.write("<dxMp dxMp_Id=\"247993\""+ " "+ "layer_Id=\"85430\""+ " "+ "nm="+quotes+"d_"+stream_names+quotes+" "+ "description=\"\""+ " "+ "ver=\"9\""+ " "+ "nativeDbTyp_Id=\"6\""+ " "+ "reusableFlag=\"N\""+" "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"jkuppuswamy\""+ " "+ "lastUpdateBy=\"jkuppuswamy\""+ " "+ "updateDt=\"2017-03-15 10:11:04.934 UTC\""+ " "+ "change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ "/>\n")
    writer.write("<params/>\n")
    writer.write("<sqlParams/>\n")
    writer.write("<objects>\n")
    #print(str(stream_names))        
    del ti
    gc.collect()

    cnt1=238143000
    cnt10=247994
    
    #cnt2=95539
    ref_id=[]
    i=0
    j=0
    a=1
    a=dObj_Id_value[i]
    for record in temp_table_lists:
        ti=""
        for table_name,ft in sorted(table_dict.items()):
            if(table_name==record):
                a=dObj_Id_value[i]*1000
                ref_id.append(cnt10)
                cnt5=(cnt10*1000)

                #print(str(cnt2))
                #c=cnt2*1000
                #src_obj_ref_id.append(cnt2)
                #dObj_Id_value.append(cnt2)
                #c=cnt2*1000
                ti="<source change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+" "+ "ref_Id="+"\""+str(cnt10)+"\""+">\n"
                ti+="<src_Inst src_Inst_Id="+"\""+str(cnt10)+"\""+ " "+ "dxMp_Id=\"247993\""+ " "+ "dObj_Id="+"\""+str(dObj_Id_value[i])+"\""+ " "+ "instNm="+quotes+"SRC_"+table_name+quotes+" "+ "description=\"\""+ " "+ "ver=\"4\""+ " "+ "nativeFlag=\"N\""+ " "+ "srcFltrCnd=\"\""+ " "+ "srcFltrCndValid_Cd=\"0\""+ " "+ "srcSelDistinctFlag=\"N\""+ " "+ "tformCreateFlag=\"N\""+" "+ "srcRowLimit=\"-1\""+ " "+ "pl_Srt_Order=\"0\""+ " "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"jkuppuswamy\""+ " "+ "updateDt=\"2017-03-15 10:11:04.943 UTC\""+ " "+ "normalizeFlg=\"Y\""+ " "+ "processOn=\"DI\""+">\n"
                ti+="<src_OverrideSql>\n"
                ti+="</src_OverrideSql>\n"
                ti+="<src_OverrideSql_Flg>N</src_OverrideSql_Flg>\n"
                ti+="</src_Inst>\n"
                ti+="<attributes>\n"    
                
                cnt_srt=0
               
                
                for seq,details in ft.iteritems():
                    #print seq
                    #print details
                    col_cnt =0
                    #print "chk count "
            
                    for x in details:
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        col_cnt = col_cnt+1

            
                    ti+="<attribute attr_Id="+ "\""+str(cnt5)+ "\"" +" "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm="+ "\""+col+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+t_tp+"\""+ " "+ "attrType_Cd=\"A\""+" "+ "notNullFlag=\"1\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"\""+ " "+ "lnk_Attr_Id=\""+str(a)+"\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"0\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id="+"\""+str(dObj_Id_value[i])+"\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"0\""+">\n"
                    ti+="<fldValue></fldValue>\n"
                    ti+="</attribute>\n"
                    cnt5=cnt5+1
                    cnt1=cnt1+1
                    cnt_srt=cnt_srt+1
                    a=a+1
                
                ti+="</attributes>\n"
                ti+="<derivedAttributes>\n"
                CNT=0
                ti+="<attribute attr_Id="+"\""+str(cnt5)+ "\""+ " "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm=\"source_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+ "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+SRC_ID+"&apos;"+quotes+" "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(CNT+0)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+"\""+str(cnt5+1)+ "\""+ " "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm=\"batch_id\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"4\""+ " "+  "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$RunId\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(CNT+1)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+"\""+str(cnt5+2)+ "\""+ " "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm=\"audit_date\""+ " "+ "attrPrec=\"30\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"93\""+ " "+  "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"DI_CF(TIMESTAMP_FORMAT('$$CurrentDateString','YYYYMMDDHH24MISS'))\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(CNT+2)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+"\""+str(cnt5+3)+ "\""+ " "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm=\"source_file_table\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"&apos;$$SrcName&apos;\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(CNT+3)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+"\""+str(cnt5+4)+ "\""+ " "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm=\"country_code\""+ " "+ "attrPrec=\"0\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"12\""+ " "+  "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"1\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"&apos;"+audit_columns_country_code+"&apos;"+quotes+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(CNT+4)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                ti+="<attribute attr_Id="+"\""+str(cnt5+5)+ "\""+ " "+ "obj_Id="+"\""+str(cnt10)+"\""+ " "+ "attrNm=\"created_date\""+ " "+ "attrPrec=\"10\""+" "+ "attrScale=\"0\""+ " "+ "attrDTyp_Id=\"91\""+ " "+  "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"2\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal=\"$$CurrentDate\""+ " "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(CNT+5)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">\n"
                ti+="<fldValue></fldValue>\n"
                ti+="</attribute>\n"
                for seq,details in ft.iteritems():
                    col_cnt =0
                    for x in details:
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        if col_cnt == 5:
                            pii=str(x)
                        
                        col_cnt = col_cnt+1
                    if(str(pii) == "y" and str(t_tp) == '12'):
            
                        #print(cnt1-1)
                        ti+="<attribute attr_Id="+ "\""+str(cnt5+7)+ "\"" +" "+ "obj_Id="+"\""+str(cnt6+1)+"\""+ " "+ "attrNm="+ "\""+str(col).upper()+"_P"+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+t_tp+"\""+ " "+ "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"DI_CF( CASE WHEN LENGTH(TRIM(::ATTR:"+str(dObj_Id_value[i])+"."+str(src_attr_Id[j])+"::)) = 0 THEN &apos; &apos; ELSE REPEAT(&apos;X&apos;,LENGTH(CAST(::ATTR:"+str(dObj_Id_value[i])+"."+str(src_attr_Id[j])+":: as VARCHAR(40)))) END)"+quotes+" "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        cnt5=cnt5+1
                        cnt_srt=cnt_srt+1
                        j=j+1
                    
                    if(str(pii) == "y" and str(t_tp) == '3'):
                        #print(cnt1-1)
                        ti+="<attribute attr_Id="+ "\""+str(cnt5+7)+ "\"" +" "+ "obj_Id="+"\""+str(cnt6+1)+"\""+ " "+ "attrNm="+ "\""+str(col).upper()+"_P"+"\""+ " "+"attrPrec="+ " \""+prs+"\""+ " "+"attrScale="+ " \""+scl+ "\""+ " "+"attrDTyp_Id="+ "\""+t_tp+"\""+ " "+ "attrType_Cd=\"D\""+" "+ "notNullFlag=\"0\""+ " "+ "distKeyFlag=\"0\""+ " "+ "attrKeyTyp_Id=\"0\""+ " "+ "attrExprVal="+quotes+"DI_CF(CAST(REPEAT('9',LENGTH(::ATTR:"+str(cnt2)+"."+str(c)+"::)) as bigINT))"+quotes+" "+ "lnk_Attr_Id=\"-1\""+ " "+ "parent_Attr_Id=\"-1\""+ " "+ "orgKeyFlag=\"0\""+ " "+ "upiFlag=\"0\""+ " "+ "usiFlag=\"0\""+ " "+ "nupiFlag=\"0\""+ " "+ "nusiFlag=\"0\""+ " "+ "ref_Id=\"-1\""+ " "+ "ref_Cd=\"\""+ " "+"valid_Cd=\"0\""+ " "+"srt_Order="+ "\""+str(cnt_srt)+"\""+" "+ "orderBy=\"0\""+ " "+ "clevel=\"0\""+ " "+ "occurs=\"1\"" + " "+  "redefines=\"-1\""+" "+ "signed=\"N\""+ " "+ "tsigned=\"N\""+ " "+ "isigned=\"N\""+ " "+ "rdeci=\"N\""+ " "+ "colformat=\"\""+ " "+ "lnk_Obj_Id=\"-1\""+ " "+ "dependingOn=\"-1\""+ " "+ "fldFormatValue=\"\""+ " "+ "minOccurs=\"1\""+">"+"\n"
                        ti+="<fldValue></fldValue>"+"\n"
                        ti+="</attribute>"+"\n"
                        cnt5=cnt5+1
                        cnt_srt=cnt_srt+1
                
                ti+="</derivedAttributes>\n"
                ti+="<tx_Inst_Properties/>\n"
                ti+="<nativeDbTyp_Id>6</nativeDbTyp_Id>\n"
                ti+="</source>\n"
                cnt10=cnt10+1
                cnt5=((cnt10)*1000)+1
                cnt2=cnt2+1
                cnt1=((cnt2)*1000)+1
                i=i+1
                writer.write(ti)
                del ti
                gc.collect()
                        
    cnt4=238152
    cnt2=238143
    cnt12=cnt2*1000
    cnt13=cnt4*1000
    ref_id_tgt=[]
    i=0
    #cnt10=cnt10-1
    ti=""
    splt_inst_id=73505
    splt_inst_id_list=[]
    for record in temp_table_lists:
        #i=0
        for table_name,ft in sorted(table_dict.items()):
            if(table_name==record):
                b=ref_id[i]*1000
                ref_id_tgt.append(cnt11)
                ti="<target change_Ind=\"N\""+ "  "+ "error_Cd=\"0\""+  " "+ "error_Msg=\"\""+ " "+ "ref_Id="+"\""+str(cnt11)+ "\""+">\n"
                ti+="<tgt_Inst tgt_Inst_Id="+"\""+str(cnt11)+ "\""+ " "+ "dxMp_Id=\"247993\""+ " "+ "dObj_Id="+"\""+str(cnt4)+"\""+ " "+ "instNm=\""+Technical_Zone_Name+ Prj_EPM_Code  + country_code +table_name+ "\""+" "+ "description=\"\""+ " "+ "ver=\"8\""+ " "+ "nativeFlag=\"Y\""+ " "+ "tgtLoadType=\"INS\""+ " "+ "truncFlag=\"Y\""+ " "+  "scdType=\"DATE\""+ " "+ "scdDefStartDt=\"TO_DATE(&apos;01/01/1900&apos;,&apos;MM/DD/YYYY&apos;)\""+ " "+ "scdDefEndDt=\"TO_DATE(&apos;12/31/2099&apos;,&apos;MM/DD/YYYY&apos;)\""+ " "+ "scdDefStartKey=\"19000101\""+ " "+ "scdDefEndKey=\"20991231\""+ " "+ "scdDefStartFlag=\"N\""+ " "+ "scdDefEndFlag=\"Y\""+ " "+ "scdOffset=\"-1\""+ " "+ "pl_Srt_Order=\"0\""+ " "+  "tgt_Srt_Order=\"1\""+ " "+ "tgtCreateFlag=\"N\""+ " "+ "pre_DCmd=\"\""+ " "+ "post_DCmd=\"\""+" "+ "pre_DCmdValid_Cd=\"0\""+ " "+ "post_DCmdValid_Cd=\"0\""+ " "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"mbs\""+ " "+ "updateDt=\"2017-04-14 10:16:27.665 UTC\""+ " "+ "primObjId="+"\""+str(ref_id[i])+"\""+"/>\n"
                ti+="<tgt_Attr_Lnks>\n"
            
            
                for seq,details in ft.iteritems():
                    #print seq
                    #print details
                    col_cnt =0
                    #print "chk count "
                    
                    for x in details:
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                        col_cnt = col_cnt+1
                        
                    ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+ " "+"tgt_dObj_Inst_Attr_Id="+ "\""+str(cnt13)+ "\""+ " "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+"lnk_Obj_Attr_Id="+ "\""+str(b)+ "\"" + " "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+ "/>\n"
                    cnt5=cnt5+1
                    cnt13=cnt13+1
                    cnt12=cnt12+1
                    b=b+1

            
                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt13)+"\""+" "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+ "lnk_Obj_Attr_Id="+ "\""+str(b)+ "\"" +" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>\n"
                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt13+1)+"\""+" "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+ "lnk_Obj_Attr_Id="+ "\""+str(b+1)+ "\"" +" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>\n"
                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt13+2)+"\""+" "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+ "lnk_Obj_Attr_Id="+ "\""+str(b+2)+ "\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>\n"
                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt13+3)+"\""+" "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+ "lnk_Obj_Attr_Id="+ "\""+str(b+3)+ "\"" +" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>\n"
                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt13+4)+"\""+" "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+ "lnk_Obj_Attr_Id="+ "\""+str(b+4)+ "\"" +" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>\n"
                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt11)+ "\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(cnt13+5)+"\""+" "+ "lnk_Obj_Id="+"\""+str(ref_id[i])+"\""+ " "+ "lnk_Obj_Attr_Id="+ "\""+str(b+5)+ "\"" +" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>\n"
                ti+="</tgt_Attr_Lnks>\n"
                ti+="<nativeDbTyp_Id>6</nativeDbTyp_Id>\n"
                ti+="<mJnr_Inst_Cnds/>\n"
                ti+="</target>\n"
                cnt11=cnt11+1
                cnt10=cnt10+1
                cnt5=((cnt10)*1000)+1
                cnt4=cnt4+1
                cnt13=((cnt4)*1000)
                cnt2=cnt2+1
                cnt12=((cnt2)*1000)+1
                i=i+1
                
            if (table_name==record):
                for tables in pii_enabled_tables:
                    for table_name,ft in sorted(table_dict.items()):
                        if((tables==record) and (table_name==tables)):
                            ti+="<target change_Ind=\"N\""+ "  "+ "error_Cd=\"0\""+  " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"95544\""+">"+"\n"
                            ti+="<tgt_Inst tgt_Inst_Id=\"95544\""+ " "+ "dxMp_Id=\"95541\""+ " "+ "dObj_Id=\"73498\""+ " "+ "instNm=\""+Technical_Zone_Name+ SRC_ID  + country_code +table_name+"_pii"+"\""+" "+ "description=\"\""+ " "+ "ver=\"8\""+ " "+ "nativeFlag=\"Y\""+ " "+ "tgtLoadType=\"INS\""+ " "+ "truncFlag=\"Y\""+ " "+  "scdType=\"DATE\""+ " "+ "scdDefStartDt=\"TO_DATE(&apos;01/01/1900&apos;,&apos;MM/DD/YYYY&apos;\""+ " "+ "scdDefEndDt=\"TO_DATE(&apos;12/31/2099&apos;,&apos;MM/DD/YYYY&apos;\""+ " "+ "scdDefStartKey=\"19000101\""+ " "+ "scdDefEndKey=\"20991231\""+ " "+ "scdDefStartFlag=\"N\""+ " "+ "scdDefEndFlag=\"Y\""+ " "+ "scdOffset=\"-1\""+ " "+ "pl_Srt_Order=\"0\""+ " "+  "tgt_Srt_Order=\"1\""+ " "+ "tgtCreateFlag=\"N\""+ " "+ "pre_DCmd=\"\""+ " "+ "post_DCmd=\"\""+" "+ "pre_DCmdValid_Cd=\"0\""+ " "+ "post_DCmdValid_Cd=\"0\""+ " "+ "valid_Cd=\"0\""+ " "+ "updateBy=\"mbs\""+ " "+ "updateDt=\"2017-04-14 10:16:27.665 UTC\""+ " "+ "primObjId=\"95542\""+"/>"+"\n"
                            ti+="<tgt_Attr_Lnks>"+"\n"
                            PII_ID_TGT=73498000
                            for seq,details in ft.iteritems():
                                col_cnt =0
                                for x in details:
                                    if col_cnt == 0:
                                        col=str(x)
                                    if col_cnt == 1:
                                        s_tp=str(x)
                                    if col_cnt == 2:
                                        t_tp=str(x)
                                    if col_cnt == 3:
                                        scl=str(x)
                                    if col_cnt == 4:
                                        prs=str(x)
                                    if col_cnt == 5:
                                        pii=str(x)
                                    #col_cnt = col_cnt+1
                        
                                ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id="+"\""+str(cnt_pii_2)+ "\""+ " "+"tgt_dObj_Inst_Attr_Id="+ "\""+str(PII_ID_TGT)+ "\""+ " "+ "lnk_Obj_Id="+"\""+str(cnt6+1)+ "\""+ " "+"lnk_Obj_Attr_Id="+"\""+str(cnt8)+ "\""+ " "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+ "/>"+"\n"
                                cnt8=cnt8+1
                                PII_ID_TGT=PII_ID_TGT+1
                                cnt5=cnt5+1 
                        
                            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id=\"95544\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(PII_ID_TGT)+"\""+" "+ "lnk_Obj_Id=\"95542\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(cnt8)+"\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+"\n"
                            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id=\"95544\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(PII_ID_TGT+1)+"\""+" "+ "lnk_Obj_Id=\"95542\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(cnt8+1)+"\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+"\n"
                            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id=\"95544\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(PII_ID_TGT+2)+"\""+" "+ "lnk_Obj_Id=\"95542\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(cnt8+2)+"\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+"\n"
                            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id=\"95544\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(PII_ID_TGT+3)+"\""+" "+ "lnk_Obj_Id=\"95542\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(cnt8+3)+"\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+"\n"
                            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id=\"95544\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(PII_ID_TGT+4)+"\""+" "+ "lnk_Obj_Id=\"95542\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(cnt8+4)+"\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+"\n"
                            ti+="<tgt_Attr_Lnk tgt_dObj_Inst_Id=\"95544\""+" "+ "tgt_dObj_Inst_Attr_Id="+"\""+str(PII_ID_TGT+5)+"\""+" "+ "lnk_Obj_Id=\"95542\""+ " "+ "lnk_Obj_Attr_Id="+"\""+str(cnt8+5)+"\""+" "+ "updKeyFlag=\"N\""+ " "+ "scdStartDtFlag=\"N\""+ " "+ "scdEndDtFlag=\"N\""+ " "+ "currIndFlag=\"N\""+ " "+ "scdFlag=\"N\""+"/>"+"\n"
                            ti+="</tgt_Attr_Lnks>"+"\n"
                            ti+="<nativeDbTyp_Id>6</nativeDbTyp_Id>"+"\n"
                            ti+="<mJnr_Inst_Cnds/>"+"\n"
                            ti+="</target>"+"\n"
                            
                            #SPLITTER ONLY TO BE IMPLEMENTED WHEN TABLE IS PII ENABLE
                            splt_inst_id_list.append(splt_inst_id)
                            ti+="<splitter nativeDbTyp_Id=\"6\""+ " "+ "change_Ind=\"N\""+ " "+ "error_Cd=\"0\""+ " "+ "error_Msg=\"\""+ " "+ "ref_Id=\"-1\""+">"+"\n"
                            ti+="<splt_Inst splt_Inst_Id=\""+str(splt_inst_id)+"\""+ " "+ "dxMp_Id=\"95541\""+ " "+ "nm="+quotes+table_name+quotes+" "+ "description=\"\""+ " "+ "ver=\"1\""+ " "+ "valid_Cd=\"0\""+ " "+ "updateDt=\"2017-02-07 00:00:00.0 UTC\""+ " "+ "updateBy=\"lmaddineni\""+ " "+ "lastUpdateBy=\"lmaddineni\""+"/>"+"\n"
                            ti+="<splt_Inst_Cnds>"+"\n"
                            ti+="<splt_Inst_Cnd splt_Inst_Cnd_Id=\""+str(splt_inst_id)+"000"+"\""+" "+"splt_Inst_Id=\""+str(splt_inst_id)+"\""+ " "+ "spltCndNm=\"1\""+ " "+ "spltCnd=\"true\""+" "+ "valid_Cd=\"0\""+ " "+ "srt_Order=\"0\""+"/>"+"\n"
                            ti+="<splt_Inst_Cnd splt_Inst_Cnd_Id=\""+str(splt_inst_id)+"001"+"\""+" "+"splt_Inst_Id=\""+str(splt_inst_id)+"\""+ " "+ "spltCndNm=\"2\""+ " "+ "spltCnd=\"true\""+" "+ "valid_Cd=\"0\""+ " "+ "srt_Order=\"1\""+"/>"+"\n"
                            ti+="</splt_Inst_Cnds>"+"\n"
                            ti+="</splitter>"+"\n"
                            splt_inst_id=splt_inst_id+1
                            
                        
                            # SPLITTER PART ENDS
                
                writer.write(ti)
                del ti
                gc.collect()
    
    
    ti=""
    #print(stream_names)


    
    ti=""
    ti+="</objects>\n"
    ti+="<dxMp_Fwd_Lnks>\n"
    i=0
    flag=0
    for record in temp_table_lists:
        #print("hola")
        for table_name,ft in sorted(table_dict.items()):
            
            if(table_name==record):
                #print(table_name)
                for seq,details in ft.iteritems():
                    col_cnt =0
                    for x in details:
                        #print("inside details")
                        if col_cnt == 0:
                            col=str(x)
                        if col_cnt == 1:
                            s_tp=str(x)
                        if col_cnt == 2:
                            t_tp=str(x)
                        if col_cnt == 3:
                            scl=str(x)
                        if col_cnt == 4:
                            prs=str(x)
                            #print(prs)
                        if col_cnt == 5:
                            pii=str(x)
                            #print(pii)
                            if(str(pii)=="y"):
                                #print("Setting Flag")
                                flag=1
                        col_cnt = col_cnt+1
        
    k=0
    for k in range(0,len(ref_id)):
        ti+="<dxMp_Fwd_Lnk dxMp_Id=\"247993\" obj_Id=\""+str(ref_id[k])+"\" fwd_Lnk_Obj_Id=\""+str(ref_id_tgt[k])+"\" grp_Id=\"-1\" fwd_Lnk_Grp_Id=\"-1\" obj_Cd=\"DOBJIS\" fwd_Lnk_Obj_Cd=\"DOBJIT\" lnkNm=\"\" error_Cd=\"0\" error_Msg=\"\"/>\n"
    '''
    if(flag==1):
        
        for record in ref_id:
            for j in ref_id_tgt:
                #print "inside"
                if(ref_id_tgt.index(j)==i):
                    writer.write("<dxMp_Fwd_Lnk dxMp_Id=\"247993\" obj_Id=\""+str(ref_id[i])+"\" fwd_Lnk_Obj_Id=\""+str(splt_inst_id_list[i])+"\" grp_Id=\"-1\" fwd_Lnk_Grp_Id=\"-1\" obj_Cd=\"DOBJIS\" fwd_Lnk_Obj_Cd=\"SPLT\" lnkNm=\"\" error_Cd=\"0\" error_Msg=\"\"/>\n")
                    writer.write("<dxMp_Fwd_Lnk dxMp_Id=\"247993\" obj_Id=\""+str(splt_inst_id_list[i])+"\" fwd_Lnk_Obj_Id=\""+str(ref_id_tgt[i])+"\" grp_Id=\""+str(splt_inst_id_list[i])+"000"+"\" fwd_Lnk_Grp_Id=\"-1\" obj_Cd=\"SPLT\" fwd_Lnk_Obj_Cd=\"DOBJIT\" lnkNm=\"\" error_Cd=\"0\" error_Msg=\"\"/>\n")
            i=i+1
        
    '''
    ti+="</dxMp_Fwd_Lnks>\n"
    ti+="<dependent_Ids/>\n"
    ti+="</design>\n"
    ti+="</designs>\n"
    writer.write(ti)
    del ti
    gc.collect()
    ti=""
    stream_flow_id = "248006"
    #audit
    
    ti+="<streams>\n"
    ti+="<stream fldr_Id=\"85427\" lockBy=\"\" mode_Ind=\"W\" change_Ind=\"N\" unlock_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\" fldrNm=\"ingest_pa_bb76\" isDependent=\"false\">\n"
    ti+="<dxFlow dxFlow_Id=\""+stream_flow_id+"\" layer_Id=\"85430\" nm=\""+"s_"+stream_names+"\" description=\"\" ver=\"2\" paramFilePath=\"\" paramFileNm=\"\" valid_Cd=\"0\" updateBy=\"srana1\" lastUpdateBy=\"srana1\" updateDt=\"2017-06-15 14:00:52.726 UTC\" dxFlow_Type=\"R\" change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\"/>\n"
    ti+="<params/>\n"
    ti+="<sqlParams/>\n"
    ti+="<objects>\n"
    ti+="<dbCommand change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\">\n"
    ti+="<dCmd_Inst dxFlow_Id=\""+stream_flow_id+"\" dCmd_Inst_Id=\"248007\" nm=\""+stream_names+"\" description=\"\" ver=\"1\" nativeDbTyp_Id=\"6\" dCmd=\""
    
    audit_sql="set hive.exec.dynamic.partition=TRUE;&#xd;set hive.exec.dynamic.partition.mode=nonstrict;&#xd;"
    tab = "cedl_audit_cntrl_streams"
    audit_sql+="insert into "+ tab + " partition(created_date, source_id)&#xd;"
    
    loop = 0
    for j in ref_id_tgt:
        if loop != 0:
            audit_sql+="union all "
        audit_sql+="select&#xd;&apos;$$JobName&apos;&#xd;,&apos;"+Technical_Zone_Name+ SRC_ID + Country_Code+temp_table_lists[loop] + "&apos;&#xd;,CASE&#xd; when ::RTSU:248008.Status::=&apos;S&apos; THEN &apos;Success&apos;&#xd; when ::RTSU:248008.Status::=&apos;F&apos; THEN &apos;Failed&apos;&#xd; else &apos;unknown&apos;&#xd; end&#xd;,::RTSU:248008.ReturnCode::&#xd;,$$RunId&#xd;,&apos;$$RunBy&apos;&#xd;,::RTST:248008."+str(j)+".SourceCount::&#xd;,::RTST:248008."+str(j)+".TargetCount::&#xd;,::RTST:248008."+str(j)+".BadCount::&#xd;,$$CurrentTimeStamp&#xd;,$$CurrentDate&#xd;,&apos;b6xp&apos;&#xd;from audit_cntrl_dual&#xd;"
        loop = loop + 1

    ti+=audit_sql
    ti+="\" valid_Cd=\"0\" updateBy=\"srana1\" lastUpdateBy=\"srana1\" updateDt=\"2017-06-15 14:00:18.143 UTC\" conn_Valid_Cd=\"0\" disableFlg=\"N\" fileNm=\"\" location=\"\" sqlFileFlg=\"N\"/>\n"
    ti+="<conn_Db_Obj_Lnk_Native conn_Id=\""+tgt_conn_id+"\" dxFlow_Id=\""+stream_flow_id+"\" dxMp_Inst_Id=\"248007\" obj_Id=\"1\" conn_Db_Id=\""+tgt_conn_id+"002\" obj_Cd=\"NATIVE\"/>\n"
    ti+="<conn_Db_Obj_Lnk_Ext conn_Id=\"-1\" dxFlow_Id=\""+stream_flow_id+"\" dxMp_Inst_Id=\"248007\" obj_Id=\"-1\" conn_Db_Id=\"-1\" obj_Cd=\"EXT\"/>\n"
    ti+="<dxFlow_Obj_Properties>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248007\" property_Id=\"-1\" property_Cd=\"JDBC_TRAN_CTL\" property_Nm=\"JDBC_TRAN_CTL\" property_Val=\"N\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248007\" property_Id=\"-1\" property_Cd=\"LOGGING_LEVEL\" property_Nm=\"LOGGING_LEVEL\" property_Val=\"INFO\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248007\" property_Id=\"-1\" property_Cd=\"TFORM_CLEANUP\" property_Nm=\"TFORM_CLEANUP\" property_Val=\"Y\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="</dxFlow_Obj_Properties>\n"
    ti+="</dbCommand>\n"
    ti+="<designJob change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\">\n"
    ti+="<dxMp_Inst dxMp_Inst_Id=\"248008\" dxFlow_Id=\""+stream_flow_id+"\" instNm=\"d_"+stream_names+"\" description=\"\" ver=\"2\" valid_Cd=\"0\" dxMp_Id=\"247993\" updateBy=\"srana1\" lastUpdateBy=\"srana1\" updateDt=\"2017-06-15 14:00:52.751 UTC\" disableFlg=\"N\"/>\n"
    
    
    ti+="<conn_Db_Obj_Lnks>\n"
    

    
    ti+="<Conn_Db_Obj_Lnk conn_Id=\""+tgt_conn_id+"\" dxFlow_Id=\""+stream_flow_id+"\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" conn_Db_Id=\"-1\" obj_Cd=\"\"/>\n"
    
    for items in ref_id:
        ti+="<Conn_Db_Obj_Lnk conn_Id=\""+src_conn_id+"\" dxFlow_Id=\""+stream_flow_id+"\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" conn_Db_Id=\""+str(src_schema)+"\" obj_Cd=\"DOBJIS\"/>\n"
    
    for items in ref_id_tgt:
        ti+="<Conn_Db_Obj_Lnk conn_Id=\""+tgt_conn_id+"\" dxFlow_Id=\""+stream_flow_id+"\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" conn_Db_Id=\""+str(tgt_schema)+"\" obj_Cd=\"DOBJIT\"/>\n"
        
    ti+="</conn_Db_Obj_Lnks>\n"
    
    ti+="<dObj_Inst_Properties>\n"
    
    writer.write(ti)
    del ti
    gc.collect()

    

    for items in ref_id:
        
        ti=""
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600000\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"LOADTYPE\" propertyVal=\"HDEXTTBL\" dbTyp_Id=\"5\" srt_Order=\"0\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500000\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"EXTRACTTYPE\" propertyVal=\"JDBC\" dbTyp_Id=\"5\" srt_Order=\"0\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600000\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"LOADTYPE\" propertyVal=\"HDEXTTBL\" dbTyp_Id=\"5\" srt_Order=\"0\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500000\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"EXTRACTTYPE\" propertyVal=\"JDBC\" dbTyp_Id=\"5\" srt_Order=\"0\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500001\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"EXTRACT_MODE\" propertyVal=\"F\" dbTyp_Id=\"5\" srt_Order=\"1\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500001\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"EXTRACT_MODE\" propertyVal=\"F\" dbTyp_Id=\"5\" srt_Order=\"1\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500002\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COLUMN_DELIMITER\" propertyVal=\"01\" dbTyp_Id=\"5\" srt_Order=\"2\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500002\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COLUMN_DELIMITER\" propertyVal=\"01\" dbTyp_Id=\"5\" srt_Order=\"2\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600003\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"TRANSFER_TYPE\" propertyVal=\"hadoop\" dbTyp_Id=\"5\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500003\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_STYLE\" propertyVal=\"YMD\" dbTyp_Id=\"5\" srt_Order=\"3\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600003\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"TRANSFER_TYPE\" propertyVal=\"hadoop\" dbTyp_Id=\"5\" srt_Order=\"3\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500003\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_STYLE\" propertyVal=\"YMD\" dbTyp_Id=\"5\" srt_Order=\"3\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500004\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_DELIM\" propertyVal=\"-\" dbTyp_Id=\"5\" srt_Order=\"4\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500004\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DATE_DELIM\" propertyVal=\"-\" dbTyp_Id=\"5\" srt_Order=\"4\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600100\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"PROFILE\" propertyVal=\"HdfsTextSimple\" dbTyp_Id=\"5\" srt_Order=\"5\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500005\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_STYLE\" propertyVal=\"24HOUR\" dbTyp_Id=\"5\" srt_Order=\"5\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600100\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"PROFILE\" propertyVal=\"HdfsTextSimple\" dbTyp_Id=\"5\" srt_Order=\"5\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500005\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_STYLE\" propertyVal=\"24HOUR\" dbTyp_Id=\"5\" srt_Order=\"5\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500006\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_DELIM\" propertyVal=\":\" dbTyp_Id=\"5\" srt_Order=\"6\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500006\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TIME_DELIM\" propertyVal=\":\" dbTyp_Id=\"5\" srt_Order=\"6\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600101\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"L_FORMAT\" propertyVal=\"TEXT\" dbTyp_Id=\"5\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600101\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"L_FORMAT\" propertyVal=\"TEXT\" dbTyp_Id=\"5\" srt_Order=\"6\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600102\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"FORMATTER\" propertyVal=\"pxfwritable_import\" dbTyp_Id=\"5\" srt_Order=\"7\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500007\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TEXT_QUALIFIER\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"7\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600102\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"FORMATTER\" propertyVal=\"pxfwritable_import\" dbTyp_Id=\"5\" srt_Order=\"7\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500007\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"TEXT_QUALIFIER\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"7\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500008\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ESC_CHAR\" propertyVal=\"04\" dbTyp_Id=\"5\" srt_Order=\"8\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600103\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMIT\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"8\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500008\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ESC_CHAR\" propertyVal=\"04\" dbTyp_Id=\"5\" srt_Order=\"8\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600103\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMIT\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"8\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500009\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_TYPE\" propertyVal=\"D\" dbTyp_Id=\"5\" srt_Order=\"9\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500012\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DECI_DELIM\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500012\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"DECI_DELIM\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500009\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"FILE_TYPE\" propertyVal=\"D\" dbTyp_Id=\"5\" srt_Order=\"9\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600104\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMITTYPE\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600104\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORLIMITTYPE\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"9\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600105\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORTABLE\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"10\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600105\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"ERRORTABLE\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"10\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500023\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"LFINSTRING\" propertyVal=\"OFF\" dbTyp_Id=\"5\" srt_Order=\"11\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500016\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"NULLVALUE\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"11\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500023\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"LFINSTRING\" propertyVal=\"OFF\" dbTyp_Id=\"5\" srt_Order=\"11\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500016\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"NULLVALUE\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"11\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600107\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"GPXFPORT\" propertyVal=\"50070\" dbTyp_Id=\"5\" srt_Order=\"12\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600107\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"GPXFPORT\" propertyVal=\"50070\" dbTyp_Id=\"5\" srt_Order=\"12\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600108\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXT_TBL_SCOPE\" propertyVal=\"L\" dbTyp_Id=\"5\" srt_Order=\"13\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600108\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXT_TBL_SCOPE\" propertyVal=\"L\" dbTyp_Id=\"5\" srt_Order=\"13\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600109\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"CREATE_EXTERNAL_TABLE_FLAG\" propertyVal=\"N\" dbTyp_Id=\"5\" srt_Order=\"14\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600109\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"CREATE_EXTERNAL_TABLE_FLAG\" propertyVal=\"N\" dbTyp_Id=\"5\" srt_Order=\"14\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600110\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXTERNAL_TABLE_NAME\" propertyVal=\"instNm\" dbTyp_Id=\"5\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500022\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"ENABLE_PARTITION\" propertyVal=\"N\" dbTyp_Id=\"5\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500017\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"NO_OF_JDBC_PARTITIONS\" propertyVal=\"2\" dbTyp_Id=\"5\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500022\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"ENABLE_PARTITION\" propertyVal=\"N\" dbTyp_Id=\"5\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500017\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"NO_OF_JDBC_PARTITIONS\" propertyVal=\"2\" dbTyp_Id=\"5\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"20600110\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"L\" propertyNm=\"EXTERNAL_TABLE_NAME\" propertyVal=\"SRC_MNTPG\" dbTyp_Id=\"5\" srt_Order=\"15\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500020\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"PARTITION_KEY\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"17\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500020\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"PARTITION_KEY\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"17\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500010\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"METHOD_N\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"18\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500010\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"METHOD_N\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"18\" defView=\"N\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500021\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"PARTITION_CRITERIA\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"18\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500021\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"P\" propertyNm=\"PARTITION_CRITERIA\" propertyVal=\"\" dbTyp_Id=\"5\" srt_Order=\"18\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500025\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"JDBC_OPTIONS\" propertyVal=\"block size=512\" dbTyp_Id=\"5\" srt_Order=\"25\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500025\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"JDBC_OPTIONS\" propertyVal=\"block size=512\" dbTyp_Id=\"5\" srt_Order=\"25\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500026\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION\" propertyVal=\"Y\" dbTyp_Id=\"5\" srt_Order=\"26\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500026\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION\" propertyVal=\"Y\" dbTyp_Id=\"5\" srt_Order=\"26\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500027\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION_TYPE\" propertyVal=\"gzip\" dbTyp_Id=\"5\" srt_Order=\"27\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500027\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"COMPRESSION_TYPE\" propertyVal=\"gzip\" dbTyp_Id=\"5\" srt_Order=\"27\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500028\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION\" propertyVal=\"Y\" dbTyp_Id=\"5\" srt_Order=\"28\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500028\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION\" propertyVal=\"Y\" dbTyp_Id=\"5\" srt_Order=\"28\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500030\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION_TYPE\" propertyVal=\"AES-128\" dbTyp_Id=\"5\" srt_Order=\"29\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500030\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTION_TYPE\" propertyVal=\"AES-128\" dbTyp_Id=\"5\" srt_Order=\"29\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500031\" dxMp_Inst_Id=\"248008\" obj_Id=\""+str(items)+"\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTED_AES_SECRET_KEY\" propertyVal=\"N\" dbTyp_Id=\"5\" srt_Order=\"30\" defView=\"Y\"/>\n"
        ti+="<dObj_Inst_Property dxFlow_Id=\""+stream_flow_id+"\" property_Id=\"10500031\" dxMp_Inst_Id=\"248008\" obj_Id=\"-1\" obj_Cd=\"DOBJIS\" propertyType=\"E\" propertyNm=\"ENCRYPTED_AES_SECRET_KEY\" propertyVal=\"N\" dbTyp_Id=\"5\" srt_Order=\"30\" defView=\"Y\"/>\n"
        writer.write(ti)
        del ti
        gc.collect()

    
    ti=""
    
    ti+="</dObj_Inst_Properties>\n"
    
    ti+="<dxFlow_Obj_Properties>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000002\" property_Cd=\"LOGGING_LEVEL\" property_Nm=\"Logging Level\" property_Val=\"INFO\" srt_Order=\"1\" property_Type=\"O\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000003\" property_Cd=\"TFORM_CLEANUP\" property_Nm=\"Tform Cleanup\" property_Val=\"Y\" srt_Order=\"2\" property_Type=\"O\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"900068\" property_Cd=\"hive.exec.dynamic.partition\" property_Nm=\"hive.exec.dynamic.partition\" property_Val=\"TRUE\" srt_Order=\"2\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"900069\" property_Cd=\"hive.exec.dynamic.partition.mode\" property_Nm=\"hive.exec.dynamic.partition.mode\" property_Val=\"nonstrict\" srt_Order=\"2\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"900170\" property_Cd=\"hive.mapred.supports.subdirectories\" property_Nm=\"hive.mapred.supports.subdirectories\" property_Val=\"TRUE\" srt_Order=\"2\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000004\" property_Cd=\"FIELD_DELIMITER\" property_Nm=\"Field Delimiter\" property_Val=\"01\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000010\" property_Cd=\"FILE_FORMAT\" property_Nm=\"File Format\" property_Val=\"TEXTFILE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"2479933\" property_Cd=\"hive.auto.convert.sortmerge.join\" property_Nm=\"hive.auto.convert.sortmerge.join\" property_Val=\"NA\" srt_Order=\"3\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000016\" property_Cd=\"INPUT_FORMAT_CLASS\" property_Nm=\"Input Format Class\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000018\" property_Cd=\"COMPRESSION\" property_Nm=\"Compression\" property_Val=\"FALSE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000020\" property_Cd=\"COMPRESSION_CODEC\" property_Nm=\"Compression Codec\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000019\" property_Cd=\"COMPRESSION_TYPE\" property_Nm=\"Compression Type\" property_Val=\"NONE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000005\" property_Cd=\"ESCAPE_CHARECTER\" property_Nm=\"Escape charecter\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000015\" property_Cd=\"ORC_COMPRESSION_SIZE\" property_Nm=\"Orc Compression Size\" property_Val=\"262144\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000011\" property_Cd=\"ORC_COMPRESSION_TYPE\" property_Nm=\"Orc Compression Type\" property_Val=\"ZLIB\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000014\" property_Cd=\"ORC_CREATE_INDEX\" property_Nm=\"Orc Create Index\" property_Val=\"FALSE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000013\" property_Cd=\"ORC_ROW_INDEX_STRIDE\" property_Nm=\"Orc Row Index Stride\" property_Val=\"10000\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000012\" property_Cd=\"ORC_STRIPE_SIZE\" property_Nm=\"Orc Stripe Size\" property_Val=\"268435456\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000017\" property_Cd=\"OUTPUT_FORMAT_CLASS\" property_Nm=\"Output Format Class\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000006\" property_Cd=\"COLLECTION_ITEMS_DELIMITER\" property_Nm=\"Collections Items Delimiter\" property_Val=\"\\002\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000021\" property_Cd=\"INTERMEDIATE_COMPRESSION\" property_Nm=\"Intermediate Compression\" property_Val=\"FALSE\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000022\" property_Cd=\"INTERMEDIATE_COMPRESSION_CODEC\" property_Nm=\"Intermediate Compression Codec\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000008\" property_Cd=\"LINE_DELIMITER\" property_Nm=\"Line Delimiter\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000007\" property_Cd=\"MAP_KEYS_DELIMITER\" property_Nm=\"Map keys Delimiter\" property_Val=\"\\003\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"10000009\" property_Cd=\"NULL_VALUE\" property_Nm=\"Null Value\" property_Val=\"\" srt_Order=\"3\" property_Type=\"F\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"2479934\" property_Cd=\"hive.optimize.bucketmapjoin\" property_Nm=\"hive.optimize.bucketmapjoin\" property_Val=\"NA\" srt_Order=\"4\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"2479936\" property_Cd=\"hive.optimize.bucketmapjoin.sortedmerge\" property_Nm=\"hive.optimize.bucketmapjoin.sortedmerge\" property_Val=\"NA\" srt_Order=\"5\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"2479937\" property_Cd=\"hive.auto.convert.sortmerge.join.noconditionaltask\" property_Nm=\"hive.auto.convert.sortmerge.join.noconditionaltask\" property_Val=\"NA\" srt_Order=\"6\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"2479938\" property_Cd=\"hive.auto.convert.sortmerge.join.bigtable.selection.policy\" property_Nm=\"hive.auto.convert.sortmerge.join.bigtable.selection.policy\" property_Val=\"NA\" srt_Order=\"7\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"900011\" property_Cd=\"mapred.map.output.compression.codec\" property_Nm=\"mapred.map.output.compression.codec\" property_Val=\"NA\" srt_Order=\"10\" property_Type=\"S\"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"248008\" property_Id=\"900013\" property_Cd=\"mapred.output.compression.type\" property_Nm=\"mapred.output.compression.type\" property_Val=\"NA\" srt_Order=\"12\" property_Type=\"S\"/>\n"
    ti+="</dxFlow_Obj_Properties>\n"
    ti+="<rce_DxMpUnits/>\n"
    ti+="<rce_DxMpUnit_OVs/>\n"
    ti+="<params/>\n"
    ti+="</designJob>\n"
    ti+="</objects>\n"
    
    ti+="<dxFlow_Fwd_Lnks>\n"
    ti+="<dxFlow_Fwd_Lnk dxFlow_Id=\""+stream_flow_id+"\" obj_Id=\"248008\" fwd_Lnk_Obj_Id=\"248007\" obj_Cd=\"DXMPI\" fwd_Lnk_Obj_Cd=\"DCMD\" lnkCndVal=\"::RTSU:248008.Status::=&apos;SUCCEEDED&apos;||::RTSU:248008.Status::=&apos;FAILED&apos;||::RTSU:248008.Status::=&apos;COMPLETED&apos;||::RTSU:248008.Status::=&apos;DEFERRED&apos;\" lnkCndValid_Cd=\"0\"/>\n"
    ti+="</dxFlow_Fwd_Lnks>\n"
    
    ti+="<dxFlow_Obj_Properties>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"-1\" property_Id=\"-1\" property_Cd=\"JDBC_TRAN_CTL\" property_Nm=\"JDBC_TRAN_CTL\" property_Val=\"N\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"-1\" property_Id=\"-1\" property_Cd=\"LOGGING_LEVEL\" property_Nm=\"LOGGING_LEVEL\" property_Val=\"INFO\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="<dxFlow_Obj_Property dxFlow_Id=\""+stream_flow_id+"\" job_Id=\"-1\" property_Id=\"-1\" property_Cd=\"TFORM_CLEANUP\" property_Nm=\"TFORM_CLEANUP\" property_Val=\"Y\" srt_Order=\"-1\" property_Type=\" \"/>\n"
    ti+="</dxFlow_Obj_Properties>\n"
    
    ti+="<dependent_Ids>\n"
    
    ti+="<long>247993</long>\n"
    ti+="<long>"+tgt_conn_id+"</long>\n"
    
    for items in src_obj_ref_id:
        ti+="<long>"+str(items)+"</long>\n"
        #print items
    for items in tgt_obj_ref_id:
        ti+="<long>"+str(items)+"</long>\n"
        #print items
    
    ti+="<long>"+src_conn_id+"</long>\n"
    ti+="</dependent_Ids>\n"
    ti+="</stream>\n"
    ti+="</streams>\n"
    ti+="<solutions/>\n"
    ti+="</layerObject>\n"
    ti+="</layers>\n"
    ti+="<connections>\n"
    ti+="<repConn fldr_Id=\"85427\" lockBy=\"\" mode_Ind=\"W\" unlock_Ind=\"N\" change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\" reusableFlag=\"N\" isDependent=\"true\" isLinkExist=\"false\" fldrNm=\"ingest_pa_bb76\">\n"
    <TARGET_CONNECTION>
    ti+="</repConn>\n"
    ti+="<repConn fldr_Id=\"85427\" lockBy=\"\" mode_Ind=\"W\" unlock_Ind=\"N\" change_Ind=\"N\" error_Cd=\"0\" error_Msg=\"\" ref_Id=\"-1\" ref_Cd=\"\" reusableFlag=\"N\" isDependent=\"true\" isLinkExist=\"false\" fldrNm=\"ingest_pa_bb76\">\n"
    <SOURCE_CONNECTION>
    writer.write(ti)
    del ti
    gc.collect()
    writer.write("</repConn>\n")
    writer.write("</connections>\n")
    writer.write("<reusables/>\n")
    writer.write("<nativeSequences/>\n")
    writer.write("</fldrObject>\n")
    writer.write("</folders>\n")
    writer.write("</repository>\n")
    
    
    #writer.write(ti)
logging.info('STREAM.py EXECUTION COMPLETED SUCCESSFULLY')
